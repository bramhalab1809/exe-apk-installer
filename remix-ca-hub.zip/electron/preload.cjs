const { contextBridge } = require('electron');

contextBridge.exposeInMainWorld('cahubDesktop', {
  isDesktop: true,
  platform: process.platform,
});
