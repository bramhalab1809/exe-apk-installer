const { app, BrowserWindow, shell, session } = require('electron');
const path = require('path');

let mainWindow = null;

function isExternalHttpUrl(rawUrl) {
  try {
    const parsed = new URL(rawUrl);
    if (parsed.protocol !== 'http:' && parsed.protocol !== 'https:') {
      return false;
    }
    const devUrl = process.env.VITE_DEV_SERVER_URL;
    if (devUrl && rawUrl.startsWith(devUrl)) {
      return false;
    }
    return true;
  } catch {
    return false;
  }
}

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1280,
    height: 800,
    minWidth: 360,
    minHeight: 640,
    title: 'CA Hub',
    autoHideMenuBar: true,
    icon: path.join(__dirname, '../public/icon.png'),
    backgroundColor: '#0C0A09',
    webPreferences: {
      preload: path.join(__dirname, 'preload.cjs'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: false,
    },
  });

  mainWindow.setMenuBarVisibility(false);

  // Open target="_blank" and Hugging Face resolve/download links in the default system browser
  mainWindow.webContents.setWindowOpenHandler(({ url }) => {
    if (isExternalHttpUrl(url)) {
      shell.openExternal(url).catch(() => {});
    }
    return { action: 'deny' };
  });

  // Prevent navigation away from the local app to external web pages inside the Electron window
  mainWindow.webContents.on('will-navigate', (event, url) => {
    if (isExternalHttpUrl(url)) {
      event.preventDefault();
      shell.openExternal(url).catch(() => {});
    }
  });

  const devServerUrl = process.env.VITE_DEV_SERVER_URL;
  if (devServerUrl) {
    mainWindow.loadURL(devServerUrl);
  } else {
    mainWindow.loadFile(path.join(__dirname, '../dist/index.html'));
  }

  mainWindow.on('closed', () => {
    mainWindow = null;
  });
}

app.whenReady().then(() => {
  // Handle file downloads cleanly in the default session
  if (session && session.defaultSession) {
    session.defaultSession.on('will-download', (_event, item) => {
      const fileName = item.getFilename();
      if (fileName) {
        item.setSaveDialogOptions({
          title: 'Save File',
          defaultPath: path.join(app.getPath('downloads'), fileName),
        });
      }
    });
  }

  createWindow();

  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) {
      createWindow();
    }
  });
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') {
    app.quit();
  }
});
