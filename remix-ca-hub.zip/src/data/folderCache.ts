import { Entry } from './types.ts';

export interface CachedFolder {
  t: number;
  entries: Entry[];
  maybeIncomplete: boolean;
}

const CACHE_PREFIX = 'cahub2.cache.';
const TTL_MS = 10 * 60 * 1000; // 10 minutes

const memoryCache = new Map<string, CachedFolder>();

function storageKey(path: string): string {
  return `${CACHE_PREFIX}${path}`;
}

function dropOldestKeys(count: number): void {
  if (typeof window === 'undefined') return;
  try {
    const items: { key: string; t: number }[] = [];
    for (let i = 0; i < localStorage.length; i++) {
      const key = localStorage.key(i);
      if (key && key.startsWith(CACHE_PREFIX)) {
        try {
          const raw = localStorage.getItem(key);
          const parsed = raw ? JSON.parse(raw) : null;
          items.push({ key, t: typeof parsed?.t === 'number' ? parsed.t : 0 });
        } catch {
          items.push({ key, t: 0 });
        }
      }
    }

    items.sort((a, b) => a.t - b.t);
    for (let i = 0; i < Math.min(count, items.length); i++) {
      localStorage.removeItem(items[i].key);
    }
  } catch {
    // Non-fatal eviction failure
  }
}

export function getCached(
  path: string,
  allowStale = false
): { entries: Entry[]; maybeIncomplete: boolean; isStale: boolean } | null {
  const now = Date.now();

  // 1. Check memory cache
  const mem = memoryCache.get(path);
  if (mem) {
    const isStale = now - mem.t > TTL_MS;
    if (!isStale || allowStale) {
      return {
        entries: mem.entries,
        maybeIncomplete: mem.maybeIncomplete,
        isStale,
      };
    }
  }

  // 2. Check localStorage
  if (typeof window === 'undefined') return null;
  try {
    const raw = localStorage.getItem(storageKey(path));
    if (!raw) return null;
    const parsed = JSON.parse(raw) as CachedFolder;
    if (parsed && Array.isArray(parsed.entries) && typeof parsed.t === 'number') {
      memoryCache.set(path, parsed);
      const isStale = now - parsed.t > TTL_MS;
      if (!isStale || allowStale) {
        return {
          entries: parsed.entries,
          maybeIncomplete: Boolean(parsed.maybeIncomplete),
          isStale,
        };
      }
    }
  } catch {
    // Cache read failure falls back to fresh fetch
  }

  return null;
}

export function setCached(
  path: string,
  value: { entries: Entry[]; maybeIncomplete: boolean }
): void {
  const item: CachedFolder = {
    t: Date.now(),
    entries: value.entries,
    maybeIncomplete: value.maybeIncomplete,
  };

  memoryCache.set(path, item);

  if (typeof window === 'undefined') return;
  const key = storageKey(path);
  const serialized = JSON.stringify(item);

  try {
    localStorage.setItem(key, serialized);
  } catch {
    // Quota exceeded: drop 10 oldest keys and retry once
    try {
      dropOldestKeys(10);
      localStorage.setItem(key, serialized);
    } catch {
      // Storage unavailable or quota persistently exceeded
    }
  }
}

export function clearAllCaches(): void {
  memoryCache.clear();
  if (typeof window === 'undefined') return;
  try {
    const toRemove: string[] = [];
    for (let i = 0; i < localStorage.length; i++) {
      const key = localStorage.key(i);
      if (key && key.startsWith(CACHE_PREFIX)) {
        toRemove.push(key);
      }
    }
    for (const key of toRemove) {
      localStorage.removeItem(key);
    }
  } catch {
    // Non-fatal cache clearing error
  }
}
