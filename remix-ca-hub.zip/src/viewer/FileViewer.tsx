import { lazy, Suspense, useState, useEffect, useRef } from 'react';
import {
  ChevronLeft,
  ChevronRight,
  ExternalLink,
  Download,
  Maximize2,
  Minimize2,
  X,
  RotateCw,
  Star,
} from '../icons/index.ts';
import { Kind } from '../data/types.ts';
import { kindOf } from '../data/fileKinds.ts';
import { fileUrl } from '../data/hfApi.ts';
import { folderHref, parentOf } from '../router/hashRoute.ts';
import { fileLinkProps } from '../lib/fileLink.ts';
import { useSiblings } from '../hooks/useSiblings.ts';
import { ImageViewer } from './ImageViewer.tsx';
import { MediaViewer } from './MediaViewer.tsx';
import { TextViewer } from './TextViewer.tsx';
import { OtherViewer } from './OtherViewer.tsx';

const PdfViewer = lazy(() => import('./PdfViewer.tsx'));

export interface FileViewerProps {
  path: string;
  isStarred?: boolean;
  onToggleStar?: (item: { name: string; path: string; isFolder: boolean; kind: Kind }) => void;
}

const btnClass =
  'flex h-8 w-8 sm:h-9 sm:w-9 shrink-0 items-center justify-center rounded-[8px] text-[#78716C] dark:text-[#A8A29E] hover:bg-[#F5F5F4] dark:hover:bg-[#292524] hover:text-[#1C1917] dark:hover:text-[#FAFAF9] transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#F59E0B]';

export function FileViewer({ path, isStarred = false, onToggleStar }: FileViewerProps) {
  const { parentPath, prevPath, nextPath } = useSiblings(path);
  const [isFullscreen, setIsFullscreen] = useState<boolean>(false);
  const [recovering, setRecovering] = useState<boolean>(false);
  const containerRef = useRef<HTMLDivElement | null>(null);

  const fileName = path.split('/').pop() || path;
  const kind = kindOf(fileName);
  const closeHref = folderHref(parentOf(path));
  const canFullscreen = typeof document !== 'undefined' && Boolean(document.fullscreenEnabled);

  const parentSegments = (parentPath || 'Home')
    .split('/')
    .filter(Boolean)
    .map((part, idx, arr) => ({ name: part, path: arr.slice(0, idx + 1).join('/') }));

  useEffect(() => {
    setRecovering(false);
  }, [path]);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && !document.fullscreenElement) {
        window.location.hash = folderHref(parentOf(path));
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [path]);

  useEffect(() => {
    const onFsChange = () => setIsFullscreen(Boolean(document.fullscreenElement));
    document.addEventListener('fullscreenchange', onFsChange);
    return () => document.removeEventListener('fullscreenchange', onFsChange);
  }, []);

  const toggleFullscreen = () => {
    if (!canFullscreen) return;
    if (!document.fullscreenElement) {
      containerRef.current?.requestFullscreen?.().catch(() => {});
    } else {
      document.exitFullscreen?.().catch(() => {});
    }
  };

  const handleOpenInBrowserTab = () => {
    setTimeout(() => {
      window.location.hash = folderHref(parentOf(path));
    }, 0);
  };

  const crumbHref = (p: string) => (p.toLowerCase() === 'home' ? '#/' : folderHref(p));
  const crumbClass =
    'hover:text-[#1C1917] dark:hover:text-[#FAFAF9] hover:underline focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-[#F59E0B] rounded';

  return (
    <div ref={containerRef} className="flex flex-1 flex-col w-full h-full min-h-0 overflow-hidden bg-white dark:bg-[#1C1917]">
      <div className="flex h-12 w-full items-center justify-between gap-1.5 sm:gap-2 px-2 shrink-0 border-b border-[#E7E5E4] dark:border-[#292524] bg-white dark:bg-[#1C1917]">
        <div className="flex items-center gap-0.5 sm:gap-1 min-w-0 flex-1">
          {prevPath ? (
            <a {...fileLinkProps(prevPath)} aria-label="Previous file" title="Previous file" className={btnClass}>
              <ChevronLeft className="h-5 w-5" />
            </a>
          ) : (
            <button type="button" disabled aria-label="Previous file" title="Previous file" className={`${btnClass} opacity-40 pointer-events-none`}>
              <ChevronLeft className="h-5 w-5" />
            </button>
          )}

          {nextPath ? (
            <a {...fileLinkProps(nextPath)} aria-label="Next file" title="Next file" className={btnClass}>
              <ChevronRight className="h-5 w-5" />
            </a>
          ) : (
            <button type="button" disabled aria-label="Next file" title="Next file" className={`${btnClass} opacity-40 pointer-events-none`}>
              <ChevronRight className="h-5 w-5" />
            </button>
          )}

          <div className="flex flex-col min-w-0 flex-1 pl-1">
            <span title={fileName} className="text-[13px] font-medium text-[#1C1917] dark:text-[#FAFAF9] truncate leading-tight">
              {fileName}
            </span>
            <div className="flex items-center gap-0.5 text-[11px] text-[#78716C] dark:text-[#A8A29E] overflow-hidden whitespace-nowrap leading-tight min-w-0">
              {parentSegments.length <= 3 ? (
                parentSegments.map((seg, i) => (
                  <span key={seg.path} className="inline-flex items-center min-w-0">
                    {i > 0 && <span className="mx-0.5 shrink-0">&rsaquo;</span>}
                    <a href={crumbHref(seg.path)} title={`Go to ${seg.name}`} className={`${crumbClass} truncate max-w-[100px] sm:max-w-[160px]`}>
                      {seg.name}
                    </a>
                  </span>
                ))
              ) : (
                <>
                  <a href={crumbHref(parentSegments[0].path)} title={`Go to ${parentSegments[0].name}`} className={`${crumbClass} shrink-0`}>
                    {parentSegments[0].name}
                  </a>
                  <span className="mx-0.5 shrink-0">&rsaquo;</span>
                  <a href={folderHref(parentSegments[parentSegments.length - 2].path)} title={`Go to ${parentSegments[parentSegments.length - 2].name}`} className={`${crumbClass} shrink-0`}>
                    ...
                  </a>
                  <span className="mx-0.5 shrink-0">&rsaquo;</span>
                  <a href={folderHref(parentSegments[parentSegments.length - 1].path)} title={`Go to ${parentSegments[parentSegments.length - 1].name}`} className={`${crumbClass} truncate min-w-0`}>
                    {parentSegments[parentSegments.length - 1].name}
                  </a>
                </>
              )}
            </div>
          </div>
        </div>

        <div className="flex items-center gap-0.5 shrink-0">
          {recovering && (
            <span aria-label="Recovering" title="Recovering" className="flex h-8 w-8 sm:h-9 sm:w-9 items-center justify-center text-[#F59E0B]">
              <RotateCw className="h-4 w-4 animate-spin" />
            </span>
          )}
          {onToggleStar && (
            <button
              type="button"
              onClick={() => onToggleStar({ name: fileName, path, isFolder: false, kind })}
              aria-label={isStarred ? 'Remove from Starred' : 'Add to Starred'}
              title={isStarred ? 'Remove from Starred' : 'Add to Starred'}
              className={btnClass}
            >
              <Star className={`h-4 w-4 ${isStarred ? 'fill-[#F59E0B] text-[#F59E0B]' : ''}`} />
            </button>
          )}
          <a
            href={fileUrl(path)}
            target="_blank"
            rel="noopener noreferrer"
            aria-label="Open in browser tab"
            title="Open in browser tab"
            onClick={handleOpenInBrowserTab}
            onAuxClick={handleOpenInBrowserTab}
            className={btnClass}
          >
            <ExternalLink className="h-4 w-4" />
          </a>
          <a href={fileUrl(path, { download: true })} download aria-label="Download" title="Download" className={btnClass}>
            <Download className="h-4 w-4" />
          </a>
          {canFullscreen && (
            <button
              type="button"
              onClick={toggleFullscreen}
              aria-label={isFullscreen ? 'Exit fullscreen' : 'Fullscreen'}
              title={isFullscreen ? 'Exit fullscreen' : 'Fullscreen'}
              className={btnClass}
            >
              {isFullscreen ? <Minimize2 className="h-4 w-4" /> : <Maximize2 className="h-4 w-4" />}
            </button>
          )}
          <a href={closeHref} aria-label="Close" title="Close" className={btnClass}>
            <X className="h-4 w-4" />
          </a>
        </div>
      </div>

      {kind === 'pdf' && (
        <Suspense
          fallback={
            <div className="flex-1 w-full h-full flex items-center justify-center p-6 bg-[#F5F5F4] dark:bg-[#0C0A09]">
              <div className="w-full max-w-[720px] h-full rounded-lg bg-[#E7E5E4] dark:bg-[#292524] animate-pulse" />
            </div>
          }
        >
          <PdfViewer path={path} onRecoveringChange={setRecovering} />
        </Suspense>
      )}
      {kind === 'image' && <ImageViewer path={path} />}
      {(kind === 'video' || kind === 'audio') && <MediaViewer path={path} kind={kind} />}
      {kind === 'text' && <TextViewer path={path} />}
      {kind === 'other' && <OtherViewer path={path} />}
    </div>
  );
}
