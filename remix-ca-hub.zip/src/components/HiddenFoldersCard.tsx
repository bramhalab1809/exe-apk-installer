import { useState, useMemo } from 'react';
import { RotateCcw, Plus, X, ChevronDown, ChevronUp } from '../icons/index.ts';

interface HiddenFoldersCardProps {
  hiddenFolders: string[];
  onAdd: (name: string) => void;
  onRemove: (name: string) => void;
  onReset: () => void;
  availableFolders?: string[];
}

export function HiddenFoldersCard({
  hiddenFolders,
  onAdd,
  onRemove,
  onReset,
  availableFolders = [],
}: HiddenFoldersCardProps) {
  const [newFolderName, setNewFolderName] = useState('');
  const [isCollapsed, setIsCollapsed] = useState(true);

  // Available folders that are not already hidden
  const unhiddenFolders = useMemo(() => {
    const hiddenLower = new Set(hiddenFolders.map((h) => h.trim().toLowerCase()));
    return availableFolders.filter((f) => !hiddenLower.has(f.trim().toLowerCase()));
  }, [availableFolders, hiddenFolders]);

  // Quick chips for top common folders that are currently not hidden
  const topChips = useMemo(() => {
    const common = ['About me', 'EXTERNAL_SM', 'ICAI_SM'];
    return common.filter((name) => unhiddenFolders.includes(name));
  }, [unhiddenFolders]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (newFolderName.trim()) {
      onAdd(newFolderName.trim());
      setNewFolderName('');
    }
  };

  return (
    <div className="flex flex-col rounded-xl border border-[#E7E5E4] dark:border-[#292524] p-3 bg-[#F5F5F4]/40 dark:bg-[#0C0A09]/40 mt-3 gap-2 shrink-0">
      {/* Header with title, count, reset and minimize/expand chevron */}
      <div className="flex min-h-[32px] items-center justify-between">
        <button
          type="button"
          onClick={() => setIsCollapsed((c) => !c)}
          className="flex items-center gap-1.5 text-left text-sm font-medium text-[#1C1917] dark:text-[#FAFAF9] hover:opacity-80 transition-opacity focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#F59E0B] rounded"
        >
          <span>Hidden folders</span>
          {hiddenFolders.length > 0 && (
            <span className="text-[11px] px-1.5 py-0.2 rounded-full bg-[#E7E5E4] dark:bg-[#292524] text-[#78716C] dark:text-[#A8A29E]">
              {hiddenFolders.length}
            </span>
          )}
        </button>

        <div className="flex items-center gap-1">
          <button
            type="button"
            onClick={onReset}
            aria-label="Reset hidden folders to default"
            title="Reset to default"
            className="flex h-7 w-7 items-center justify-center rounded-lg text-[#78716C] dark:text-[#A8A29E] hover:bg-[#F5F5F4] dark:hover:bg-[#292524] hover:text-[#1C1917] dark:hover:text-[#FAFAF9] transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#F59E0B]"
          >
            <RotateCcw className="h-3.5 w-3.5" />
          </button>
          <button
            type="button"
            onClick={() => setIsCollapsed((c) => !c)}
            aria-label={isCollapsed ? 'Expand hidden folders' : 'Minimize hidden folders'}
            title={isCollapsed ? 'Expand' : 'Minimize'}
            className="flex h-7 w-7 items-center justify-center rounded-lg text-[#78716C] dark:text-[#A8A29E] hover:bg-[#F5F5F4] dark:hover:bg-[#292524] hover:text-[#1C1917] dark:hover:text-[#FAFAF9] transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#F59E0B]"
          >
            {isCollapsed ? (
              <ChevronDown className="h-4 w-4" />
            ) : (
              <ChevronUp className="h-4 w-4" />
            )}
          </button>
        </div>
      </div>

      {!isCollapsed && (
        <div className="flex flex-col gap-2.5 pt-1">
          {/* Quick Select Dropdown */}
          {unhiddenFolders.length > 0 && (
            <div className="flex flex-col gap-1">
              <select
                value=""
                onChange={(e) => {
                  if (e.target.value) {
                    onAdd(e.target.value);
                  }
                }}
                className="w-full h-8 px-2 text-xs rounded-lg border border-[#E7E5E4] dark:border-[#292524] bg-white dark:bg-[#1C1917] text-[#1C1917] dark:text-[#FAFAF9] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#F59E0B] cursor-pointer"
              >
                <option value="" disabled>
                  Select folder to hide...
                </option>
                {unhiddenFolders.map((folder) => (
                  <option key={folder} value={folder}>
                    {folder}
                  </option>
                ))}
              </select>
            </div>
          )}

          {/* Quick chips for prominent unhidden folders */}
          {topChips.length > 0 && (
            <div className="flex flex-wrap gap-1 items-center">
              {topChips.map((name) => (
                <button
                  key={name}
                  type="button"
                  onClick={() => onAdd(name)}
                  title={`Hide ${name}`}
                  className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] bg-white dark:bg-[#1C1917] border border-[#E7E5E4] dark:border-[#292524] text-[#78716C] dark:text-[#A8A29E] hover:border-[#F59E0B] hover:text-[#1C1917] dark:hover:text-[#FAFAF9] transition-colors focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-[#F59E0B]"
                >
                  <Plus className="h-3 w-3 text-[#F59E0B]" />
                  <span>{name}</span>
                </button>
              ))}
            </div>
          )}

          {/* Manual Input with datalist autocomplete */}
          <form onSubmit={handleSubmit} className="flex items-center gap-1.5">
            <input
              type="text"
              list="folder-datalist-suggestions"
              value={newFolderName}
              onChange={(e) => setNewFolderName(e.target.value)}
              placeholder="Or type folder name"
              className="flex-1 min-w-0 h-8 px-2.5 text-xs rounded-lg border border-[#E7E5E4] dark:border-[#292524] bg-white dark:bg-[#1C1917] text-[#1C1917] dark:text-[#FAFAF9] placeholder-[#78716C] dark:placeholder-[#A8A29E] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#F59E0B]"
            />
            <datalist id="folder-datalist-suggestions">
              {unhiddenFolders.map((f) => (
                <option key={f} value={f} />
              ))}
            </datalist>
            <button
              type="submit"
              aria-label="Add hidden folder"
              title="Add"
              className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg border border-[#E7E5E4] dark:border-[#292524] bg-white dark:bg-[#1C1917] text-[#78716C] dark:text-[#A8A29E] hover:text-[#1C1917] dark:hover:text-[#FAFAF9] hover:bg-[#F5F5F4] dark:hover:bg-[#292524] transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#F59E0B]"
            >
              <Plus className="h-4 w-4" />
            </button>
          </form>

          {/* Currently hidden folders list */}
          {hiddenFolders.length > 0 ? (
            <div className="flex flex-col gap-1 max-h-36 overflow-y-auto pt-0.5">
              {hiddenFolders.map((item) => (
                <div
                  key={item}
                  className="flex items-center justify-between py-1 px-2 rounded-md bg-white dark:bg-[#1C1917] border border-[#E7E5E4] dark:border-[#292524]"
                >
                  <span className="text-xs truncate text-[#1C1917] dark:text-[#FAFAF9] mr-2">
                    {item}
                  </span>
                  <button
                    type="button"
                    onClick={() => onRemove(item)}
                    aria-label={`Remove hidden folder ${item}`}
                    title="Unhide folder"
                    className="flex h-5 w-5 shrink-0 items-center justify-center rounded text-[#78716C] dark:text-[#A8A29E] hover:text-[#EF4444] transition-colors focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-[#F59E0B]"
                  >
                    <X className="h-3 w-3" />
                  </button>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-[11px] text-[#78716C] dark:text-[#A8A29E] py-1 text-center">
              No hidden folders
            </div>
          )}
        </div>
      )}
    </div>
  );
}
