import { useState, useEffect, useRef } from 'react';
import { ChevronLeft, ChevronRight, Folder } from '../icons/index.ts';
import { folderHref, parentOf } from '../router/hashRoute.ts';

export interface FolderPathBarProps {
  folderPath: string;
}

interface PathSegment {
  name: string;
  path: string;
}

function normalizeFolder(p: string): string {
  const clean = (p || '').trim().replace(/^\/+|\/+$/g, '');
  return !clean || clean.toLowerCase() === 'home' ? 'Home' : clean;
}

function buildSegments(folderPath: string): PathSegment[] {
  const clean = (folderPath || '').trim().replace(/^\/+|\/+$/g, '');
  if (!clean || clean.toLowerCase() === 'home') return [];
  const parts = clean.split('/').filter(Boolean);
  const segments: PathSegment[] = [];
  let accum = '';
  for (const part of parts) {
    accum = accum ? `${accum}/${part}` : part;
    segments.push({ name: part, path: accum });
  }
  return segments;
}

export function FolderPathBar({ folderPath }: FolderPathBarProps) {
  const normalized = normalizeFolder(folderPath);
  const segments = buildSegments(folderPath);
  const [navState, setNavState] = useState<{ stack: string[]; index: number }>(() => ({
    stack: [normalized],
    index: 0,
  }));
  const internalNavRef = useRef<boolean>(false);
  const [menuOpen, setMenuOpen] = useState<boolean>(false);
  const menuRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    setMenuOpen(false);
    setNavState((prev) => {
      if (prev.stack[prev.index] === normalized) return prev;
      if (internalNavRef.current) {
        internalNavRef.current = false;
        return prev;
      }
      if (prev.index > 0 && prev.stack[prev.index - 1] === normalized) {
        return { ...prev, index: prev.index - 1 };
      }
      if (prev.index < prev.stack.length - 1 && prev.stack[prev.index + 1] === normalized) {
        return { ...prev, index: prev.index + 1 };
      }
      const nextStack = [...prev.stack.slice(0, prev.index + 1), normalized];
      return { stack: nextStack, index: nextStack.length - 1 };
    });
  }, [normalized]);

  useEffect(() => {
    if (!menuOpen) return;
    const onDown = (e: MouseEvent | TouchEvent) => {
      if (menuRef.current && !menuRef.current.contains(e.target as Node)) setMenuOpen(false);
    };
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') setMenuOpen(false);
    };
    document.addEventListener('mousedown', onDown);
    document.addEventListener('touchstart', onDown);
    document.addEventListener('keydown', onKey);
    return () => {
      document.removeEventListener('mousedown', onDown);
      document.removeEventListener('touchstart', onDown);
      document.removeEventListener('keydown', onKey);
    };
  }, [menuOpen]);

  const isAtRoot = segments.length === 0;
  const canGoBack = !isAtRoot;
  const canGoForward = navState.index < navState.stack.length - 1;

  if (isAtRoot && !canGoForward) return null;

  const handleBack = () => {
    if (!canGoBack) return;
    const parent = normalizeFolder(parentOf(folderPath));
    setNavState((prev) => {
      internalNavRef.current = true;
      if (prev.index > 0 && prev.stack[prev.index - 1] === parent) {
        return { ...prev, index: prev.index - 1 };
      }
      const before = prev.stack.slice(0, prev.index);
      const updated = [...before, parent, ...prev.stack.slice(prev.index)];
      return { stack: updated, index: before.length };
    });
    window.location.hash = folderHref(parent === 'Home' ? '' : parent);
  };

  const handleForward = () => {
    if (!canGoForward) return;
    const nextFolder = navState.stack[navState.index + 1];
    internalNavRef.current = true;
    setNavState((prev) => ({ ...prev, index: Math.min(prev.stack.length - 1, prev.index + 1) }));
    window.location.hash = folderHref(nextFolder === 'Home' ? '' : nextFolder);
  };

  const hasCollapsed = segments.length > 3;
  const collapsedSegments = hasCollapsed ? segments.slice(1, segments.length - 2) : [];
  const tailSegments = hasCollapsed ? segments.slice(segments.length - 2) : segments.slice(1);
  const navBtnBase = 'flex h-7 w-7 items-center justify-center rounded-[6px] transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#F59E0B]';

  return (
    <div className="flex items-center gap-2 w-full mb-3 pb-2 border-b border-[#E7E5E4] dark:border-[#292524] shrink-0">
      <div className="inline-flex items-center rounded-[8px] border border-[#E7E5E4] dark:border-[#292524] bg-[#F5F5F4]/80 dark:bg-[#292524]/80 p-0.5 shrink-0">
        <button
          type="button"
          onClick={handleBack}
          disabled={!canGoBack}
          aria-label="Back to previous folder"
          title="Back"
          className={`${navBtnBase} ${canGoBack ? 'text-[#1C1917] dark:text-[#FAFAF9] hover:bg-[#E5F3FF] dark:hover:bg-[#2B3A4F] cursor-pointer' : 'text-[#78716C]/40 dark:text-[#A8A29E]/35 pointer-events-none'}`}
        >
          <ChevronLeft className="h-4 w-4 shrink-0" />
        </button>
        <div className="w-px h-4 bg-[#E7E5E4] dark:bg-[#3F3A36]" />
        <button
          type="button"
          onClick={handleForward}
          disabled={!canGoForward}
          aria-label="Forward to next folder"
          title="Next"
          className={`${navBtnBase} ${canGoForward ? 'text-[#1C1917] dark:text-[#FAFAF9] hover:bg-[#E5F3FF] dark:hover:bg-[#2B3A4F] cursor-pointer' : 'text-[#78716C]/40 dark:text-[#A8A29E]/35 pointer-events-none'}`}
        >
          <ChevronRight className="h-4 w-4 shrink-0" />
        </button>
      </div>

      <nav aria-label="Folder path" className="flex flex-1 items-center gap-0.5 min-w-0 overflow-visible">
        {isAtRoot ? (
          <span className="inline-flex items-center gap-1.5 px-2 py-1 rounded-[6px] text-[12px] font-semibold text-[#1C1917] dark:text-[#FAFAF9] bg-[#E5F3FF] dark:bg-[#2B3A4F]">
            <Folder className="h-3.5 w-3.5 text-[#F59E0B] shrink-0" />
            <span>Home</span>
          </span>
        ) : (
          <>
            <a
              href={segments[0].path.toLowerCase() === 'home' ? '#/' : folderHref(segments[0].path)}
              title={segments[0].name}
              className={`inline-flex items-center gap-1 px-1.5 py-1 rounded-[6px] text-[12px] transition-colors shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#F59E0B] ${
                segments.length === 1
                  ? 'font-semibold text-[#1C1917] dark:text-[#FAFAF9] bg-[#E5F3FF] dark:bg-[#2B3A4F]'
                  : 'font-medium text-[#78716C] dark:text-[#A8A29E] hover:text-[#1C1917] dark:hover:text-[#FAFAF9] hover:bg-[#F5F5F4] dark:hover:bg-[#292524]'
              }`}
            >
              {segments.length === 1 && <Folder className="h-3.5 w-3.5 text-[#F59E0B] shrink-0" />}
              <span className="max-w-[90px] sm:max-w-[130px] truncate">{segments[0].name}</span>
            </a>

            {collapsedSegments.length > 0 && (
              <div ref={menuRef} className="relative flex items-center gap-0.5 shrink-0">
                <ChevronRight className="h-3.5 w-3.5 text-[#78716C] dark:text-[#A8A29E] shrink-0" />
                <button
                  type="button"
                  onClick={() => setMenuOpen((v) => !v)}
                  aria-expanded={menuOpen}
                  aria-label="Show hidden path folders"
                  title="Show intermediate folders"
                  className={`flex h-6 px-1.5 items-center justify-center rounded-[6px] text-[12px] font-semibold tracking-wider transition-colors cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#F59E0B] ${
                    menuOpen
                      ? 'bg-[#CCE8FF] dark:bg-[#35507A] text-[#1C1917] dark:text-[#FAFAF9]'
                      : 'bg-[#F5F5F4] dark:bg-[#292524] text-[#78716C] dark:text-[#A8A29E] hover:text-[#1C1917] dark:hover:text-[#FAFAF9] hover:bg-[#E5F3FF] dark:hover:bg-[#2B3A4F]'
                  }`}
                >
                  ...
                </button>
                {menuOpen && (
                  <div
                    role="menu"
                    className="absolute left-0 top-full mt-1.5 z-30 min-w-[190px] max-w-[260px] rounded-[10px] border border-[#E7E5E4] dark:border-[#292524] bg-white dark:bg-[#1C1917] p-1 shadow-lg"
                  >
                    {collapsedSegments.map((seg) => (
                      <a
                        key={seg.path}
                        href={folderHref(seg.path)}
                        onClick={() => setMenuOpen(false)}
                        title={seg.name}
                        className="flex items-center gap-2 px-2.5 py-1.5 rounded-[6px] text-[12px] font-medium text-[#1C1917] dark:text-[#FAFAF9] hover:bg-[#E5F3FF] dark:hover:bg-[#2B3A4F] transition-colors truncate"
                      >
                        <Folder className="h-3.5 w-3.5 text-[#F59E0B] shrink-0" />
                        <span className="truncate">{seg.name}</span>
                      </a>
                    ))}
                  </div>
                )}
              </div>
            )}

            {tailSegments.map((seg, idx) => {
              const isLast = idx === tailSegments.length - 1;
              const hideOnPhone = !isLast && tailSegments.length > 1 && collapsedSegments.length > 0;
              return (
                <div key={seg.path} className={`${hideOnPhone ? 'hidden sm:flex' : 'flex'} items-center gap-0.5 min-w-0 ${isLast ? 'shrink' : 'shrink-0'}`}>
                  <ChevronRight className="h-3.5 w-3.5 text-[#78716C] dark:text-[#A8A29E] shrink-0" />
                  <a
                    href={folderHref(seg.path)}
                    title={seg.name}
                    aria-current={isLast ? 'page' : undefined}
                    className={`inline-flex items-center gap-1 px-1.5 py-1 rounded-[6px] text-[12px] min-w-0 transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#F59E0B] ${
                      isLast
                        ? 'font-semibold text-[#1C1917] dark:text-[#FAFAF9] bg-[#E5F3FF] dark:bg-[#2B3A4F]'
                        : 'font-medium text-[#78716C] dark:text-[#A8A29E] hover:text-[#1C1917] dark:hover:text-[#FAFAF9] hover:bg-[#F5F5F4] dark:hover:bg-[#292524]'
                    }`}
                  >
                    {isLast && <Folder className="h-3.5 w-3.5 text-[#F59E0B] shrink-0" />}
                    <span className="max-w-[130px] sm:max-w-[160px] md:max-w-[220px] truncate">{seg.name}</span>
                  </a>
                </div>
              );
            })}
          </>
        )}
      </nav>
    </div>
  );
}
