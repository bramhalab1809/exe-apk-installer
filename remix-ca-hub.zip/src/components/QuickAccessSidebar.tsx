import { useEffect } from 'react';
import { ChevronRight, X, Star, Trash2 } from '../icons/index.ts';
import { QuickAccessItem, QuickAccessTab } from '../hooks/useQuickAccess.ts';
import { folderHref } from '../router/hashRoute.ts';
import { fileLinkProps } from '../lib/fileLink.ts';
import { RecentClockIcon, StarredFolderIcon } from './QuickAccessIcons.tsx';

interface QuickAccessSidebarProps {
  isMobile: boolean;
  activeTab: QuickAccessTab | null;
  onSelectTab: (tab: QuickAccessTab) => void;
  onClose: () => void;
  recentItems: QuickAccessItem[];
  starredItems: QuickAccessItem[];
  onToggleStar: (item: QuickAccessItem) => void;
  onRemoveRecent: (path: string) => void;
  onClearRecents: () => void;
}

function formatParent(path: string): string {
  const parts = path.split('/').filter(Boolean);
  return parts.length <= 1 ? 'Home' : parts.slice(0, -1).join(' / ');
}

export function QuickAccessSidebar({
  isMobile,
  activeTab,
  onSelectTab,
  onClose,
  recentItems,
  starredItems,
  onToggleStar,
  onRemoveRecent,
  onClearRecents,
}: QuickAccessSidebarProps) {
  const isOpen = activeTab !== null;
  const currentTab: QuickAccessTab = activeTab || 'recent';
  const items = currentTab === 'recent' ? recentItems : starredItems;

  useEffect(() => {
    if (!isMobile || !isOpen) return;
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [isMobile, isOpen, onClose]);

  const tabBtnClass = (active: boolean) =>
    `flex h-7 w-7 items-center justify-center rounded-[6px] transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#F59E0B] ${
      active
        ? 'bg-[#CCE8FF] dark:bg-[#35507A] text-[#1C1917] dark:text-[#FAFAF9]'
        : 'text-[#78716C] dark:text-[#A8A29E] hover:text-[#1C1917] dark:hover:text-[#FAFAF9]'
    }`;

  const panelContent = (
    <>
      <div className="flex h-12 w-full items-center justify-between px-2.5 shrink-0 border-b border-[#E7E5E4] dark:border-[#292524]">
        <div className="flex items-center gap-1.5 min-w-0">
          {currentTab === 'recent' ? (
            <RecentClockIcon className="h-4 w-4 text-[#F59E0B] shrink-0" />
          ) : (
            <StarredFolderIcon className="h-4 w-4 text-[#F59E0B] shrink-0" />
          )}
          <span className="text-[15px] font-semibold text-[#1C1917] dark:text-[#FAFAF9] truncate select-none">
            {currentTab === 'recent' ? 'Recent Open' : 'Starred'}
          </span>
        </div>

        <div className="flex items-center gap-1 shrink-0">
          <div className="flex items-center rounded-lg border border-[#E7E5E4] dark:border-[#292524] p-0.5 bg-[#F5F5F4]/60 dark:bg-[#0C0A09]/60">
            <button type="button" onClick={() => onSelectTab('recent')} aria-label="Recent Open" title="Recent Open" className={tabBtnClass(currentTab === 'recent')}>
              <RecentClockIcon className="h-3.5 w-3.5" />
            </button>
            <button type="button" onClick={() => onSelectTab('starred')} aria-label="Starred" title="Starred" className={tabBtnClass(currentTab === 'starred')}>
              <StarredFolderIcon className="h-3.5 w-3.5" />
            </button>
          </div>

          {currentTab === 'recent' && recentItems.length > 0 && (
            <button
              type="button"
              onClick={onClearRecents}
              aria-label="Clear recent items"
              title="Clear recent items"
              className="flex h-8 w-8 items-center justify-center rounded-[8px] text-[#78716C] dark:text-[#A8A29E] hover:bg-[#F5F5F4] dark:hover:bg-[#292524] hover:text-[#EF4444] transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#F59E0B]"
            >
              <Trash2 className="h-4 w-4" />
            </button>
          )}

          <button
            type="button"
            onClick={onClose}
            aria-label="Collapse Quick Access Panel"
            title="Collapse panel"
            className="flex h-8 w-8 items-center justify-center rounded-[8px] text-[#78716C] dark:text-[#A8A29E] hover:bg-[#F5F5F4] dark:hover:bg-[#292524] hover:text-[#1C1917] dark:hover:text-[#FAFAF9] transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#F59E0B]"
          >
            <ChevronRight className="h-5 w-5" />
          </button>
        </div>
      </div>

      <div className="flex-1 w-full overflow-y-auto overflow-x-hidden p-2 flex flex-col gap-1">
        {items.length === 0 ? (
          <div className="flex flex-1 flex-col items-center justify-center py-12 px-4 text-center gap-2 text-[#78716C] dark:text-[#A8A29E]">
            {currentTab === 'recent' ? <RecentClockIcon className="h-8 w-8 opacity-50" /> : <StarredFolderIcon className="h-8 w-8 opacity-50" />}
            <span className="text-[13px] font-medium">{currentTab === 'recent' ? 'No recent items' : 'No starred items'}</span>
          </div>
        ) : (
          items.map((item) => {
            const href = item.isFolder ? folderHref(item.path) : fileLinkProps(item.path).href;
            return (
              <div key={item.path} className="group flex items-center justify-between gap-1.5 rounded-[8px] px-2 py-1.5 hover:bg-[#E5F3FF] dark:hover:bg-[#2B3A4F] transition-colors min-w-0">
                <a
                  href={href}
                  onClick={isMobile ? onClose : undefined}
                  title={item.path}
                  className="flex flex-1 items-center gap-2 min-w-0 focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-[#F59E0B] rounded"
                >
                  {item.isFolder ? (
                    <svg width="20" height="16" viewBox="0 0 24 20" fill="none" className="shrink-0" aria-hidden="true">
                      <path d="M2 4a2 2 0 0 1 2-2h5l2 2h9a2 2 0 0 1 2 2v2H2V4z" fill="#E8A317" />
                      <rect x="2" y="6" width="20" height="12" rx="2" fill="#FBBF24" />
                    </svg>
                  ) : (
                    <span className="flex h-5 w-5 shrink-0 items-center justify-center rounded bg-[#EF4444]/15 text-[#EF4444] text-[9px] font-bold uppercase">
                      {(item.name.split('.').pop() || 'FILE').slice(0, 3)}
                    </span>
                  )}
                  <div className="flex flex-col min-w-0 flex-1">
                    <span className="text-[13px] font-medium text-[#1C1917] dark:text-[#FAFAF9] truncate leading-tight">{item.name}</span>
                    <span className="text-[11px] text-[#78716C] dark:text-[#A8A29E] truncate leading-tight">{formatParent(item.path)}</span>
                  </div>
                </a>

                {currentTab === 'starred' ? (
                  <button
                    type="button"
                    onClick={() => onToggleStar(item)}
                    aria-label={`Unstar ${item.name}`}
                    title="Remove from Starred"
                    className="flex h-7 w-7 shrink-0 items-center justify-center rounded-md text-[#F59E0B] hover:bg-black/5 dark:hover:bg-white/5 transition-colors focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-[#F59E0B]"
                  >
                    <Star className="h-3.5 w-3.5 fill-current" />
                  </button>
                ) : (
                  <button
                    type="button"
                    onClick={() => onRemoveRecent(item.path)}
                    aria-label={`Remove ${item.name} from recents`}
                    title="Remove"
                    className="flex h-7 w-7 shrink-0 items-center justify-center rounded-md text-[#78716C] dark:text-[#A8A29E] hover:text-[#EF4444] hover:bg-black/5 dark:hover:bg-white/5 transition-colors focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-[#F59E0B]"
                  >
                    <X className="h-3.5 w-3.5" />
                  </button>
                )}
              </div>
            );
          })
        )}
      </div>
    </>
  );

  if (isMobile) {
    return (
      <>
        <div
          className={`fixed inset-0 z-40 bg-black/40 backdrop-blur-[1px] transition-opacity duration-200 ${
            isOpen ? 'opacity-100 pointer-events-auto' : 'opacity-0 pointer-events-none'
          }`}
          onClick={onClose}
          aria-hidden="true"
        />
        <aside
          role="complementary"
          aria-label="Quick Access Panel"
          aria-hidden={!isOpen}
          className={`fixed top-2 bottom-2 right-2 z-50 flex flex-col w-[min(288px,85vw)] rounded-[16px] border border-[#E7E5E4] dark:border-[#292524] bg-white dark:bg-[#1C1917] shadow-lg transition-transform duration-200 ease-in-out overflow-hidden ${
            isOpen ? 'translate-x-0' : 'translate-x-[120%]'
          }`}
        >
          {panelContent}
        </aside>
      </>
    );
  }

  return (
    <aside
      role="complementary"
      aria-label="Quick Access Panel"
      aria-hidden={!isOpen}
      className={`h-full flex flex-col rounded-[16px] bg-white dark:bg-[#1C1917] transition-all duration-200 ease-in-out overflow-hidden ${
        isOpen
          ? 'w-[288px] min-w-[288px] opacity-100 border border-[#E7E5E4] dark:border-[#292524]'
          : 'w-0 min-w-0 opacity-0 border-0 p-0 -ml-2 sm:-ml-3 pointer-events-none'
      }`}
    >
      <div className="flex flex-col h-full w-[288px]">{panelContent}</div>
    </aside>
  );
}
