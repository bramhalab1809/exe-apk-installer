import { useState, useRef, useLayoutEffect, useEffect, useMemo } from 'react';
import { AlertTriangle } from './icons/index.ts';
import { Sidebar } from './components/Sidebar.tsx';
import { QuickAccessSidebar } from './components/QuickAccessSidebar.tsx';
import { FolderGrid } from './components/FolderGrid.tsx';
import { FolderPathBar } from './components/FolderPathBar.tsx';
import { SearchRow } from './components/SearchRow.tsx';
import { SearchResults } from './components/SearchResults.tsx';
import { SettingsDialog } from './components/SettingsDialog.tsx';
import { FileViewer } from './viewer/FileViewer.tsx';
import { usePrefs } from './hooks/usePrefs.ts';
import { useSidebar } from './hooks/useSidebar.ts';
import { useQuickAccess } from './hooks/useQuickAccess.ts';
import { useHashRoute } from './router/useHashRoute.ts';
import { useFolder } from './hooks/useFolder.ts';
import { useTree } from './hooks/useTree.ts';
import { useSearchIndex } from './search/useSearchIndex.ts';
import { search } from './search/rank.ts';
import { filterHidden } from './data/sortAndHide.ts';
import { clearAllCaches } from './data/folderCache.ts';
import { kindOf } from './data/fileKinds.ts';
import { useKindFilter } from './hooks/useKindFilter.ts';
import { useSearchNav } from './hooks/useSearchNav.ts';
import { useNativeBack } from './hooks/useNativeBack.ts';

export default function App() {
  const route = useHashRoute();
  const searchNav = useSearchNav(route);
  const { isSearch } = searchNav;
  const isViewer = route.type === 'viewer';
  const prefs = usePrefs();
  const { isMobile, isOpen, openSidebar, closeSidebar } = useSidebar();
  const quickAccess = useQuickAccess();
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const gearButtonRef = useRef<HTMLButtonElement | null>(null);
  const mainRef = useRef<HTMLElement | null>(null);
  const scrollMap = useRef<Map<string, number>>(new Map());
  const { selectedKinds, toggleKindGroup } = useKindFilter();

  const currentFolderPath = isSearch ? '' : route.folderPath;
  const { entries, status, stale, refresh } = useFolder(currentFolderPath);

  const treeExpandPath = isSearch ? '__search_active__' : isViewer ? route.filePath : route.folderPath;
  const sidebarCurrentPath = isSearch ? '__search_active__' : isViewer ? `v:${route.filePath}` : route.folderPath;
  const tree = useTree(treeExpandPath, prefs.hiddenFolders);
  const searchIndex = useSearchIndex(status === 'ready');

  useNativeBack({
    route,
    isSettingsOpen,
    onCloseSettings: () => setIsSettingsOpen(false),
    isMobile,
    isSidebarOpen: isOpen,
    onCloseSidebar: closeSidebar,
    isQuickAccessOpen: quickAccess.activeTab !== null,
    onCloseQuickAccess: quickAccess.closePanel,
    onClearSearch: searchNav.handleClearOrEsc,
  });

  useEffect(() => {
    if (route.type === 'viewer' && route.filePath) {
      const name = route.filePath.split('/').pop() || route.filePath;
      quickAccess.recordRecent({ name, path: route.filePath, isFolder: false, kind: kindOf(name) });
    } else if (route.type === 'folder' && route.folderPath && route.folderPath !== 'Home') {
      const name = route.folderPath.split('/').pop() || route.folderPath;
      quickAccess.recordRecent({ name, path: route.folderPath, isFolder: true, kind: 'other' });
    }
  }, [route.type, route.filePath, route.folderPath, quickAccess.recordRecent]);

  const visibleFolderEntries = useMemo(
    () => filterHidden(entries, prefs.hiddenFolders),
    [entries, prefs.hiddenFolders]
  );

  const availableFolders = useMemo(() => {
    const set = new Set<string>(['About me', 'EXTERNAL_SM', 'ICAI_SM']);
    for (const e of searchIndex.entries) {
      if (e.isFolder && e.name) set.add(e.name);
    }
    return Array.from(set).sort((a, b) => a.localeCompare(b, undefined, { numeric: true, sensitivity: 'base' }));
  }, [searchIndex.entries]);

  const searchResults = useMemo(() => {
    if (!isSearch || !route.query.trim()) return [];
    const effectiveScope = searchNav.activeScope === 'folder' ? searchNav.currentScopeFolder : null;
    return search(searchIndex.entries, route.query, {
      kinds: selectedKinds,
      scopeFolder: effectiveScope,
      hidden: prefs.hiddenFolders,
    });
  }, [isSearch, route.query, searchNav.activeScope, searchNav.currentScopeFolder, searchIndex.entries, selectedKinds, prefs.hiddenFolders]);

  const handleScroll = () => {
    if (mainRef.current && route.type === 'folder') {
      scrollMap.current.set(route.folderPath, mainRef.current.scrollTop);
    }
  };

  useLayoutEffect(() => {
    if (mainRef.current) {
      mainRef.current.scrollTop = route.type === 'folder' ? (scrollMap.current.get(route.folderPath) ?? 0) : 0;
    }
  }, [route.type, route.folderPath]);

  useEffect(() => {
    if (route.type === 'folder' && status === 'ready' && mainRef.current) {
      mainRef.current.scrollTop = scrollMap.current.get(route.folderPath) ?? 0;
    }
  }, [route.type, status, route.folderPath]);

  const handleReload = async () => {
    clearAllCaches();
    refresh();
    tree.resetTree();
    await searchIndex.rebuild();
  };

  return (
    <div className="flex h-dvh w-full flex-row p-2 sm:p-3 gap-2 sm:gap-3 bg-[#F5F5F4] dark:bg-[#0C0A09] text-[#1C1917] dark:text-[#FAFAF9] overflow-hidden select-none">
      <Sidebar
        isMobile={isMobile}
        isOpen={isOpen}
        onClose={closeSidebar}
        onOpenSettings={() => setIsSettingsOpen(true)}
        gearButtonRef={gearButtonRef}
        tree={tree}
        currentPath={sidebarCurrentPath}
      />

      <main
        ref={mainRef}
        role="main"
        onScroll={handleScroll}
        className={`relative flex-1 min-w-0 h-full rounded-[16px] border border-[#E7E5E4] dark:border-[#292524] bg-white dark:bg-[#1C1917] ${
          isViewer ? 'flex flex-col overflow-hidden p-0' : 'p-3 sm:p-6 overflow-y-auto overflow-x-hidden'
        }`}
      >
        {isViewer ? (
          <FileViewer
            path={route.filePath}
            isStarred={quickAccess.isStarred(route.filePath)}
            onToggleStar={quickAccess.toggleStar}
          />
        ) : (
          <>
            {!isSearch && stale && (
              <div className="absolute top-4 right-4 z-10 flex items-center justify-center text-[#F59E0B]" title="Offline copy" aria-label="Offline copy">
                <AlertTriangle className="h-5 w-5" />
              </div>
            )}

            <SearchRow
              query={isSearch ? route.query : ''}
              onQueryChange={searchNav.handleQueryChange}
              scopeFolder={searchNav.currentScopeFolder}
              activeScope={searchNav.activeScope}
              onScopeChange={searchNav.handleScopeChange}
              selectedKinds={selectedKinds}
              onToggleKindGroup={toggleKindGroup}
              building={searchIndex.building}
              maybeIncomplete={searchIndex.maybeIncomplete}
              showPanelButton={isMobile || !isOpen}
              onOpenSidebar={openSidebar}
              onClearOrEsc={searchNav.handleClearOrEsc}
              onFocusInput={searchIndex.triggerImmediateBuild}
              showControls={prefs.showSearchControls}
              activeQuickTab={quickAccess.activeTab}
              onToggleQuickTab={quickAccess.toggleTab}
            />

            {isSearch ? (
              <SearchResults
                entries={searchResults}
                query={route.query}
                ready={searchIndex.ready}
                building={searchIndex.building}
                error={searchIndex.error}
                onRetry={searchIndex.triggerImmediateBuild}
                onFolderClick={searchNav.handleClearOrEsc}
                isStarred={quickAccess.isStarred}
                onToggleStar={quickAccess.toggleStar}
              />
            ) : (
              <>
                <FolderPathBar folderPath={route.folderPath} />
                <FolderGrid
                  entries={visibleFolderEntries}
                  status={status}
                  onRetry={refresh}
                  isStarred={quickAccess.isStarred}
                  onToggleStar={quickAccess.toggleStar}
                />
              </>
            )}
          </>
        )}
      </main>

      <QuickAccessSidebar
        isMobile={isMobile}
        activeTab={quickAccess.activeTab}
        onSelectTab={quickAccess.setActiveTab}
        onClose={quickAccess.closePanel}
        recentItems={quickAccess.recentItems}
        starredItems={quickAccess.starredItems}
        onToggleStar={quickAccess.toggleStar}
        onRemoveRecent={quickAccess.removeRecent}
        onClearRecents={quickAccess.clearRecents}
      />

      <SettingsDialog
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
        theme={prefs.theme}
        onSelectTheme={prefs.setTheme}
        triggerRef={gearButtonRef}
        onReload={handleReload}
        hiddenFolders={prefs.hiddenFolders}
        onAddHiddenFolder={prefs.addHiddenFolder}
        onRemoveHiddenFolder={prefs.removeHiddenFolder}
        onResetHiddenFolders={prefs.resetHiddenFolders}
        showSearchControls={prefs.showSearchControls}
        onToggleSearchControls={prefs.setShowSearchControls}
        availableFolders={availableFolders}
      />
    </div>
  );
}
