import { useEffect, useRef } from 'react';
import { RouteState, folderHref, parentOf } from '../router/hashRoute.ts';

export interface UseNativeBackOptions {
  route: RouteState;
  isSettingsOpen: boolean;
  onCloseSettings: () => void;
  isMobile: boolean;
  isSidebarOpen: boolean;
  onCloseSidebar: () => void;
  isQuickAccessOpen: boolean;
  onCloseQuickAccess: () => void;
  onClearSearch: () => void;
}

/**
 * Handles Android APK / Capacitor hardware Back button (`backbutton` event)
 * so pressing Back navigates cleanly through modals, drawers, file viewer,
 * search, and parent folders before allowing app exit at the root `#/` screen.
 */
export function useNativeBack(options: UseNativeBackOptions): void {
  const optsRef = useRef<UseNativeBackOptions>(options);
  optsRef.current = options;

  useEffect(() => {
    const handleBackButton = (event: Event) => {
      const {
        route,
        isSettingsOpen,
        onCloseSettings,
        isMobile,
        isSidebarOpen,
        onCloseSidebar,
        isQuickAccessOpen,
        onCloseQuickAccess,
        onClearSearch,
      } = optsRef.current;

      // 1. Close Settings dialog if open
      if (isSettingsOpen) {
        event.preventDefault();
        onCloseSettings();
        return;
      }

      // 2. Close mobile Quick Access drawer or mobile Explore sidebar drawer if open
      if (isMobile && isQuickAccessOpen) {
        event.preventDefault();
        onCloseQuickAccess();
        return;
      }
      if (isMobile && isSidebarOpen) {
        event.preventDefault();
        onCloseSidebar();
        return;
      }

      // 3. Exit in-app viewer back to its parent folder
      if (route.type === 'viewer') {
        event.preventDefault();
        window.location.hash = folderHref(parentOf(route.filePath));
        return;
      }

      // 4. Clear active search and return to folder view
      if (route.type === 'search') {
        event.preventDefault();
        onClearSearch();
        return;
      }

      // 5. Step up to parent folder when inside a subfolder
      const cleanFolder = (route.folderPath || '').trim().replace(/^\/+|\/+$/g, '');
      if (cleanFolder && cleanFolder.toLowerCase() !== 'home') {
        event.preventDefault();
        window.location.hash = folderHref(parentOf(cleanFolder));
        return;
      }
      // 6. At root `#/`: allow default Capacitor/Android back behavior (minimize/exit)
    };

    document.addEventListener('backbutton', handleBackButton, false);
    return () => {
      document.removeEventListener('backbutton', handleBackButton, false);
    };
  }, []);
}
