import { useState, useEffect } from 'react';
import { parseHash, RouteState } from './hashRoute.ts';

export function useHashRoute(): RouteState {
  const [route, setRoute] = useState<RouteState>(() => {
    if (typeof window === 'undefined') {
      return { type: 'folder', folderPath: '', filePath: '', query: '', scopeFolder: null };
    }
    return parseHash(window.location.hash);
  });

  useEffect(() => {
    const handleHashChange = () => {
      setRoute(parseHash(window.location.hash));
    };

    window.addEventListener('hashchange', handleHashChange);
    return () => window.removeEventListener('hashchange', handleHashChange);
  }, []);

  return route;
}
