/**
 * Hash route parsing and URL construction.
 * Routes:
 *   #/ -> root folder ('')
 *   #/f/<encodeURIComponent(folderPath)> -> specific folder
 *   #/s/<encodeURIComponent(query)>?in=<encodeURIComponent(folderPath)> -> search
 *   #/v/<encodeURIComponent(filePath)> -> in-app file viewer
 */

export type RouteType = 'folder' | 'search' | 'viewer';

export interface RouteState {
  type: RouteType;
  folderPath: string;
  filePath: string;
  query: string;
  scopeFolder: string | null;
}

export function parentOf(path: string): string {
  const clean = path.trim().replace(/^\/+|\/+$/g, '');
  if (!clean || !clean.includes('/')) {
    return '';
  }
  return clean.slice(0, clean.lastIndexOf('/'));
}

export function parseHash(hash: string): RouteState {
  if (!hash || hash === '#' || hash === '#/') {
    return { type: 'folder', folderPath: '', filePath: '', query: '', scopeFolder: null };
  }

  // Viewer route: #/v/<filePath>
  if (hash.startsWith('#/v/')) {
    const raw = hash.slice(4);
    try {
      const filePath = decodeURIComponent(raw).trim().replace(/^\/+|\/+$/g, '');
      if (filePath) {
        return {
          type: 'viewer',
          folderPath: parentOf(filePath),
          filePath,
          query: '',
          scopeFolder: null,
        };
      }
    } catch {
      // Fall through to root folder
    }
    return { type: 'folder', folderPath: '', filePath: '', query: '', scopeFolder: null };
  }

  // Search route: #/s/<query>?in=<scope>
  if (hash.startsWith('#/s/')) {
    const withoutPrefix = hash.slice(4);
    const questionIndex = withoutPrefix.indexOf('?');
    const rawQuery = questionIndex === -1 ? withoutPrefix : withoutPrefix.slice(0, questionIndex);
    const rawParams = questionIndex === -1 ? '' : withoutPrefix.slice(questionIndex + 1);

    let query = '';
    try {
      query = decodeURIComponent(rawQuery);
    } catch {
      query = '';
    }

    let scopeFolder: string | null = null;
    if (rawParams) {
      try {
        const searchParams = new URLSearchParams(rawParams);
        const inParam = searchParams.get('in');
        if (inParam) {
          scopeFolder = decodeURIComponent(inParam);
        }
      } catch {
        // Fall back to null scope
      }
    }

    if (!query) {
      return {
        type: 'folder',
        folderPath: scopeFolder || '',
        filePath: '',
        query: '',
        scopeFolder: null,
      };
    }

    return {
      type: 'search',
      folderPath: scopeFolder || '',
      filePath: '',
      query,
      scopeFolder,
    };
  }

  // Folder route: #/f/<folderPath>
  if (hash.startsWith('#/f/')) {
    const raw = hash.slice(4);
    try {
      const folderPath = decodeURIComponent(raw);
      return { type: 'folder', folderPath, filePath: '', query: '', scopeFolder: null };
    } catch {
      return { type: 'folder', folderPath: '', filePath: '', query: '', scopeFolder: null };
    }
  }

  return { type: 'folder', folderPath: '', filePath: '', query: '', scopeFolder: null };
}

export function folderHref(path: string): string {
  const clean = path.trim().replace(/^\/+|\/+$/g, '');
  if (!clean) {
    return '#/';
  }
  return `#/f/${encodeURIComponent(clean)}`;
}

export function fileHref(path: string): string {
  const clean = path.trim().replace(/^\/+|\/+$/g, '');
  if (!clean) {
    return '#/';
  }
  return `#/v/${encodeURIComponent(clean)}`;
}

export function searchHref(query: string, scopeFolder?: string | null): string {
  const cleanQuery = query.trim();
  const cleanScope = scopeFolder ? scopeFolder.trim().replace(/^\/+|\/+$/g, '') : null;

  if (!cleanQuery) {
    return folderHref(cleanScope || '');
  }

  const encodedQuery = encodeURIComponent(cleanQuery);
  if (cleanScope) {
    return `#/s/${encodedQuery}?in=${encodeURIComponent(cleanScope)}`;
  }
  return `#/s/${encodedQuery}`;
}
