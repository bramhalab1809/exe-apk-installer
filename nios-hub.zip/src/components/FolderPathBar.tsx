import { useState, useEffect, useRef } from 'react';
import { ChevronLeft, ChevronRight, Folder } from '../icons/index.ts';
import { folderHref, parentOf } from '../router/hashRoute.ts';
import { FolderPathMenu, PathSegment } from './FolderPathMenu.tsx';

export interface FolderPathBarProps {
  folderPath: string;
}

function normalizeFolder(p: string): string {
  const clean = (p || '').trim().replace(/^\/+|\/+$/g, '');
  if (!clean || clean.toLowerCase() === 'home') return 'Home';
  return clean;
}

function buildSegments(folderPath: string): PathSegment[] {
  const clean = (folderPath || '').trim().replace(/^\/+|\/+$/g, '');
  if (!clean || clean.toLowerCase() === 'home') {
    return [];
  }
  const parts = clean.split('/').filter(Boolean);
  const segments: PathSegment[] = [];
  let accum = '';
  for (const part of parts) {
    accum = accum ? `${accum}/${part}` : part;
    segments.push({ name: part, path: accum });
  }
  return segments;
}

export function FolderPathBar({ folderPath }: FolderPathBarProps) {
  const normalized = normalizeFolder(folderPath);
  const segments = buildSegments(folderPath);

  // Track folder history so Back (<) and Next (>) buttons work seamlessly
  const [navState, setNavState] = useState<{ stack: string[]; index: number }>(() => ({
    stack: [normalized],
    index: 0,
  }));
  const internalNavRef = useRef<boolean>(false);

  useEffect(() => {
    setNavState((prev) => {
      const currentInStack = prev.stack[prev.index];
      if (currentInStack === normalized) return prev;
      if (internalNavRef.current) {
        internalNavRef.current = false;
        return prev;
      }
      if (prev.index > 0 && prev.stack[prev.index - 1] === normalized) {
        return { ...prev, index: prev.index - 1 };
      }
      if (prev.index < prev.stack.length - 1 && prev.stack[prev.index + 1] === normalized) {
        return { ...prev, index: prev.index + 1 };
      }
      const nextStack = prev.stack.slice(0, prev.index + 1);
      nextStack.push(normalized);
      return { stack: nextStack, index: nextStack.length - 1 };
    });
  }, [normalized]);

  const isAtRoot = segments.length === 0;
  const canGoBack = !isAtRoot;
  const canGoForward = navState.index < navState.stack.length - 1;

  // Hide the bar completely when at Home with no forward history
  if (isAtRoot && !canGoForward) {
    return null;
  }

  const handleBack = () => {
    if (!canGoBack) return;
    const parent = normalizeFolder(parentOf(folderPath));
    setNavState((prev) => {
      if (prev.index > 0 && prev.stack[prev.index - 1] === parent) {
        internalNavRef.current = true;
        return { ...prev, index: prev.index - 1 };
      }
      // Insert parent right before current index so Next (>) can return to current folder
      const before = prev.stack.slice(0, prev.index);
      const fromCurrent = prev.stack.slice(prev.index);
      const updated = [...before, parent, ...fromCurrent];
      internalNavRef.current = true;
      return {
        stack: updated,
        index: before.length,
      };
    });
    window.location.hash = folderHref(parent === 'Home' ? '' : parent);
  };

  const handleForward = () => {
    if (!canGoForward) return;
    const nextFolder = navState.stack[navState.index + 1];
    internalNavRef.current = true;
    setNavState((prev) => ({
      ...prev,
      index: Math.min(prev.stack.length - 1, prev.index + 1),
    }));
    window.location.hash = folderHref(nextFolder === 'Home' ? '' : nextFolder);
  };

  // Determine visible vs collapsed middle segments so path never spreads out or scrolls
  // segments[0] is typically "Home" (or "About me")
  const hasCollapsedDesktop = segments.length > 3;
  const collapsedSegments = hasCollapsedDesktop ? segments.slice(1, segments.length - 2) : [];
  const tailSegments = hasCollapsedDesktop ? segments.slice(segments.length - 2) : segments.slice(1);

  return (
    <div className="flex items-center gap-2 w-full mb-3 pb-2 border-b border-[#E7E5E4] dark:border-[#292524] shrink-0">
      {/* Compact Back (<) and Next (>) navigation buttons */}
      <div className="inline-flex items-center rounded-[8px] border border-[#E7E5E4] dark:border-[#292524] bg-[#F5F5F4]/80 dark:bg-[#292524]/80 p-0.5 shrink-0">
        <button
          type="button"
          onClick={handleBack}
          disabled={!canGoBack}
          aria-label="Back to previous folder"
          title="Back"
          className={`flex h-7 w-7 items-center justify-center rounded-[6px] transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#F59E0B] ${
            canGoBack
              ? 'text-[#1C1917] dark:text-[#FAFAF9] hover:bg-[#E5F3FF] dark:hover:bg-[#2B3A4F] cursor-pointer'
              : 'text-[#78716C]/40 dark:text-[#A8A29E]/35 pointer-events-none'
          }`}
        >
          <ChevronLeft className="h-4 w-4 shrink-0" />
        </button>
        <div className="w-px h-4 bg-[#E7E5E4] dark:bg-[#3F3A36]" />
        <button
          type="button"
          onClick={handleForward}
          disabled={!canGoForward}
          aria-label="Forward to next folder"
          title="Next"
          className={`flex h-7 w-7 items-center justify-center rounded-[6px] transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#F59E0B] ${
            canGoForward
              ? 'text-[#1C1917] dark:text-[#FAFAF9] hover:bg-[#E5F3FF] dark:hover:bg-[#2B3A4F] cursor-pointer'
              : 'text-[#78716C]/40 dark:text-[#A8A29E]/35 pointer-events-none'
          }`}
        >
          <ChevronRight className="h-4 w-4 shrink-0" />
        </button>
      </div>

      {/* Compact, non-scrolling breadcrumb bar with middle ellipsis dropdown */}
      <nav
        aria-label="Folder path"
        className="flex flex-1 items-center gap-0.5 min-w-0 overflow-visible"
      >
        {isAtRoot ? (
          <span className="inline-flex items-center gap-1.5 px-2 py-1 rounded-[6px] text-[12px] font-semibold text-[#1C1917] dark:text-[#FAFAF9] bg-[#E5F3FF] dark:bg-[#2B3A4F]">
            <Folder className="h-3.5 w-3.5 text-[#F59E0B] shrink-0" />
            <span>Home</span>
          </span>
        ) : (
          <>
            {/* Root / First segment (e.g. Home) */}
            <a
              href={segments[0].path.toLowerCase() === 'home' ? '#/' : folderHref(segments[0].path)}
              title={segments[0].name}
              className={`inline-flex items-center gap-1 px-1.5 py-1 rounded-[6px] text-[12px] transition-colors shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#F59E0B] ${
                segments.length === 1
                  ? 'font-semibold text-[#1C1917] dark:text-[#FAFAF9] bg-[#E5F3FF] dark:bg-[#2B3A4F]'
                  : 'font-medium text-[#78716C] dark:text-[#A8A29E] hover:text-[#1C1917] dark:hover:text-[#FAFAF9] hover:bg-[#F5F5F4] dark:hover:bg-[#292524]'
              }`}
            >
              {segments.length === 1 && <Folder className="h-3.5 w-3.5 text-[#F59E0B] shrink-0" />}
              <span className="max-w-[90px] sm:max-w-[130px] truncate">{segments[0].name}</span>
            </a>

            {/* Collapsed middle segments ("•••" dropdown) when path is deep */}
            <FolderPathMenu collapsedSegments={collapsedSegments} />

            {/* Last 1-2 segments (parent + current folder) */}
            {tailSegments.map((seg, idx) => {
              const isLast = idx === tailSegments.length - 1;
              const hideOnVerySmallMobile = !isLast && tailSegments.length > 1 && collapsedSegments.length > 0;
              return (
                <div
                  key={seg.path}
                  className={`${
                    hideOnVerySmallMobile ? 'hidden sm:flex' : 'flex'
                  } items-center gap-0.5 min-w-0 ${isLast ? 'shrink' : 'shrink-0'}`}
                >
                  <ChevronRight className="h-3.5 w-3.5 text-[#78716C] dark:text-[#A8A29E] shrink-0" />
                  <a
                    href={folderHref(seg.path)}
                    title={seg.name}
                    aria-current={isLast ? 'page' : undefined}
                    className={`inline-flex items-center gap-1 px-1.5 py-1 rounded-[6px] text-[12px] min-w-0 transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#F59E0B] ${
                      isLast
                        ? 'font-semibold text-[#1C1917] dark:text-[#FAFAF9] bg-[#E5F3FF] dark:bg-[#2B3A4F]'
                        : 'font-medium text-[#78716C] dark:text-[#A8A29E] hover:text-[#1C1917] dark:hover:text-[#FAFAF9] hover:bg-[#F5F5F4] dark:hover:bg-[#292524]'
                    }`}
                  >
                    {isLast && <Folder className="h-3.5 w-3.5 text-[#F59E0B] shrink-0" />}
                    <span className="max-w-[130px] sm:max-w-[160px] md:max-w-[220px] truncate">
                      {seg.name}
                    </span>
                  </a>
                </div>
              );
            })}
          </>
        )}
      </nav>
    </div>
  );
}
