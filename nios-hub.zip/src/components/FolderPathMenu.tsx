import { useState, useEffect, useRef } from 'react';
import { ChevronRight, Folder } from '../icons/index.ts';
import { folderHref } from '../router/hashRoute.ts';

export interface PathSegment {
  name: string;
  path: string;
}

interface FolderPathMenuProps {
  collapsedSegments: PathSegment[];
}

export function FolderPathMenu({ collapsedSegments }: FolderPathMenuProps) {
  const [menuOpen, setMenuOpen] = useState<boolean>(false);
  const menuRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    if (!menuOpen) return;
    const handlePointerDown = (e: MouseEvent | TouchEvent) => {
      if (menuRef.current && !menuRef.current.contains(e.target as Node)) {
        setMenuOpen(false);
      }
    };
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        setMenuOpen(false);
      }
    };
    document.addEventListener('mousedown', handlePointerDown);
    document.addEventListener('touchstart', handlePointerDown);
    document.addEventListener('keydown', handleKeyDown);
    return () => {
      document.removeEventListener('mousedown', handlePointerDown);
      document.removeEventListener('touchstart', handlePointerDown);
      document.removeEventListener('keydown', handleKeyDown);
    };
  }, [menuOpen]);

  if (collapsedSegments.length === 0) return null;

  return (
    <div ref={menuRef} className="relative flex items-center gap-0.5 shrink-0">
      <ChevronRight className="h-3.5 w-3.5 text-[#78716C] dark:text-[#A8A29E] shrink-0" />
      <button
        type="button"
        onClick={() => setMenuOpen((v) => !v)}
        aria-expanded={menuOpen}
        aria-label="Show hidden path folders"
        title="Show intermediate folders"
        className={`flex h-6 px-1.5 items-center justify-center rounded-[6px] text-[12px] font-semibold tracking-wider transition-colors cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#F59E0B] ${
          menuOpen
            ? 'bg-[#CCE8FF] dark:bg-[#35507A] text-[#1C1917] dark:text-[#FAFAF9]'
            : 'bg-[#F5F5F4] dark:bg-[#292524] text-[#78716C] dark:text-[#A8A29E] hover:text-[#1C1917] dark:hover:text-[#FAFAF9] hover:bg-[#E5F3FF] dark:hover:bg-[#2B3A4F]'
        }`}
      >
        •••
      </button>

      {menuOpen && (
        <div
          role="menu"
          className="absolute left-0 top-full mt-1.5 z-30 min-w-[190px] max-w-[260px] rounded-[10px] border border-[#E7E5E4] dark:border-[#292524] bg-white dark:bg-[#1C1917] p-1 shadow-lg"
        >
          {collapsedSegments.map((seg) => (
            <a
              key={seg.path}
              href={folderHref(seg.path)}
              onClick={() => setMenuOpen(false)}
              title={seg.name}
              className="flex items-center gap-2 px-2.5 py-1.5 rounded-[6px] text-[12px] font-medium text-[#1C1917] dark:text-[#FAFAF9] hover:bg-[#E5F3FF] dark:hover:bg-[#2B3A4F] transition-colors truncate"
            >
              <Folder className="h-3.5 w-3.5 text-[#F59E0B] shrink-0" />
              <span className="truncate">{seg.name}</span>
            </a>
          ))}
        </div>
      )}
    </div>
  );
}
