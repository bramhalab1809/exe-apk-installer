import { useState, useEffect, useRef } from 'react';
import { Sun, Moon, Monitor, X, RotateCw, ChevronDown, ChevronUp } from '../icons/index.ts';
import { ThemeMode } from '../hooks/usePrefs.ts';
import { HiddenFoldersCard } from './HiddenFoldersCard.tsx';

interface SettingsDialogProps {
  isOpen: boolean;
  onClose: () => void;
  theme: ThemeMode;
  onSelectTheme: (theme: ThemeMode) => void;
  triggerRef?: React.RefObject<HTMLButtonElement | null>;
  onReload: () => void;
  hiddenFolders: string[];
  onAddHiddenFolder: (name: string) => void;
  onRemoveHiddenFolder: (name: string) => void;
  onResetHiddenFolders: () => void;
  showSearchControls: boolean;
  onToggleSearchControls: (val: boolean) => void;
  availableFolders?: string[];
}

export function SettingsDialog({
  isOpen,
  onClose,
  theme,
  onSelectTheme,
  triggerRef,
  onReload,
  hiddenFolders,
  onAddHiddenFolder,
  onRemoveHiddenFolder,
  onResetHiddenFolders,
  showSearchControls,
  onToggleSearchControls,
  availableFolders,
}: SettingsDialogProps) {
  const [controlsCollapsed, setControlsCollapsed] = useState(true);
  const dialogRef = useRef<HTMLDivElement>(null);
  const closeButtonRef = useRef<HTMLButtonElement>(null);

  useEffect(() => {
    if (!isOpen) return;
    setControlsCollapsed(true);
    const timer = setTimeout(() => closeButtonRef.current?.focus(), 50);

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        e.stopPropagation();
        onClose();
        return;
      }
      if (e.key === 'Tab' && dialogRef.current) {
        const focusable = dialogRef.current.querySelectorAll<HTMLElement>(
          'button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])'
        );
        if (focusable.length === 0) return;
        const first = focusable[0];
        const last = focusable[focusable.length - 1];
        if (e.shiftKey && document.activeElement === first) {
          e.preventDefault();
          last.focus();
        } else if (!e.shiftKey && document.activeElement === last) {
          e.preventDefault();
          first.focus();
        }
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => {
      clearTimeout(timer);
      window.removeEventListener('keydown', handleKeyDown);
      triggerRef?.current?.focus();
    };
  }, [isOpen, onClose, triggerRef]);

  if (!isOpen) return null;

  const themeBtnClass = (mode: ThemeMode) =>
    `flex h-8 w-8 items-center justify-center rounded-md transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#F59E0B] ${
      theme === mode
        ? 'bg-[#E5F3FF] dark:bg-[#2B3A4F] text-[#1C1917] dark:text-[#FAFAF9]'
        : 'text-[#78716C] dark:text-[#A8A29E] hover:bg-[#F5F5F4] dark:hover:bg-[#292524]'
    }`;

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="settings-dialog-title"
      className="fixed inset-0 z-50 flex items-center justify-center p-2.5 sm:p-4 bg-black/40 backdrop-blur-[1px] animate-in fade-in duration-150"
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div
        ref={dialogRef}
        className="w-full max-w-[340px] max-h-[calc(100dvh-20px)] sm:max-h-[90dvh] flex flex-col rounded-[16px] border border-[#E7E5E4] dark:border-[#292524] bg-white dark:bg-[#1C1917] p-4 sm:p-5 shadow-sm text-[#1C1917] dark:text-[#FAFAF9] overflow-y-auto overflow-x-hidden"
      >
        <div className="flex items-center justify-between pb-3 shrink-0">
          <span id="settings-dialog-title" className="text-sm font-semibold">
            Settings
          </span>
          <button
            ref={closeButtonRef}
            type="button"
            onClick={onClose}
            aria-label="Close settings"
            title="Close"
            className="flex h-8 w-8 items-center justify-center rounded-lg text-[#78716C] dark:text-[#A8A29E] hover:bg-[#F5F5F4] dark:hover:bg-[#292524] hover:text-[#1C1917] dark:hover:text-[#FAFAF9] transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#F59E0B]"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        {/* 1. Theme Card */}
        <div className="flex min-h-[48px] items-center justify-between gap-2 rounded-xl border border-[#E7E5E4] dark:border-[#292524] px-3 py-2 bg-[#F5F5F4]/40 dark:bg-[#0C0A09]/40 shrink-0">
          <span className="text-sm font-medium text-[#1C1917] dark:text-[#FAFAF9]">Theme</span>
          <div className="flex items-center gap-1 rounded-lg border border-[#E7E5E4] dark:border-[#292524] p-1 bg-white dark:bg-[#1C1917] shrink-0">
            <button type="button" onClick={() => onSelectTheme('light')} aria-label="Light theme" title="Light theme" className={themeBtnClass('light')}>
              <Sun className="h-4 w-4" />
            </button>
            <button type="button" onClick={() => onSelectTheme('dark')} aria-label="Dark theme" title="Dark theme" className={themeBtnClass('dark')}>
              <Moon className="h-4 w-4" />
            </button>
            <button type="button" onClick={() => onSelectTheme('system')} aria-label="System theme" title="System theme" className={themeBtnClass('system')}>
              <Monitor className="h-4 w-4" />
            </button>
          </div>
        </div>

        {/* 2. Controls Card (Minimized by default on open) */}
        <div className="flex flex-col rounded-xl border border-[#E7E5E4] dark:border-[#292524] p-3 bg-[#F5F5F4]/40 dark:bg-[#0C0A09]/40 mt-3 gap-2 shrink-0">
          <div className="flex min-h-[32px] items-center justify-between">
            <button
              type="button"
              onClick={() => setControlsCollapsed((c) => !c)}
              className="flex items-center gap-1.5 text-left text-sm font-medium text-[#1C1917] dark:text-[#FAFAF9] hover:opacity-80 transition-opacity focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#F59E0B] rounded"
            >
              <span>Controls</span>
            </button>
            <button
              type="button"
              onClick={() => setControlsCollapsed((c) => !c)}
              aria-label={controlsCollapsed ? 'Expand controls' : 'Minimize controls'}
              title={controlsCollapsed ? 'Expand' : 'Minimize'}
              className="flex h-7 w-7 items-center justify-center rounded-lg text-[#78716C] dark:text-[#A8A29E] hover:bg-[#F5F5F4] dark:hover:bg-[#292524] hover:text-[#1C1917] dark:hover:text-[#FAFAF9] transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#F59E0B]"
            >
              {controlsCollapsed ? <ChevronDown className="h-4 w-4" /> : <ChevronUp className="h-4 w-4" />}
            </button>
          </div>

          {!controlsCollapsed && (
            <div className="flex flex-col gap-2 pt-1">
              <div className="flex items-center justify-between gap-2 py-1.5 px-2.5 rounded-lg bg-white dark:bg-[#1C1917] border border-[#E7E5E4] dark:border-[#292524]">
                <span className="text-xs font-medium text-[#1C1917] dark:text-[#FAFAF9]">
                  Search filters
                </span>
                <button
                  type="button"
                  role="switch"
                  aria-checked={showSearchControls}
                  aria-label="Search filters"
                  onClick={() => onToggleSearchControls(!showSearchControls)}
                  title={showSearchControls ? 'Disable search filters' : 'Enable search filters'}
                  className={`relative inline-flex h-5 w-9 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#F59E0B] ${
                    showSearchControls ? 'bg-[#F59E0B]' : 'bg-[#E7E5E4] dark:bg-[#292524]'
                  }`}
                >
                  <span
                    className={`pointer-events-none inline-block h-4 w-4 transform rounded-full bg-white shadow ring-0 transition duration-200 ease-in-out ${
                      showSearchControls ? 'translate-x-4' : 'translate-x-0'
                    }`}
                  />
                </button>
              </div>
            </div>
          )}
        </div>

        {/* 3. Library Reload Card */}
        <div className="flex min-h-[48px] items-center justify-between rounded-xl border border-[#E7E5E4] dark:border-[#292524] px-3 py-2 bg-[#F5F5F4]/40 dark:bg-[#0C0A09]/40 mt-3 shrink-0">
          <span className="text-sm font-medium text-[#1C1917] dark:text-[#FAFAF9]">Reload</span>
          <button
            type="button"
            onClick={onReload}
            aria-label="Reload library"
            title="Reload library"
            className="flex h-8 w-8 items-center justify-center rounded-lg text-[#78716C] dark:text-[#A8A29E] hover:bg-[#F5F5F4] dark:hover:bg-[#292524] hover:text-[#1C1917] dark:hover:text-[#FAFAF9] transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#F59E0B]"
          >
            <RotateCw className="h-4 w-4" />
          </button>
        </div>

        {/* 4. Hidden Folders Card */}
        <HiddenFoldersCard
          hiddenFolders={hiddenFolders}
          onAdd={onAddHiddenFolder}
          onRemove={onRemoveHiddenFolder}
          onReset={onResetHiddenFolders}
          availableFolders={availableFolders}
        />
      </div>
    </div>
  );
}
