import { Kind } from '../data/types.ts';
import { extOf } from '../data/fileKinds.ts';

interface FileIconProps {
  name: string;
  kind: Kind;
  width?: number;
  height?: number;
}

const BAND_COLORS: Record<Kind, string> = {
  pdf: '#EF4444',
  image: '#22C55E',
  video: '#8B5CF6',
  audio: '#3B82F6',
  text: '#64748B',
  other: '#9CA3AF',
};

export function FileIcon({ name, kind, width = 72, height = 60 }: FileIconProps) {
  const bandColor = BAND_COLORS[kind] || BAND_COLORS.other;
  const rawExt = extOf(name) || (kind !== 'other' ? kind : 'FILE');
  const extText = rawExt.toUpperCase().slice(0, 4);

  return (
    <svg
      width={width}
      height={height}
      viewBox="0 0 96 80"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className="shrink-0 select-none pointer-events-none"
      aria-hidden="true"
    >
      {/* Page drop shadow / base border */}
      <path
        d="M24 6 h36 l16 16 v50 a4 4 0 0 1 -4 4 H24 a4 4 0 0 1 -4 -4 V10 a4 4 0 0 1 4 -4 z"
        fill="#FFFFFF"
        stroke="#CBD5E1"
        strokeWidth="1.5"
      />

      {/* Folded corner triangle */}
      <path
        d="M60 6 v12 a4 4 0 0 0 4 4 h12 z"
        fill="#E2E8F0"
        stroke="#CBD5E1"
        strokeWidth="1.5"
        strokeLinejoin="round"
      />

      {/* Page subtle lines representing text content */}
      <line x1="28" y1="20" x2="52" y2="20" stroke="#E2E8F0" strokeWidth="2" strokeLinecap="round" />
      <line x1="28" y1="28" x2="68" y2="28" stroke="#E2E8F0" strokeWidth="2" strokeLinecap="round" />
      <line x1="28" y1="36" x2="68" y2="36" stroke="#E2E8F0" strokeWidth="2" strokeLinecap="round" />

      {/* Coloured band */}
      <rect
        x="20.5"
        y="46"
        width="55"
        height="22"
        rx="2"
        fill={bandColor}
      />

      {/* Extension text */}
      <text
        x="48"
        y="61"
        fill="#FFFFFF"
        fontSize="10.5"
        fontWeight="700"
        fontFamily="system-ui, -apple-system, sans-serif"
        textAnchor="middle"
        letterSpacing="0.5"
      >
        {extText}
      </text>
    </svg>
  );
}
