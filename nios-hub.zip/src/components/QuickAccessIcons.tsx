import { QuickAccessTab } from '../hooks/useQuickAccess.ts';

/**
 * Clock / History icon for "Recent Open"
 */
export function RecentClockIcon({ className = 'h-4 w-4' }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      className={className}
      aria-hidden="true"
    >
      <path d="M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8" />
      <path d="M3 3v5h5" />
      <path d="M12 7v5l3.5 2" />
    </svg>
  );
}

/**
 * Folder-with-Star icon for "Starred"
 */
export function StarredFolderIcon({ className = 'h-4 w-4' }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.9"
      strokeLinecap="round"
      strokeLinejoin="round"
      className={className}
      aria-hidden="true"
    >
      <path d="M4 20h16a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2h-7.93a2 2 0 0 1-1.66-.9l-.82-1.2A2 2 0 0 0 7.93 3H4a2 2 0 0 0-2 2v13c0 1.1.9 2 2 2Z" />
      <polygon
        points="12 10.5 13.09 12.71 15.5 13.06 13.75 14.77 14.16 17.17 12 16.03 9.84 17.17 10.25 14.77 8.5 13.06 10.91 12.71 12 10.5"
        fill="currentColor"
      />
    </svg>
  );
}

interface QuickAccessButtonsProps {
  activeTab: QuickAccessTab | null;
  onToggleTab: (tab: QuickAccessTab) => void;
}

export function QuickAccessButtons({ activeTab, onToggleTab }: QuickAccessButtonsProps) {
  const activeCls =
    'bg-[#CCE8FF] dark:bg-[#35507A] text-[#1C1917] dark:text-[#FAFAF9] border border-[#99D1FF] dark:border-[#4A6FA5]';
  const inactiveCls =
    'text-[#78716C] dark:text-[#A8A29E] hover:bg-[#F5F5F4] dark:hover:bg-[#292524] hover:text-[#1C1917] dark:hover:text-[#FAFAF9] border border-transparent';

  return (
    <div className="flex items-center gap-1 rounded-xl border border-[#E7E5E4] dark:border-[#292524] p-0.5 bg-white dark:bg-[#1C1917] shrink-0">
      <button
        type="button"
        onClick={() => onToggleTab('recent')}
        aria-label="Recent Open"
        aria-pressed={activeTab === 'recent'}
        title="Recent Open"
        className={`flex h-8 w-8 items-center justify-center rounded-[8px] transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#F59E0B] ${
          activeTab === 'recent' ? activeCls : inactiveCls
        }`}
      >
        <RecentClockIcon className="h-4 w-4" />
      </button>

      <button
        type="button"
        onClick={() => onToggleTab('starred')}
        aria-label="Starred"
        aria-pressed={activeTab === 'starred'}
        title="Starred"
        className={`flex h-8 w-8 items-center justify-center rounded-[8px] transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#F59E0B] ${
          activeTab === 'starred' ? activeCls : inactiveCls
        }`}
      >
        <StarredFolderIcon className="h-4 w-4" />
      </button>
    </div>
  );
}
