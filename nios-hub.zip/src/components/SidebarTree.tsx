import { UseTreeResult } from '../hooks/useTree.ts';
import { TreeNode } from './TreeNode.tsx';
import { Loader2 } from '../icons/index.ts';

interface SidebarTreeProps {
  tree: UseTreeResult;
  currentPath: string;
  onItemClick?: () => void;
}

export function SidebarTree({ tree, currentPath, onItemClick }: SidebarTreeProps) {
  const {
    rootFolders,
    rootLoading,
    expandedPaths,
    childrenMap,
    loadingMap,
    loadedMap,
    toggleExpand,
  } = tree;

  if (rootLoading) {
    return (
      <div className="flex items-center justify-center py-8 text-[#78716C] dark:text-[#A8A29E]">
        <Loader2 className="h-5 w-5 animate-spin" />
      </div>
    );
  }

  return (
    <nav aria-label="Folder tree" className="flex flex-col py-1.5 w-full">
      {rootFolders.map((folder) => (
        <TreeNode
          key={folder.path}
          folder={folder}
          level={0}
          currentPath={currentPath}
          isExpanded={expandedPaths.has(folder.path)}
          isLoading={Boolean(loadingMap.get(folder.path))}
          isLoaded={Boolean(loadedMap.get(folder.path))}
          childrenFolders={childrenMap.get(folder.path)}
          expandedPaths={expandedPaths}
          loadingMap={loadingMap}
          loadedMap={loadedMap}
          childrenMap={childrenMap}
          onToggle={toggleExpand}
          onItemClick={onItemClick}
        />
      ))}
    </nav>
  );
}
