import React, { useState, useEffect, useRef } from 'react';
import { PanelLeft, Search, X, Loader2, AlertTriangle } from '../icons/index.ts';
import { Kind } from '../data/types.ts';
import { SearchFilterToggles, KindFilterGroup } from './SearchFilterToggles.tsx';
import { QuickAccessButtons } from './QuickAccessIcons.tsx';
import { QuickAccessTab } from '../hooks/useQuickAccess.ts';

interface SearchRowProps {
  query: string;
  onQueryChange: (q: string) => void;
  scopeFolder: string | null;
  activeScope: 'all' | 'folder';
  onScopeChange: (scope: 'all' | 'folder') => void;
  selectedKinds: Set<Kind>;
  onToggleKindGroup: (group: KindFilterGroup) => void;
  building: boolean;
  maybeIncomplete: boolean;
  showPanelButton: boolean;
  onOpenSidebar: () => void;
  onClearOrEsc: () => void;
  onFocusInput?: () => void;
  showControls?: boolean;
  activeQuickTab?: QuickAccessTab | null;
  onToggleQuickTab?: (tab: QuickAccessTab) => void;
}

export function SearchRow({
  query,
  onQueryChange,
  scopeFolder,
  activeScope,
  onScopeChange,
  selectedKinds,
  onToggleKindGroup,
  building,
  maybeIncomplete,
  showPanelButton,
  onOpenSidebar,
  onClearOrEsc,
  onFocusInput,
  showControls = false,
  activeQuickTab = null,
  onToggleQuickTab,
}: SearchRowProps) {
  const [localText, setLocalText] = useState(query);
  const inputRef = useRef<HTMLInputElement>(null);
  const debounceTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => {
    setLocalText(query);
  }, [query]);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = e.target.value;
    setLocalText(val);

    if (debounceTimerRef.current) {
      clearTimeout(debounceTimerRef.current);
    }
    debounceTimerRef.current = setTimeout(() => {
      onQueryChange(val);
    }, 120);
  };

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      const activeEl = document.activeElement;
      const isInputFocused =
        activeEl &&
        (activeEl.tagName === 'INPUT' ||
          activeEl.tagName === 'TEXTAREA' ||
          (activeEl as HTMLElement).isContentEditable);

      if ((e.key === 'k' || e.key === 'K') && (e.ctrlKey || e.metaKey)) {
        e.preventDefault();
        inputRef.current?.focus();
        onFocusInput?.();
        return;
      }

      if (e.key === '/' && !isInputFocused) {
        e.preventDefault();
        inputRef.current?.focus();
        onFocusInput?.();
        return;
      }

      if (e.key === 'Escape' && isInputFocused) {
        e.preventDefault();
        setLocalText('');
        inputRef.current?.blur();
        onClearOrEsc();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      if (debounceTimerRef.current) clearTimeout(debounceTimerRef.current);
    };
  }, [onClearOrEsc, onFocusInput]);

  const handleClear = () => {
    setLocalText('');
    onClearOrEsc();
    inputRef.current?.focus();
  };

  const isScopeEnabled = Boolean(scopeFolder);

  return (
    <div className="w-full flex flex-col gap-2 mb-4 shrink-0">
      <div className="flex items-center gap-1.5 sm:gap-2 w-full min-h-[40px]">
        {/* PanelLeft button when sidebar is collapsed */}
        {showPanelButton && (
          <button
            type="button"
            onClick={onOpenSidebar}
            aria-label="Open sidebar"
            title="Open sidebar"
            className="flex h-9 w-9 shrink-0 items-center justify-center rounded-[8px] text-[#78716C] dark:text-[#A8A29E] hover:bg-[#F5F5F4] dark:hover:bg-[#292524] hover:text-[#1C1917] dark:hover:text-[#FAFAF9] transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#F59E0B]"
          >
            <PanelLeft className="h-5 w-5" />
          </button>
        )}

        {/* Search Input: pill shape */}
        <div className="relative flex-1 min-w-0 max-w-[560px] flex items-center">
          <Search className="absolute left-3.5 h-4 w-4 text-[#78716C] dark:text-[#A8A29E] pointer-events-none select-none" />
          <input
            ref={inputRef}
            type="text"
            value={localText}
            onChange={handleInputChange}
            onFocus={onFocusInput}
            placeholder="Search"
            className="w-full h-10 pl-9 pr-14 text-[13px] rounded-[20px] border border-[#E7E5E4] dark:border-[#292524] bg-white dark:bg-[#1C1917] text-[#1C1917] dark:text-[#FAFAF9] placeholder-[#78716C] dark:placeholder-[#A8A29E] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#F59E0B] transition-colors"
          />

          <div className="absolute right-2.5 flex items-center gap-1">
            {maybeIncomplete && (
              <span
                title="List may be incomplete"
                aria-label="List may be incomplete"
                className="flex items-center text-[#F59E0B]"
              >
                <AlertTriangle className="h-4 w-4" />
              </span>
            )}

            {localText ? (
              <button
                type="button"
                onClick={handleClear}
                aria-label="Clear search"
                title="Clear"
                className="flex h-6 w-6 items-center justify-center rounded-full text-[#78716C] dark:text-[#A8A29E] hover:text-[#1C1917] dark:hover:text-[#FAFAF9] hover:bg-black/5 dark:hover:bg-white/5 transition-colors focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-[#F59E0B]"
              >
                <X className="h-3.5 w-3.5" />
              </button>
            ) : building ? (
              <span title="Indexing" aria-label="Indexing" className="flex items-center text-[#78716C] dark:text-[#A8A29E]">
                <Loader2 className="h-4 w-4 animate-spin" />
              </span>
            ) : null}
          </div>
        </div>

        {/* Desktop Toggles (hidden on mobile < 640px, or if showControls is off) */}
        {showControls && (
          <div className="hidden md:flex items-center gap-2 shrink-0">
            <SearchFilterToggles
              isScopeEnabled={isScopeEnabled}
              activeScope={activeScope}
              onScopeChange={onScopeChange}
              selectedKinds={selectedKinds}
              onToggleKindGroup={onToggleKindGroup}
            />
          </div>
        )}

        {/* Quick Access Buttons (Recent Open & Starred) aligned to the right */}
        {onToggleQuickTab && (
          <div className="ml-auto flex items-center shrink-0">
            <QuickAccessButtons activeTab={activeQuickTab} onToggleTab={onToggleQuickTab} />
          </div>
        )}
      </div>

      {/* Mobile Toggles: row 2 below 768px if showControls is on */}
      {showControls && (
        <div className="flex md:hidden items-center gap-2 overflow-x-auto pb-1">
          <SearchFilterToggles
            isScopeEnabled={isScopeEnabled}
            activeScope={activeScope}
            onScopeChange={onScopeChange}
            selectedKinds={selectedKinds}
            onToggleKindGroup={onToggleKindGroup}
            isMobileCompact
          />
        </div>
      )}
    </div>
  );
}
