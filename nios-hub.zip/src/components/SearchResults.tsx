import { useState, useEffect, useRef } from 'react';
import { SearchEntry } from '../search/rank.ts';
import { Kind } from '../data/types.ts';
import { folderHref } from '../router/hashRoute.ts';
import { fileLinkProps } from '../lib/fileLink.ts';
import { FolderIcon } from './FolderIcon.tsx';
import { FileIcon } from './FileIcon.tsx';
import { HighlightText } from './HighlightText.tsx';
import { Search, AlertCircle, RotateCw, Star } from '../icons/index.ts';

interface SearchResultsProps {
  entries: SearchEntry[];
  query: string;
  ready: boolean;
  building: boolean;
  error: boolean;
  onRetry?: () => void;
  onFolderClick?: () => void;
  isStarred?: (path: string) => boolean;
  onToggleStar?: (item: { name: string; path: string; isFolder: boolean; kind: Kind }) => void;
}

const PAGE_SIZE = 60;

function formatParentPath(fullPath: string): string {
  const segments = fullPath.split('/');
  if (segments.length <= 1) return 'Home';
  return segments.slice(0, -1).join(' › ');
}

export function SearchResults({
  entries,
  query,
  ready,
  building,
  error,
  onRetry,
  onFolderClick,
  isStarred,
  onToggleStar,
}: SearchResultsProps) {
  const [visibleCount, setVisibleCount] = useState(PAGE_SIZE);
  const sentinelRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    setVisibleCount(PAGE_SIZE);
  }, [query, entries]);

  useEffect(() => {
    if (visibleCount >= entries.length) return;

    const observer = new IntersectionObserver(
      (observerEntries) => {
        if (observerEntries[0].isIntersecting) {
          setVisibleCount((prev) => Math.min(prev + PAGE_SIZE, entries.length));
        }
      },
      { rootMargin: '200px' }
    );

    const el = sentinelRef.current;
    if (el) observer.observe(el);

    return () => {
      if (el) observer.unobserve(el);
    };
  }, [visibleCount, entries.length]);

  if (error && !ready) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[240px] sm:min-h-[300px] gap-3 text-center">
        <AlertCircle className="h-10 w-10 text-[#EF4444]" />
        <span className="text-[15px] font-medium text-[#78716C] dark:text-[#A8A29E]">
          Could not load
        </span>
        {onRetry && (
          <button
            type="button"
            onClick={onRetry}
            aria-label="Retry search indexing"
            title="Retry"
            className="flex h-9 w-9 items-center justify-center rounded-[8px] text-[#78716C] dark:text-[#A8A29E] hover:bg-[#F5F5F4] dark:hover:bg-[#292524] hover:text-[#1C1917] dark:hover:text-[#FAFAF9] transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#F59E0B]"
          >
            <RotateCw className="h-5 w-5" />
          </button>
        )}
      </div>
    );
  }

  if (!ready || (building && entries.length === 0)) {
    return (
      <div className="grid w-full items-start gap-3 sm:gap-5 grid-cols-[repeat(auto-fill,minmax(96px,1fr))] sm:grid-cols-[repeat(auto-fill,minmax(112px,1fr))]">
        {Array.from({ length: 12 }).map((_, index) => (
          <div
            key={index}
            className="flex flex-col items-center justify-start p-2 rounded-[4px] border border-transparent"
          >
            <div className="w-[72px] h-[60px] rounded-lg bg-[#E7E5E4] dark:bg-[#292524] animate-pulse" />
          </div>
        ))}
      </div>
    );
  }

  if (entries.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[240px] sm:min-h-[300px] gap-2 text-center select-none">
        <Search className="h-10 w-10 text-[#78716C] dark:text-[#A8A29E]" />
        <span className="text-[15px] font-medium text-[#78716C] dark:text-[#A8A29E]">
          No results
        </span>
      </div>
    );
  }

  const visibleEntries = entries.slice(0, visibleCount);

  return (
    <div className="flex flex-col w-full">
      <div className="grid w-full items-start gap-3 sm:gap-5 grid-cols-[repeat(auto-fill,minmax(96px,1fr))] sm:grid-cols-[repeat(auto-fill,minmax(112px,1fr))]">
        {visibleEntries.map((entry) => {
          const parentPath = formatParentPath(entry.path);
          const starred = isStarred ? isStarred(entry.path) : false;
          const href = entry.isFolder ? folderHref(entry.path) : fileLinkProps(entry.path).href;

          return (
            <div key={entry.path} className="group relative flex flex-col items-center min-w-0">
              <a
                href={href}
                onClick={entry.isFolder ? onFolderClick : undefined}
                title={entry.path}
                className="flex flex-col items-center justify-start w-full p-2 rounded-[4px] border border-transparent group-hover:bg-[#E5F3FF] dark:group-hover:bg-[#2B3A4F] group-hover:border-[#CCE8FF] dark:group-hover:border-[#35507A] text-center transition-colors duration-150 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#F59E0B] focus-visible:ring-offset-1 select-none min-w-0"
              >
                {entry.isFolder ? (
                  <FolderIcon />
                ) : (
                  <FileIcon name={entry.name} kind={entry.kind} />
                )}
                <span className="mt-1 text-[12px] sm:text-[13px] font-normal leading-snug text-[#1C1917] dark:text-[#FAFAF9] line-clamp-2 w-full break-words [overflow-wrap:anywhere]">
                  <HighlightText text={entry.name} query={query} />
                </span>
                <span
                  title={entry.path}
                  className="mt-0.5 text-[11px] font-normal text-[#78716C] dark:text-[#A8A29E] truncate w-full"
                >
                  {parentPath}
                </span>
              </a>

              {onToggleStar && (
                <button
                  type="button"
                  onClick={(e) => {
                    e.preventDefault();
                    e.stopPropagation();
                    onToggleStar(entry);
                  }}
                  aria-label={starred ? `Unstar ${entry.name}` : `Star ${entry.name}`}
                  title={starred ? 'Remove from Starred' : 'Add to Starred'}
                  className={`absolute top-1 right-1 z-10 flex h-6 w-6 items-center justify-center rounded-full transition-all focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#F59E0B] ${
                    starred
                      ? 'opacity-100 text-[#F59E0B] bg-white/90 dark:bg-[#1C1917]/90 shadow-xs'
                      : 'opacity-70 sm:opacity-0 sm:group-hover:opacity-100 focus-visible:opacity-100 text-[#78716C] dark:text-[#A8A29E] hover:text-[#F59E0B] bg-white/80 dark:bg-[#1C1917]/80'
                  }`}
                >
                  <Star className={`h-3.5 w-3.5 ${starred ? 'fill-current' : ''}`} />
                </button>
              )}
            </div>
          );
        })}
      </div>

      {visibleCount < entries.length && <div ref={sentinelRef} className="h-10 w-full" />}
    </div>
  );
}
