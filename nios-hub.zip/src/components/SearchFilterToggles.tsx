import { Globe, Folder, FileText, Image, Film, File } from '../icons/index.ts';
import { Kind } from '../data/types.ts';

export type KindFilterGroup = 'pdf' | 'image' | 'media' | 'doc';

interface SearchFilterTogglesProps {
  isScopeEnabled: boolean;
  activeScope: 'all' | 'folder';
  onScopeChange: (scope: 'all' | 'folder') => void;
  selectedKinds: Set<Kind>;
  onToggleKindGroup: (group: KindFilterGroup) => void;
  isMobileCompact?: boolean;
}

export function SearchFilterToggles({
  isScopeEnabled,
  activeScope,
  onScopeChange,
  selectedKinds,
  onToggleKindGroup,
  isMobileCompact = false,
}: SearchFilterTogglesProps) {
  const isPdfActive = selectedKinds.has('pdf');
  const isImageActive = selectedKinds.has('image');
  const isMediaActive = selectedKinds.has('video') || selectedKinds.has('audio');
  const isDocActive = selectedKinds.has('text') || selectedKinds.has('other');

  const btnSize = isMobileCompact ? 'h-7 w-7' : 'h-8 w-8';
  const iconSize = isMobileCompact ? 'h-3.5 w-3.5' : 'h-4 w-4';

  const activeCls =
    'bg-[#CCE8FF] dark:bg-[#35507A] text-[#1C1917] dark:text-[#FAFAF9] border border-[#99D1FF] dark:border-[#4A6FA5]';
  const inactiveCls = 'text-[#78716C] dark:text-[#A8A29E] hover:bg-white dark:hover:bg-[#1C1917]';

  return (
    <div className="flex items-center gap-2">
      {/* Scope Toggle Group */}
      <div className="flex items-center rounded-lg border border-[#E7E5E4] dark:border-[#292524] p-0.5 bg-[#F5F5F4]/50 dark:bg-[#0C0A09]/50">
        <button
          type="button"
          onClick={() => onScopeChange('all')}
          aria-label="Search all folders"
          title="All folders"
          className={`flex ${btnSize} items-center justify-center rounded-[6px] transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#F59E0B] ${
            activeScope === 'all' ? activeCls : inactiveCls
          }`}
        >
          <Globe className={iconSize} />
        </button>
        <button
          type="button"
          disabled={!isScopeEnabled}
          onClick={() => onScopeChange('folder')}
          aria-label="Search current folder"
          title={isScopeEnabled ? 'Current folder' : 'Current folder (open a folder first)'}
          className={`flex ${btnSize} items-center justify-center rounded-[6px] transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#F59E0B] ${
            !isScopeEnabled
              ? 'opacity-40 cursor-not-allowed text-[#78716C] dark:text-[#A8A29E]'
              : activeScope === 'folder'
              ? activeCls
              : inactiveCls
          }`}
        >
          <Folder className={iconSize} />
        </button>
      </div>

      {/* Kind Filter Group */}
      <div className="flex items-center rounded-lg border border-[#E7E5E4] dark:border-[#292524] p-0.5 bg-[#F5F5F4]/50 dark:bg-[#0C0A09]/50">
        <button
          type="button"
          onClick={() => onToggleKindGroup('pdf')}
          aria-label="PDF files"
          title="PDF"
          className={`flex ${btnSize} items-center justify-center rounded-[6px] transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#F59E0B] ${
            isPdfActive ? activeCls : inactiveCls
          }`}
        >
          <FileText className={iconSize} />
        </button>
        <button
          type="button"
          onClick={() => onToggleKindGroup('image')}
          aria-label="Images"
          title="Images"
          className={`flex ${btnSize} items-center justify-center rounded-[6px] transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#F59E0B] ${
            isImageActive ? activeCls : inactiveCls
          }`}
        >
          <Image className={iconSize} />
        </button>
        <button
          type="button"
          onClick={() => onToggleKindGroup('media')}
          aria-label="Video and audio"
          title="Videos & Audio"
          className={`flex ${btnSize} items-center justify-center rounded-[6px] transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#F59E0B] ${
            isMediaActive ? activeCls : inactiveCls
          }`}
        >
          <Film className={iconSize} />
        </button>
        <button
          type="button"
          onClick={() => onToggleKindGroup('doc')}
          aria-label="Text and other files"
          title="Documents & Other"
          className={`flex ${btnSize} items-center justify-center rounded-[6px] transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#F59E0B] ${
            isDocActive ? activeCls : inactiveCls
          }`}
        >
          <File className={iconSize} />
        </button>
      </div>
    </div>
  );
}
