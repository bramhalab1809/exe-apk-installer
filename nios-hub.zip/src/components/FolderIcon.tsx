import { useId } from 'react';

export function FolderIcon() {
  const uniqueId = useId();
  const backGradientId = `folder-back-${uniqueId}`;
  const frontGradientId = `folder-front-${uniqueId}`;

  return (
    <svg
      width="72"
      height="60"
      viewBox="0 0 96 80"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className="shrink-0 select-none pointer-events-none"
      aria-hidden="true"
    >
      <defs>
        <linearGradient id={backGradientId} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#F7C948" />
          <stop offset="100%" stopColor="#E8A317" />
        </linearGradient>
        <linearGradient id={frontGradientId} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#FFE08A" />
          <stop offset="100%" stopColor="#FBBF24" />
        </linearGradient>
      </defs>

      {/* 1. Back panel with tab */}
      <path
        d="M6 12a6 6 0 0 1 6-6h20a6 6 0 0 1 4.5 2L42 14h42a6 6 0 0 1 6 6v50a6 6 0 0 1-6 6H12a6 6 0 0 1-6-6z"
        fill={`url(#${backGradientId})`}
      />

      {/* 2. Paper sliver */}
      <rect
        x="12"
        y="18"
        width="72"
        height="14"
        rx="2"
        fill="#FFFFFF"
        opacity="0.85"
      />

      {/* 3. Front panel */}
      <rect
        x="6"
        y="26"
        width="84"
        height="50"
        rx="6"
        fill={`url(#${frontGradientId})`}
      />

      {/* 4. Top highlight on the front panel */}
      <rect
        x="6"
        y="26"
        width="84"
        height="2"
        fill="#FFF3C4"
        opacity="0.7"
      />
    </svg>
  );
}
