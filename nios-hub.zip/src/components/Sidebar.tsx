import React from 'react';
import { Settings, ChevronLeft } from '../icons/index.ts';
import { SidebarTree } from './SidebarTree.tsx';
import { UseTreeResult } from '../hooks/useTree.ts';

interface SidebarProps {
  isMobile: boolean;
  isOpen: boolean;
  onClose: () => void;
  onOpenSettings: () => void;
  gearButtonRef: React.RefObject<HTMLButtonElement | null>;
  tree: UseTreeResult;
  currentPath: string;
}

export function Sidebar({
  isMobile,
  isOpen,
  onClose,
  onOpenSettings,
  gearButtonRef,
  tree,
  currentPath,
}: SidebarProps) {
  // Mobile drawer rendering
  if (isMobile) {
    return (
      <>
        {/* Dim Backdrop */}
        <div
          className={`fixed inset-0 z-40 bg-black/40 backdrop-blur-[1px] transition-opacity duration-200 ${
            isOpen ? 'opacity-100 pointer-events-auto' : 'opacity-0 pointer-events-none'
          }`}
          onClick={onClose}
          aria-hidden="true"
        />

        {/* Slide-over Drawer */}
        <aside
          role="complementary"
          aria-label="Sidebar navigation"
          className={`fixed top-3 bottom-3 left-3 z-50 flex flex-col w-[min(288px,85vw)] rounded-[16px] border border-[#E7E5E4] dark:border-[#292524] bg-white dark:bg-[#1C1917] shadow-lg transition-transform duration-200 ease-in-out ${
            isOpen ? 'translate-x-0' : '-translate-x-[120%]'
          }`}
        >
          {/* Header Row */}
          <div className="flex h-12 items-center justify-between px-2 shrink-0 border-b border-transparent">
            <a
              href="#/"
              onClick={onClose}
              title="Explore (Root)"
              className="text-[16px] font-semibold text-[#1C1917] dark:text-[#FAFAF9] select-none pl-2 no-underline hover:opacity-80 transition-opacity focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#F59E0B] rounded"
            >
              Explore
            </a>
            <div className="flex items-center gap-1">
              <button
                ref={gearButtonRef}
                type="button"
                onClick={onOpenSettings}
                aria-label="Settings"
                title="Settings"
                className="flex h-9 w-9 items-center justify-center rounded-[8px] text-[#78716C] dark:text-[#A8A29E] hover:bg-[#F5F5F4] dark:hover:bg-[#292524] hover:text-[#1C1917] dark:hover:text-[#FAFAF9] transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#F59E0B]"
              >
                <Settings className="h-5 w-5" />
              </button>
              <button
                type="button"
                onClick={onClose}
                aria-label="Collapse sidebar"
                title="Collapse sidebar"
                className="flex h-9 w-9 items-center justify-center rounded-[8px] text-[#78716C] dark:text-[#A8A29E] hover:bg-[#F5F5F4] dark:hover:bg-[#292524] hover:text-[#1C1917] dark:hover:text-[#FAFAF9] transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#F59E0B]"
              >
                <ChevronLeft className="h-5 w-5" />
              </button>
            </div>
          </div>

          {/* Body: scrollable tree navigation */}
          <div className="flex-1 overflow-y-auto px-1">
            <SidebarTree tree={tree} currentPath={currentPath} onItemClick={onClose} />
          </div>
        </aside>
      </>
    );
  }

  // Desktop sidebar rendering
  return (
    <aside
      role="complementary"
      aria-label="Sidebar navigation"
      aria-hidden={!isOpen}
      className={`h-full flex flex-col rounded-[16px] bg-white dark:bg-[#1C1917] transition-all duration-200 ease-in-out overflow-hidden ${
        isOpen
          ? 'w-[288px] min-w-[288px] opacity-100 border border-[#E7E5E4] dark:border-[#292524]'
          : 'w-0 min-w-0 opacity-0 border-0 p-0 -mr-3 pointer-events-none'
      }`}
    >
      {/* Header Row */}
      <div className="flex h-12 w-[288px] items-center justify-between px-2 shrink-0">
        <a
          href="#/"
          title="Explore (Root)"
          className="text-[16px] font-semibold text-[#1C1917] dark:text-[#FAFAF9] select-none pl-2 no-underline hover:opacity-80 transition-opacity focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#F59E0B] rounded"
        >
          Explore
        </a>
        <div className="flex items-center gap-1">
          <button
            ref={gearButtonRef}
            type="button"
            onClick={onOpenSettings}
            aria-label="Settings"
            title="Settings"
            className="flex h-9 w-9 items-center justify-center rounded-[8px] text-[#78716C] dark:text-[#A8A29E] hover:bg-[#F5F5F4] dark:hover:bg-[#292524] hover:text-[#1C1917] dark:hover:text-[#FAFAF9] transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#F59E0B]"
          >
            <Settings className="h-5 w-5" />
          </button>
          <button
            type="button"
            onClick={onClose}
            aria-label="Collapse sidebar"
            title="Collapse sidebar"
            className="flex h-9 w-9 items-center justify-center rounded-[8px] text-[#78716C] dark:text-[#A8A29E] hover:bg-[#F5F5F4] dark:hover:bg-[#292524] hover:text-[#1C1917] dark:hover:text-[#FAFAF9] transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#F59E0B]"
          >
            <ChevronLeft className="h-5 w-5" />
          </button>
        </div>
      </div>

      {/* Body: scrollable tree navigation */}
      <div className="flex-1 w-[288px] overflow-y-auto px-1">
        <SidebarTree tree={tree} currentPath={currentPath} />
      </div>
    </aside>
  );
}
