import React from 'react';

interface HighlightTextProps {
  text: string;
  query: string;
  className?: string;
}

export function HighlightText({ text, query, className }: HighlightTextProps) {
  const trimmed = query.trim();
  if (!trimmed) {
    return <span className={className}>{text}</span>;
  }

  const tokens = trimmed
    .split(/\s+/)
    .filter(Boolean)
    .map((t) => t.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'));

  if (tokens.length === 0) {
    return <span className={className}>{text}</span>;
  }

  const splitRegex = new RegExp(`(${tokens.join('|')})`, 'gi');
  const matchRegex = new RegExp(`^(${tokens.join('|')})$`, 'i');
  const parts = text.split(splitRegex);

  return (
    <span className={className}>
      {parts.map((part, index) => {
        if (matchRegex.test(part)) {
          return (
            <strong key={index} className="font-semibold text-[#1C1917] dark:text-[#FAFAF9]">
              {part}
            </strong>
          );
        }
        return <React.Fragment key={index}>{part}</React.Fragment>;
      })}
    </span>
  );
}
