import { Entry } from '../data/types.ts';
import { folderHref } from '../router/hashRoute.ts';
import { ChevronRight, Loader2 } from '../icons/index.ts';

interface TreeNodeProps {
  folder: Entry;
  level: number;
  currentPath: string;
  isExpanded: boolean;
  isLoading: boolean;
  isLoaded: boolean;
  childrenFolders?: Entry[];
  expandedPaths: Set<string>;
  loadingMap: Map<string, boolean>;
  loadedMap: Map<string, boolean>;
  childrenMap: Map<string, Entry[]>;
  onToggle: (path: string) => void;
  onItemClick?: () => void;
}

export function TreeNode({
  folder,
  level,
  currentPath,
  isExpanded,
  isLoading,
  isLoaded,
  childrenFolders = [],
  expandedPaths,
  loadingMap,
  loadedMap,
  childrenMap,
  onToggle,
  onItemClick,
}: TreeNodeProps) {
  const isViewer = currentPath.startsWith('v:');
  const activePath = isViewer ? currentPath.slice(2) : currentPath;
  const isSelected = isViewer
    ? activePath === folder.path || activePath.startsWith(`${folder.path}/`)
    : activePath === folder.path || (!activePath && folder.path === 'Home');
  const hasNoChildren = isLoaded && childrenFolders.length === 0;

  return (
    <div className="flex flex-col w-full">
      <div
        className="flex items-center h-8 w-full pr-1.5 select-none"
        style={{ paddingLeft: `${level * 12 + 4}px` }}
      >
        {/* Toggle chevron or loading spinner */}
        <div className="flex items-center justify-center w-5 h-5 shrink-0 mr-1">
          {isLoading ? (
            <Loader2 className="h-3.5 w-3.5 animate-spin text-[#78716C] dark:text-[#A8A29E]" />
          ) : hasNoChildren ? (
            <span className="w-5" />
          ) : (
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                onToggle(folder.path);
              }}
              aria-label={isExpanded ? 'Collapse folder' : 'Expand folder'}
              title={isExpanded ? 'Collapse' : 'Expand'}
              className="flex h-5 w-5 items-center justify-center rounded text-[#78716C] dark:text-[#A8A29E] hover:bg-black/5 dark:hover:bg-white/5 transition-transform focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-[#F59E0B]"
            >
              <ChevronRight
                className={`h-3.5 w-3.5 transition-transform duration-150 ${
                  isExpanded ? 'rotate-90' : ''
                }`}
              />
            </button>
          )}
        </div>

        {/* Folder link */}
        <a
          href={folderHref(folder.path)}
          onClick={onItemClick}
          title={folder.name}
          className={`flex-1 flex items-center gap-1.5 min-w-0 h-7 px-1.5 rounded-[4px] text-[13px] truncate transition-colors focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-[#F59E0B] ${
            isSelected
              ? 'bg-[#CCE8FF] dark:bg-[#35507A] font-medium text-[#1C1917] dark:text-[#FAFAF9]'
              : 'text-[#1C1917] dark:text-[#FAFAF9] hover:bg-[#E5F3FF] dark:hover:bg-[#2B3A4F]'
          }`}
        >
          {/* Small 18px yellow folder glyph */}
          <svg
            width="18"
            height="15"
            viewBox="0 0 24 20"
            fill="none"
            className="shrink-0 select-none pointer-events-none"
            aria-hidden="true"
          >
            <path d="M2 4a2 2 0 0 1 2-2h5l2 2h9a2 2 0 0 1 2 2v2H2V4z" fill="#E8A317" />
            <rect x="2" y="6" width="20" height="12" rx="2" fill="#FBBF24" />
            <rect x="2" y="6" width="20" height="1" fill="#FFF3C4" opacity="0.6" />
          </svg>
          <span className="truncate">{folder.name}</span>
        </a>
      </div>

      {/* Children */}
      {isExpanded && childrenFolders.length > 0 && (
        <div className="flex flex-col w-full">
          {childrenFolders.map((child) => (
            <TreeNode
              key={child.path}
              folder={child}
              level={level + 1}
              currentPath={currentPath}
              isExpanded={expandedPaths.has(child.path)}
              isLoading={Boolean(loadingMap.get(child.path))}
              isLoaded={Boolean(loadedMap.get(child.path))}
              childrenFolders={childrenMap.get(child.path)}
              expandedPaths={expandedPaths}
              loadingMap={loadingMap}
              loadedMap={loadedMap}
              childrenMap={childrenMap}
              onToggle={onToggle}
              onItemClick={onItemClick}
            />
          ))}
        </div>
      )}
    </div>
  );
}
