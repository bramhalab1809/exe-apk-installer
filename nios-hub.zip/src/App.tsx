import { useState, useRef, useEffect, useMemo } from 'react';
import { AlertTriangle } from './icons/index.ts';
import { Sidebar } from './components/Sidebar.tsx';
import { QuickAccessSidebar } from './components/QuickAccessSidebar.tsx';
import { FolderGrid } from './components/FolderGrid.tsx';
import { FolderPathBar } from './components/FolderPathBar.tsx';
import { SearchRow } from './components/SearchRow.tsx';
import { SearchResults } from './components/SearchResults.tsx';
import { SettingsDialog } from './components/SettingsDialog.tsx';
import { FileViewer } from './viewer/FileViewer.tsx';
import { usePrefs } from './hooks/usePrefs.ts';
import { useSidebar } from './hooks/useSidebar.ts';
import { useQuickAccess } from './hooks/useQuickAccess.ts';
import { useHashRoute } from './router/useHashRoute.ts';
import { useFolder } from './hooks/useFolder.ts';
import { useTree } from './hooks/useTree.ts';
import { useSearchIndex } from './search/useSearchIndex.ts';
import { search } from './search/rank.ts';
import { filterHidden } from './data/sortAndHide.ts';
import { clearAllCaches } from './data/folderCache.ts';
import { kindOf } from './data/fileKinds.ts';
import { useKindFilter } from './hooks/useKindFilter.ts';
import { useSearchNav } from './hooks/useSearchNav.ts';
import { useNativeBack } from './hooks/useNativeBack.ts';
import { useScrollRestoration } from './hooks/useScrollRestoration.ts';

export default function App() {
  const route = useHashRoute();
  const searchNav = useSearchNav(route);
  const { isSearch } = searchNav;
  const isViewer = route.type === 'viewer';

  const {
    theme,
    setTheme,
    hiddenFolders,
    addHiddenFolder,
    removeHiddenFolder,
    resetHiddenFolders,
    showSearchControls,
    setShowSearchControls,
  } = usePrefs();

  const { isMobile, isOpen, openSidebar, closeSidebar } = useSidebar();
  const quickAccess = useQuickAccess();
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const gearButtonRef = useRef<HTMLButtonElement | null>(null);
  const mainRef = useRef<HTMLElement | null>(null);
  const { selectedKinds, toggleKindGroup } = useKindFilter();

  const currentFolderPath = isSearch ? '' : route.folderPath;
  const { entries, status, stale, refresh } = useFolder(currentFolderPath);

  const treeExpandPath = isSearch ? '__search_active__' : isViewer ? route.filePath : route.folderPath;
  const sidebarCurrentPath = isSearch ? '__search_active__' : isViewer ? `v:${route.filePath}` : route.folderPath;
  const tree = useTree(treeExpandPath, hiddenFolders);
  const searchIndex = useSearchIndex(status === 'ready');

  // Handle hardware Back button and mobile modal stack navigation
  useNativeBack({
    isSettingsOpen,
    onCloseSettings: () => setIsSettingsOpen(false),
    isSidebarOpen: isOpen,
    isMobile,
    onCloseSidebar: closeSidebar,
    activeQuickTab: quickAccess.activeTab,
    onCloseQuickAccess: quickAccess.closePanel,
    route,
    onClearSearch: searchNav.handleClearOrEsc,
  });

  // Record visited folders and files in Recent Open
  useEffect(() => {
    if (route.type === 'viewer' && route.filePath) {
      const name = route.filePath.split('/').pop() || route.filePath;
      quickAccess.recordRecent({ name, path: route.filePath, isFolder: false, kind: kindOf(name) });
    } else if (route.type === 'folder' && route.folderPath && route.folderPath !== 'Home') {
      const name = route.folderPath.split('/').pop() || route.folderPath;
      quickAccess.recordRecent({ name, path: route.folderPath, isFolder: true, kind: 'other' });
    }
  }, [route.type, route.filePath, route.folderPath, quickAccess.recordRecent]);

  const visibleFolderEntries = useMemo(() => filterHidden(entries, hiddenFolders), [entries, hiddenFolders]);

  const availableFolders = useMemo(() => {
    const set = new Set<string>(['About me', 'Nios_Syllabus']);
    searchIndex.entries.forEach((e) => e.isFolder && e.name && set.add(e.name));
    return Array.from(set).sort((a, b) => a.localeCompare(b, undefined, { numeric: true, sensitivity: 'base' }));
  }, [searchIndex.entries]);

  const searchResults = useMemo(() => {
    if (!isSearch || !route.query.trim()) return [];
    const scope = searchNav.activeScope === 'folder' ? searchNav.currentScopeFolder : null;
    return search(searchIndex.entries, route.query, { kinds: selectedKinds, scopeFolder: scope, hidden: hiddenFolders });
  }, [isSearch, route.query, searchNav.activeScope, searchNav.currentScopeFolder, searchIndex.entries, selectedKinds, hiddenFolders]);

  const { handleScroll } = useScrollRestoration(mainRef, route.type, route.folderPath, status);

  const handleReload = async () => {
    clearAllCaches();
    refresh();
    tree.resetTree();
    await searchIndex.rebuild();
  };

  const showPanelButton = isMobile || !isOpen;

  return (
    <div className="flex h-dvh w-full flex-row p-2 sm:p-3 pt-[max(0.5rem,env(safe-area-inset-top,0px))] pb-[max(0.5rem,env(safe-area-inset-bottom,0px))] pl-[max(0.5rem,env(safe-area-inset-left,0px))] pr-[max(0.5rem,env(safe-area-inset-right,0px))] gap-2 sm:gap-3 bg-[#F5F5F4] dark:bg-[#0C0A09] text-[#1C1917] dark:text-[#FAFAF9] overflow-hidden select-none">
      {/* LEFT box: Explore Sidebar */}
      <Sidebar
        isMobile={isMobile}
        isOpen={isOpen}
        onClose={closeSidebar}
        onOpenSettings={() => setIsSettingsOpen(true)}
        gearButtonRef={gearButtonRef}
        tree={tree}
        currentPath={sidebarCurrentPath}
      />

      {/* CENTER box: Main area */}
      <main
        ref={mainRef}
        role="main"
        onScroll={handleScroll}
        className={`relative flex-1 min-w-0 h-full rounded-[16px] border border-[#E7E5E4] dark:border-[#292524] bg-white dark:bg-[#1C1917] ${
          isViewer ? 'flex flex-col overflow-hidden p-0' : 'p-3 sm:p-6 overflow-y-auto overflow-x-hidden'
        }`}
      >
        {isViewer ? (
          <FileViewer
            path={route.filePath}
            isStarred={quickAccess.isStarred(route.filePath)}
            onToggleStar={quickAccess.toggleStar}
          />
        ) : (
          <>
            {!isSearch && stale && (
              <div
                className="absolute top-4 right-4 z-10 flex items-center justify-center text-[#F59E0B]"
                title="Offline copy"
                aria-label="Offline copy"
              >
                <AlertTriangle className="h-5 w-5" />
              </div>
            )}

            <SearchRow
              query={isSearch ? route.query : ''}
              onQueryChange={searchNav.handleQueryChange}
              scopeFolder={searchNav.currentScopeFolder}
              activeScope={searchNav.activeScope}
              onScopeChange={searchNav.handleScopeChange}
              selectedKinds={selectedKinds}
              onToggleKindGroup={toggleKindGroup}
              building={searchIndex.building}
              maybeIncomplete={searchIndex.maybeIncomplete}
              showPanelButton={showPanelButton}
              onOpenSidebar={openSidebar}
              onClearOrEsc={searchNav.handleClearOrEsc}
              onFocusInput={searchIndex.triggerImmediateBuild}
              showControls={showSearchControls}
              activeQuickTab={quickAccess.activeTab}
              onToggleQuickTab={quickAccess.toggleTab}
            />

            {isSearch ? (
              <SearchResults
                entries={searchResults}
                query={route.query}
                ready={searchIndex.ready}
                building={searchIndex.building}
                error={searchIndex.error}
                onRetry={searchIndex.triggerImmediateBuild}
                onFolderClick={searchNav.handleClearOrEsc}
                isStarred={quickAccess.isStarred}
                onToggleStar={quickAccess.toggleStar}
              />
            ) : (
              <>
                <FolderPathBar folderPath={route.folderPath} />
                <FolderGrid
                  entries={visibleFolderEntries}
                  status={status}
                  onRetry={refresh}
                  isStarred={quickAccess.isStarred}
                  onToggleStar={quickAccess.toggleStar}
                />
              </>
            )}
          </>
        )}
      </main>

      {/* RIGHT box: Quick Access Panel */}
      <QuickAccessSidebar
        isMobile={isMobile}
        activeTab={quickAccess.activeTab}
        onSelectTab={quickAccess.setActiveTab}
        onClose={quickAccess.closePanel}
        recentItems={quickAccess.recentItems}
        starredItems={quickAccess.starredItems}
        onToggleStar={quickAccess.toggleStar}
        onRemoveRecent={quickAccess.removeRecent}
        onClearRecents={quickAccess.clearRecents}
      />

      <SettingsDialog
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
        theme={theme}
        onSelectTheme={setTheme}
        triggerRef={gearButtonRef}
        onReload={handleReload}
        hiddenFolders={hiddenFolders}
        onAddHiddenFolder={addHiddenFolder}
        onRemoveHiddenFolder={removeHiddenFolder}
        onResetHiddenFolders={resetHiddenFolders}
        showSearchControls={showSearchControls}
        onToggleSearchControls={setShowSearchControls}
        availableFolders={availableFolders}
      />
    </div>
  );
}
