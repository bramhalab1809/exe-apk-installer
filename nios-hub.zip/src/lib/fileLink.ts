import { fileHref } from '../router/hashRoute.ts';

export interface FileLinkProps {
  href: string;
}

/**
 * Returns anchor attributes for opening a dataset file in the in-app viewer.
 */
export function fileLinkProps(path: string): FileLinkProps {
  return {
    href: fileHref(path),
  };
}
