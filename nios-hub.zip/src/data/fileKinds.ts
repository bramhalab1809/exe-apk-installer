import { Kind } from './types.ts';

const KIND_MAP: Record<string, Kind> = {
  pdf: 'pdf',
  // Images
  png: 'image',
  jpg: 'image',
  jpeg: 'image',
  gif: 'image',
  webp: 'image',
  svg: 'image',
  avif: 'image',
  bmp: 'image',
  // Videos
  mp4: 'video',
  webm: 'video',
  mov: 'video',
  m4v: 'video',
  mkv: 'video',
  // Audio
  mp3: 'audio',
  wav: 'audio',
  m4a: 'audio',
  ogg: 'audio',
  aac: 'audio',
  // Text
  txt: 'text',
  md: 'text',
  csv: 'text',
  json: 'text',
  log: 'text',
};

export function extOf(name: string): string {
  const dotIndex = name.lastIndexOf('.');
  if (dotIndex === -1 || dotIndex === 0 || dotIndex === name.length - 1) {
    return '';
  }
  return name.slice(dotIndex + 1).toLowerCase();
}

export function kindOf(name: string): Kind {
  const ext = extOf(name);
  if (!ext) return 'other';
  return KIND_MAP[ext] || 'other';
}
