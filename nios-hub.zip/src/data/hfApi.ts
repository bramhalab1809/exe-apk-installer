import { Entry } from './types.ts';
import { kindOf } from './fileKinds.ts';

export const HF_REPO = 'andy180926/NIOS-SYLLABUS';
export const HF_BRANCH = 'main';

export function toHfPath(path: string): string {
  const clean = path.trim().replace(/^\/+|\/+$/g, '');
  if (!clean || clean.toLowerCase() === 'home') return '';
  if (clean.toLowerCase().startsWith('home/')) {
    return clean.slice(5);
  }
  return clean;
}

export function encodePath(path: string): string {
  if (!path) return '';
  return path
    .split('/')
    .filter(Boolean)
    .map(encodeURIComponent)
    .join('/');
}

export function fileUrl(
  path: string,
  opts?: { download?: boolean; bust?: boolean }
): string {
  if (path.startsWith('About me/') || path === 'About me') {
    return `./About me/${encodePath(path.replace(/^About me\/?/, ''))}`;
  }
  const realPath = toHfPath(path);
  const base = `https://huggingface.co/datasets/${HF_REPO}/resolve/${HF_BRANCH}/${encodePath(realPath)}`;
  const params = new URLSearchParams();

  if (opts?.download) {
    params.set('download', 'true');
  }
  if (opts?.bust) {
    params.set('r', String(Date.now()));
  }

  const query = params.toString();
  return query ? `${base}?${query}` : base;
}

interface RawHfItem {
  type: 'directory' | 'file';
  path: string;
  size?: number;
}

function extractNextUrl(linkHeader: string | null): string | null {
  if (!linkHeader) return null;
  const match = linkHeader.match(/<([^>]+)>;\s*rel="next"/i);
  return match ? match[1] : null;
}

export const ABOUT_ME_DOC_ENTRIES: Entry[] = [
  { name: 'file_structure.txt', path: 'About me/file_structure.txt', isFolder: false, size: 4091, kind: 'other' },
  { name: 'how_it_works.txt', path: 'About me/how_it_works.txt', isFolder: false, size: 2354, kind: 'other' },
  { name: 'project_overview.txt', path: 'About me/project_overview.txt', isFolder: false, size: 1750, kind: 'other' },
  { name: 'rules_for_builders.txt', path: 'About me/rules_for_builders.txt', isFolder: false, size: 1999, kind: 'other' },
  { name: 'search_engine.txt', path: 'About me/search_engine.txt', isFolder: false, size: 2592, kind: 'other' },
  { name: 'state_and_storage.txt', path: 'About me/state_and_storage.txt', isFolder: false, size: 2964, kind: 'other' },
  { name: 'ui_layout_and_design.txt', path: 'About me/ui_layout_and_design.txt', isFolder: false, size: 2763, kind: 'other' },
];

export async function listFolder(
  path: string,
  signal?: AbortSignal
): Promise<{ entries: Entry[]; maybeIncomplete: boolean }> {
  if (path === 'About me' || path === '/About me') {
    return {
      entries: ABOUT_ME_DOC_ENTRIES,
      maybeIncomplete: false,
    };
  }

  const cleanPath = toHfPath(path);
  const encoded = encodePath(cleanPath);
  const initialUrl = `https://huggingface.co/api/datasets/${HF_REPO}/tree/${HF_BRANCH}${
    encoded ? `/${encoded}` : ''
  }`;

  const allEntries: Entry[] = [];
  let nextUrl: string | null = initialUrl;
  let pageCount = 0;
  let maybeIncomplete = false;

  while (nextUrl && pageCount < 20) {
    pageCount++;
    const res = await fetch(nextUrl, { signal });
    if (!res.ok) {
      throw new Error(`HTTP ${res.status}`);
    }

    const items = (await res.json()) as RawHfItem[];
    if (Array.isArray(items)) {
      for (const item of items) {
        const itemPath = item.path || '';
        if (itemPath === 'About me' || itemPath.startsWith('About me/')) continue;
        const name = itemPath.split('/').pop() || itemPath;
        const isFolder = item.type === 'directory';
        const fullPath = `Home/${itemPath}`;
        allEntries.push({
          name,
          path: fullPath,
          isFolder,
          size: typeof item.size === 'number' ? item.size : 0,
          kind: isFolder ? 'other' : kindOf(name),
        });
      }
    }

    const linkHeader = res.headers.get('Link') || res.headers.get('link');
    const following = extractNextUrl(linkHeader);

    if (items.length >= 1000 && !following) {
      maybeIncomplete = true;
    }

    nextUrl = following;
  }

  return {
    entries: allEntries,
    maybeIncomplete,
  };
}
