import { Entry } from './types.ts';

export function isSystemEntry(entry: Entry): boolean {
  if (entry.name.startsWith('.')) {
    return true;
  }
  if (entry.name.toLowerCase() === 'readme.md') {
    // Only hidden at the dataset root or Home root
    return (
      !entry.path.includes('/') ||
      entry.path.toLowerCase() === 'readme.md' ||
      entry.path.toLowerCase() === 'home/readme.md'
    );
  }
  return false;
}

export function isHiddenFolder(entry: Entry, hiddenList: string[]): boolean {
  if (!hiddenList || hiddenList.length === 0) return false;
  const entryNameLower = entry.name.toLowerCase();
  const entryPathLower = entry.path.toLowerCase();

  for (const rawItem of hiddenList) {
    const item = rawItem.trim().toLowerCase();
    if (!item) continue;

    if (item.includes('/')) {
      // Path match (exact or child of hidden path)
      if (entryPathLower === item || entryPathLower.startsWith(item + '/')) {
        return true;
      }
    } else {
      // Name match (or any ancestor folder name)
      if (entryNameLower === item) {
        return true;
      }
      const segments = entryPathLower.split('/');
      if (segments.includes(item)) {
        return true;
      }
    }
  }

  return false;
}

export function filterHidden(entries: Entry[], hiddenList: string[]): Entry[] {
  return entries.filter((entry) => {
    if (isSystemEntry(entry)) return false;
    if (isHiddenFolder(entry, hiddenList)) return false;
    return true;
  });
}

export function sortEntries(entries: Entry[]): Entry[] {
  return [...entries].sort((a, b) => {
    // Folders first
    if (a.isFolder && !b.isFolder) return -1;
    if (!a.isFolder && b.isFolder) return 1;

    // Natural alphabetical order
    return a.name.localeCompare(b.name, undefined, {
      numeric: true,
      sensitivity: 'base',
    });
  });
}
