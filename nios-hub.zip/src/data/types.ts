export type Kind = 'pdf' | 'image' | 'video' | 'audio' | 'text' | 'other';

export interface Entry {
  name: string;
  path: string;
  isFolder: boolean;
  size: number;
  kind: Kind;
}
