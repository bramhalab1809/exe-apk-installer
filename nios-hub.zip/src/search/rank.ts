import { Kind } from '../data/types.ts';

export interface SearchEntry {
  name: string;
  path: string;
  isFolder: boolean;
  kind: Kind;
  normName: string;
  normPath: string;
}

export interface SearchOptions {
  kinds: Set<Kind>;
  scopeFolder: string | null;
  hidden: string[];
}

export function normalize(s: string): string {
  return s
    .normalize('NFKD')
    .replace(/[\u0300-\u036f]/g, '')
    .toLowerCase()
    .replace(/[_\-.\(\)\[\]%+\s]+/g, ' ')
    .trim();
}

function isEntryExcludedByHidden(
  entryPath: string,
  entryName: string,
  hiddenList: string[]
): boolean {
  if (!hiddenList || hiddenList.length === 0) return false;

  const pathLower = entryPath.toLowerCase();
  const nameLower = entryName.toLowerCase();
  const segments = pathLower.split('/');

  for (const rawItem of hiddenList) {
    const item = rawItem.trim().toLowerCase();
    if (!item) continue;

    if (item.includes('/')) {
      if (pathLower === item || pathLower.startsWith(item + '/')) {
        return true;
      }
    } else {
      if (nameLower === item || segments.includes(item)) {
        return true;
      }
    }
  }

  return false;
}

export function search(
  entries: SearchEntry[],
  query: string,
  options: SearchOptions
): SearchEntry[] {
  const normQuery = normalize(query);
  if (!normQuery) return [];

  const tokens = normQuery.split(' ').filter(Boolean);
  if (tokens.length === 0) return [];

  const { kinds, scopeFolder, hidden } = options;
  const hasKinds = kinds.size > 0;
  const cleanScope = scopeFolder ? scopeFolder.trim().replace(/^\/+|\/+$/g, '') : null;

  const matches: { entry: SearchEntry; score: number }[] = [];

  for (let i = 0; i < entries.length; i++) {
    const e = entries[i];

    // Filter by kind
    if (hasKinds) {
      if (e.isFolder || !kinds.has(e.kind)) continue;
    }

    // Filter by scope
    if (cleanScope) {
      const inScope = e.path === cleanScope || e.path.startsWith(cleanScope + '/');
      if (!inScope) continue;
    }

    // Filter by hidden list
    if (isEntryExcludedByHidden(e.path, e.name, hidden)) {
      continue;
    }

    // Token check: each token must appear in normName or normPath
    let allTokensPresent = true;
    for (let j = 0; j < tokens.length; j++) {
      const tok = tokens[j];
      if (!e.normName.includes(tok) && !e.normPath.includes(tok)) {
        allTokensPresent = false;
        break;
      }
    }
    if (!allTokensPresent) continue;

    // Calculate score
    let score = 0;
    if (e.normName === normQuery) {
      score = 1000;
    } else if (e.normName.startsWith(normQuery)) {
      score = 800;
    } else if (e.normName.includes(normQuery)) {
      score = 600;
    } else {
      let allInName = true;
      for (let j = 0; j < tokens.length; j++) {
        if (!e.normName.includes(tokens[j])) {
          allInName = false;
          break;
        }
      }
      score = allInName ? 400 : 200;
    }

    if (e.isFolder) {
      score += 30;
    }

    matches.push({ entry: e, score });
  }

  // Sort: highest score, shorter path, natural name order
  matches.sort((a, b) => {
    if (b.score !== a.score) return b.score - a.score;
    if (a.entry.path.length !== b.entry.path.length) {
      return a.entry.path.length - b.entry.path.length;
    }
    return a.entry.name.localeCompare(b.entry.name, undefined, {
      numeric: true,
      sensitivity: 'base',
    });
  });

  return matches.slice(0, 300).map((m) => m.entry);
}
