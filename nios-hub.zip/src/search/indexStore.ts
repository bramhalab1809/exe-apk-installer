import { RawIndexData } from './indexBuilder.ts';
import { HF_REPO } from '../data/hfApi.ts';

export interface StoredIndexRecord extends RawIndexData {
  t: number;
}

const DB_NAME = `nioshub-index-${HF_REPO.replace(/[^a-zA-Z0-9]/g, '_')}`;
const STORE_NAME = 'index';
const RECORD_KEY = 'v1';
const TTL_MS = 30 * 60 * 1000; // 30 minutes

let memoryStore: StoredIndexRecord | null = null;

// Delete obsolete CA index database
if (typeof window !== 'undefined' && window.indexedDB) {
  try {
    window.indexedDB.deleteDatabase('cahub2-index');
  } catch {
    // Non-fatal
  }
}

function openDatabase(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    if (typeof window === 'undefined' || !window.indexedDB) {
      return reject(new Error('IndexedDB not supported'));
    }
    try {
      const request = indexedDB.open(DB_NAME, 1);
      request.onupgradeneeded = () => {
        const db = request.result;
        if (!db.objectStoreNames.contains(STORE_NAME)) {
          db.createObjectStore(STORE_NAME);
        }
      };
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error || new Error('IDB open failed'));
    } catch (err) {
      reject(err);
    }
  });
}

export async function loadStoredIndex(): Promise<{
  data: StoredIndexRecord | null;
  isStale: boolean;
}> {
  const now = Date.now();

  // Try IndexedDB first
  try {
    const db = await openDatabase();
    const result = await new Promise<StoredIndexRecord | null>((resolve, reject) => {
      const tx = db.transaction(STORE_NAME, 'readonly');
      const store = tx.objectStore(STORE_NAME);
      const req = store.get(RECORD_KEY);
      req.onsuccess = () => resolve((req.result as StoredIndexRecord) || null);
      req.onerror = () => reject(req.error);
    });

    if (result && Array.isArray(result.paths)) {
      memoryStore = result;
      const isStale = now - result.t > TTL_MS;
      return { data: result, isStale };
    }
  } catch {
    // Fall back to memoryStore on IDB failure
  }

  if (memoryStore) {
    const isStale = now - memoryStore.t > TTL_MS;
    return { data: memoryStore, isStale };
  }

  return { data: null, isStale: false };
}

export async function saveStoredIndex(data: RawIndexData): Promise<void> {
  const record: StoredIndexRecord = {
    ...data,
    t: Date.now(),
  };

  memoryStore = record;

  try {
    const db = await openDatabase();
    await new Promise<void>((resolve, reject) => {
      const tx = db.transaction(STORE_NAME, 'readwrite');
      const store = tx.objectStore(STORE_NAME);
      const req = store.put(record, RECORD_KEY);
      req.onsuccess = () => resolve();
      req.onerror = () => reject(req.error);
    });
  } catch {
    // Non-fatal if IndexedDB write fails; memoryStore holds data
  }
}

export async function clearStoredIndex(): Promise<void> {
  memoryStore = null;

  try {
    const db = await openDatabase();
    await new Promise<void>((resolve, reject) => {
      const tx = db.transaction(STORE_NAME, 'readwrite');
      const store = tx.objectStore(STORE_NAME);
      const req = store.delete(RECORD_KEY);
      req.onsuccess = () => resolve();
      req.onerror = () => reject(req.error);
    });
  } catch {
    // Non-fatal IDB clear failure
  }
}
