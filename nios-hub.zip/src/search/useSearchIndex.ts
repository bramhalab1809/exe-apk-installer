import { useState, useEffect, useRef, useCallback } from 'react';
import { SearchEntry, normalize } from './rank.ts';
import { buildIndex, RawIndexData } from './indexBuilder.ts';
import { loadStoredIndex, saveStoredIndex, clearStoredIndex } from './indexStore.ts';
import { kindOf } from '../data/fileKinds.ts';
import { Kind } from '../data/types.ts';

export interface UseSearchIndexResult {
  ready: boolean;
  building: boolean;
  progressCount: number;
  maybeIncomplete: boolean;
  error: boolean;
  entries: SearchEntry[];
  triggerImmediateBuild: () => void;
  rebuild: () => Promise<void>;
}

function convertToSearchEntries(data: RawIndexData): SearchEntry[] {
  const { paths, isFolder } = data;
  const list: SearchEntry[] = [];

  for (let i = 0; i < paths.length; i++) {
    const p = paths[i];
    const isDir = isFolder[i];
    const segments = p.split('/');
    const name = segments[segments.length - 1] || p;
    const kind: Kind = isDir ? 'other' : kindOf(name);

    list.push({
      name,
      path: p,
      isFolder: isDir,
      kind,
      normName: normalize(name),
      normPath: normalize(p),
    });
  }

  return list;
}

export function useSearchIndex(isFirstFolderLoaded = true): UseSearchIndexResult {
  const [ready, setReady] = useState(false);
  const [building, setBuilding] = useState(false);
  const [progressCount, setProgressCount] = useState(0);
  const [maybeIncomplete, setMaybeIncomplete] = useState(false);
  const [error, setError] = useState(false);
  const [entries, setEntries] = useState<SearchEntry[]>([]);

  const buildingRef = useRef(false);
  const abortControllerRef = useRef<AbortController | null>(null);

  const runBuild = useCallback(async () => {
    if (buildingRef.current) return;
    buildingRef.current = true;
    setBuilding(true);
    setError(false);

    abortControllerRef.current?.abort();
    const controller = new AbortController();
    abortControllerRef.current = controller;

    try {
      const raw = await buildIndex(controller.signal, (count) => {
        setProgressCount(count);
      });

      await saveStoredIndex(raw);
      const converted = convertToSearchEntries(raw);
      setEntries(converted);
      setMaybeIncomplete(raw.maybeIncomplete);
      setReady(true);
    } catch {
      // Keep old entries if available
      setError(true);
    } finally {
      buildingRef.current = false;
      setBuilding(false);
    }
  }, []);

  const triggerImmediateBuild = useCallback(() => {
    if (!ready && !buildingRef.current) {
      runBuild();
    }
  }, [ready, runBuild]);

  const rebuild = useCallback(async () => {
    await clearStoredIndex();
    setReady(false);
    setProgressCount(0);
    await runBuild();
  }, [runBuild]);

  // Initial load check with Stale-While-Revalidate
  useEffect(() => {
    let cancelled = false;

    loadStoredIndex().then(({ data, isStale }) => {
      if (cancelled) return;
      if (data) {
        const converted = convertToSearchEntries(data);
        setEntries(converted);
        setMaybeIncomplete(data.maybeIncomplete);
        setReady(true);
        setProgressCount(data.paths.length);

        if (isStale) {
          runBuild();
        }
      } else if (isFirstFolderLoaded) {
        // Start build 1500ms after first folder finished loading
        const timer = setTimeout(() => {
          if (!cancelled && !buildingRef.current) {
            runBuild();
          }
        }, 1500);

        return () => clearTimeout(timer);
      }
    });

    return () => {
      cancelled = true;
      abortControllerRef.current?.abort();
    };
  }, [isFirstFolderLoaded, runBuild]);

  return {
    ready,
    building,
    progressCount,
    maybeIncomplete,
    error,
    entries,
    triggerImmediateBuild,
    rebuild,
  };
}
