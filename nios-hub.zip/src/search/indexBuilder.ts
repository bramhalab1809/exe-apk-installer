import { HF_REPO, HF_BRANCH } from '../data/hfApi.ts';

export interface RawIndexData {
  paths: string[];
  isFolder: boolean[];
  maybeIncomplete: boolean;
}

interface RawHfTreeItem {
  type: 'directory' | 'file';
  path: string;
}

function extractNextUrl(linkHeader: string | null): string | null {
  if (!linkHeader) return null;
  const match = linkHeader.match(/<([^>]+)>;\s*rel="next"/i);
  return match ? match[1] : null;
}

function shouldSkip(path: string): boolean {
  const segments = path.split('/');
  const name = segments[segments.length - 1];
  if (name.startsWith('.')) return true;
  if (name.toLowerCase() === 'readme.md' && segments.length === 1) return true;
  return false;
}

export async function buildIndex(
  signal?: AbortSignal,
  onProgress?: (count: number) => void
): Promise<RawIndexData> {
  const initialUrl = `https://huggingface.co/api/datasets/${HF_REPO}/tree/${HF_BRANCH}?recursive=true`;

  const paths: string[] = [
    'Home',
    'About me',
    'About me/file_structure.txt',
    'About me/how_it_works.txt',
    'About me/project_overview.txt',
    'About me/rules_for_builders.txt',
    'About me/search_engine.txt',
    'About me/state_and_storage.txt',
    'About me/ui_layout_and_design.txt',
  ];
  const isFolder: boolean[] = [
    true,
    true,
    false,
    false,
    false,
    false,
    false,
    false,
    false,
  ];
  let nextUrl: string | null = initialUrl;
  let pageCount = 0;
  let maybeIncomplete = false;

  while (nextUrl && pageCount < 60) {
    pageCount++;
    const res = await fetch(nextUrl, { signal });
    if (!res.ok) {
      throw new Error(`HTTP ${res.status}`);
    }

    const items = (await res.json()) as RawHfTreeItem[];
    if (Array.isArray(items)) {
      for (const item of items) {
        if (!item.path || shouldSkip(item.path)) continue;
        paths.push(`Home/${item.path}`);
        isFolder.push(item.type === 'directory');
      }
      onProgress?.(paths.length);
    }

    const linkHeader = res.headers.get('Link') || res.headers.get('link');
    const following = extractNextUrl(linkHeader);

    if (items.length >= 1000 && !following) {
      maybeIncomplete = true;
    }

    nextUrl = following;
  }

  return {
    paths,
    isFolder,
    maybeIncomplete,
  };
}
