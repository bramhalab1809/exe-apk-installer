import { useMemo } from 'react';
import { parentOf } from '../router/hashRoute.ts';
import { useFolder } from './useFolder.ts';
import { isSystemEntry } from '../data/sortAndHide.ts';

export interface SiblingsResult {
  parentPath: string;
  prevPath: string | null;
  nextPath: string | null;
}

export function useSiblings(filePath: string): SiblingsResult {
  const parentPath = useMemo(() => parentOf(filePath), [filePath]);
  const { entries, status } = useFolder(parentPath);

  return useMemo(() => {
    if (status !== 'ready' || !filePath) {
      return { parentPath, prevPath: null, nextPath: null };
    }

    const files = entries.filter((entry) => !entry.isFolder && !isSystemEntry(entry));
    const currentIndex = files.findIndex((entry) => entry.path === filePath);

    if (currentIndex === -1) {
      return { parentPath, prevPath: null, nextPath: null };
    }

    const prevPath = currentIndex > 0 ? files[currentIndex - 1].path : null;
    const nextPath = currentIndex < files.length - 1 ? files[currentIndex + 1].path : null;

    return { parentPath, prevPath, nextPath };
  }, [entries, status, filePath, parentPath]);
}
