import { useState, useCallback } from 'react';
import { Kind } from '../data/types.ts';
import { KindFilterGroup } from '../components/SearchFilterToggles.tsx';

export function useKindFilter() {
  const [selectedKinds, setSelectedKinds] = useState<Set<Kind>>(() => new Set());

  const toggleKindGroup = useCallback((group: KindFilterGroup) => {
    setSelectedKinds((prev) => {
      const next = new Set(prev);
      if (group === 'pdf') {
        if (next.has('pdf')) next.delete('pdf');
        else next.add('pdf');
      } else if (group === 'image') {
        if (next.has('image')) next.delete('image');
        else next.add('image');
      } else if (group === 'media') {
        const has = next.has('video') || next.has('audio');
        if (has) {
          next.delete('video');
          next.delete('audio');
        } else {
          next.add('video');
          next.add('audio');
        }
      } else if (group === 'doc') {
        const has = next.has('text') || next.has('other');
        if (has) {
          next.delete('text');
          next.delete('other');
        } else {
          next.add('text');
          next.add('other');
        }
      }
      return next;
    });
  }, []);

  return {
    selectedKinds,
    toggleKindGroup,
  };
}
