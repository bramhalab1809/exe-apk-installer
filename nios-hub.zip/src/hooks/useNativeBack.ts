import { useEffect, useRef } from 'react';
import { RouteState, parentOf, folderHref } from '../router/hashRoute.ts';

export interface UseNativeBackOptions {
  isSettingsOpen: boolean;
  onCloseSettings: () => void;
  isSidebarOpen: boolean;
  isMobile: boolean;
  onCloseSidebar: () => void;
  activeQuickTab: string | null;
  onCloseQuickAccess: () => void;
  route: RouteState;
  onClearSearch: () => void;
}

export function useNativeBack(options: UseNativeBackOptions): void {
  const optionsRef = useRef(options);
  optionsRef.current = options;

  useEffect(() => {
    const handleBackAction = (): boolean => {
      const opt = optionsRef.current;

      // 1. Close Settings dialog if open
      if (opt.isSettingsOpen) {
        opt.onCloseSettings();
        return true;
      }

      // 2. Close Mobile Quick Access drawer if open
      if (opt.activeQuickTab) {
        opt.onCloseQuickAccess();
        return true;
      }

      // 3. Close Mobile Explore sidebar if open
      if (opt.isMobile && opt.isSidebarOpen) {
        opt.onCloseSidebar();
        return true;
      }

      // 4. In-app viewer -> navigate to parent folder
      if (opt.route.type === 'viewer' && opt.route.filePath) {
        const parent = parentOf(opt.route.filePath);
        window.location.hash = folderHref(parent);
        return true;
      }

      // 5. Search view -> clear search and return to prior folder
      if (opt.route.type === 'search') {
        opt.onClearSearch();
        return true;
      }

      // 6. Subfolder view -> navigate to parent folder
      if (
        opt.route.type === 'folder' &&
        opt.route.folderPath &&
        opt.route.folderPath !== 'Home'
      ) {
        const parent = parentOf(opt.route.folderPath);
        window.location.hash = folderHref(parent);
        return true;
      }

      // 7. At root Home -> allow default exit/minimize
      return false;
    };

    const onCapacitorBack = (event: Event) => {
      const handled = handleBackAction();
      if (handled) {
        event.preventDefault();
      }
    };

    document.addEventListener('backbutton', onCapacitorBack);
    return () => {
      document.removeEventListener('backbutton', onCapacitorBack);
    };
  }, []);
}
