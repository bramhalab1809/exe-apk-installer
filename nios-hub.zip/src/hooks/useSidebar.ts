import { useState, useEffect, useCallback } from 'react';

interface UiState {
  sidebarOpen: boolean;
}

const STORAGE_KEY = 'nioshub.ui';
const DEFAULT_SIDEBAR_OPEN = true;
const MOBILE_BREAKPOINT = 768;

function loadInitialDesktopSidebar(): boolean {
  if (typeof window === 'undefined') return DEFAULT_SIDEBAR_OPEN;
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return DEFAULT_SIDEBAR_OPEN;
    const parsed = JSON.parse(raw) as Partial<UiState>;
    if (typeof parsed?.sidebarOpen === 'boolean') {
      return parsed.sidebarOpen;
    }
  } catch {
    // Fall back to default
  }
  return DEFAULT_SIDEBAR_OPEN;
}

function saveDesktopSidebar(sidebarOpen: boolean): void {
  if (typeof window === 'undefined') return;
  try {
    const data: UiState = { sidebarOpen };
    localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
  } catch {
    // Ignore storage write errors
  }
}

export function useSidebar() {
  const [isMobile, setIsMobile] = useState<boolean>(() => {
    if (typeof window === 'undefined') return false;
    return window.innerWidth < MOBILE_BREAKPOINT;
  });

  const [desktopOpen, setDesktopOpen] = useState<boolean>(loadInitialDesktopSidebar);
  const [mobileOpen, setMobileOpen] = useState<boolean>(false);

  useEffect(() => {
    const handleResize = () => {
      const mobile = window.innerWidth < MOBILE_BREAKPOINT;
      setIsMobile(mobile);
      if (!mobile) {
        setMobileOpen(false);
      }
    };

    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  const openSidebar = useCallback(() => {
    if (isMobile) {
      setMobileOpen(true);
    } else {
      setDesktopOpen(true);
      saveDesktopSidebar(true);
    }
  }, [isMobile]);

  const closeSidebar = useCallback(() => {
    if (isMobile) {
      setMobileOpen(false);
    } else {
      setDesktopOpen(false);
      saveDesktopSidebar(false);
    }
  }, [isMobile]);

  const toggleSidebar = useCallback(() => {
    if (isMobile) {
      setMobileOpen((prev) => !prev);
    } else {
      setDesktopOpen((prev) => {
        const next = !prev;
        saveDesktopSidebar(next);
        return next;
      });
    }
  }, [isMobile]);

  // Handle escape key to close sidebar on mobile
  useEffect(() => {
    if (!isMobile || !mobileOpen) return;

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        setMobileOpen(false);
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isMobile, mobileOpen]);

  const isVisible = isMobile ? mobileOpen : desktopOpen;

  return {
    isMobile,
    isOpen: isVisible,
    desktopOpen,
    mobileOpen,
    openSidebar,
    closeSidebar,
    toggleSidebar,
  };
}
