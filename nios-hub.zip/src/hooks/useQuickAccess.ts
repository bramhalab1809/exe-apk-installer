import { useState, useCallback, useMemo } from 'react';
import { Kind } from '../data/types.ts';

export type QuickAccessTab = 'recent' | 'starred';

export interface QuickAccessItem {
  name: string;
  path: string;
  isFolder: boolean;
  kind: Kind;
  t: number;
}

const STARRED_KEY = 'nioshub.starred';
const RECENTS_KEY = 'nioshub.recents';
const MAX_ITEMS = 40;

function isLegacyItem(path: string, name: string): boolean {
  const p = path.toLowerCase();
  const n = name.toLowerCase();
  return (
    p.includes('external_sm') ||
    p.includes('icai_sm') ||
    p.includes('ca-foundation') ||
    n === 'external_sm' ||
    n === 'icai_sm'
  );
}

function parseItems(raw: string | null): QuickAccessItem[] {
  if (!raw) return [];
  try {
    const parsed = JSON.parse(raw) as unknown;
    if (!Array.isArray(parsed)) return [];
    const valid: QuickAccessItem[] = [];
    const seen = new Set<string>();
    for (const item of parsed) {
      if (item && typeof item === 'object') {
        const rec = item as Partial<QuickAccessItem>;
        if (
          typeof rec.path === 'string' &&
          rec.path.trim() &&
          typeof rec.name === 'string' &&
          rec.name.trim() &&
          typeof rec.isFolder === 'boolean' &&
          !seen.has(rec.path) &&
          !isLegacyItem(rec.path, rec.name)
        ) {
          seen.add(rec.path);
          valid.push({
            path: rec.path,
            name: rec.name,
            isFolder: rec.isFolder,
            kind: rec.kind || 'other',
            t: typeof rec.t === 'number' ? rec.t : Date.now(),
          });
          if (valid.length >= MAX_ITEMS) break;
        }
      }
    }
    return valid;
  } catch {
    return [];
  }
}

function loadList(key: string): QuickAccessItem[] {
  if (typeof window === 'undefined') return [];
  try {
    return parseItems(localStorage.getItem(key));
  } catch {
    return [];
  }
}

function saveList(key: string, items: QuickAccessItem[]): void {
  if (typeof window === 'undefined') return;
  try {
    localStorage.setItem(key, JSON.stringify(items.slice(0, MAX_ITEMS)));
  } catch {
    // Ignore quota errors
  }
}

export function useQuickAccess() {
  // Always hidden (null) by default on initial page load
  const [activeTab, setActiveTab] = useState<QuickAccessTab | null>(null);
  const [starredItems, setStarredItems] = useState<QuickAccessItem[]>(() => loadList(STARRED_KEY));
  const [recentItems, setRecentItems] = useState<QuickAccessItem[]>(() => loadList(RECENTS_KEY));

  const starredPathSet = useMemo(
    () => new Set(starredItems.map((i) => i.path)),
    [starredItems]
  );

  const isStarred = useCallback(
    (path: string) => starredPathSet.has(path),
    [starredPathSet]
  );

  const toggleTab = useCallback((tab: QuickAccessTab) => {
    setActiveTab((prev) => (prev === tab ? null : tab));
  }, []);

  const closePanel = useCallback(() => {
    setActiveTab(null);
  }, []);

  const toggleStar = useCallback(
    (item: { name: string; path: string; isFolder: boolean; kind: Kind }) => {
      if (!item.path) return;
      setStarredItems((prev) => {
        const exists = prev.some((i) => i.path === item.path);
        const next = exists
          ? prev.filter((i) => i.path !== item.path)
          : [{ ...item, t: Date.now() }, ...prev].slice(0, MAX_ITEMS);
        saveList(STARRED_KEY, next);
        return next;
      });
    },
    []
  );

  const recordRecent = useCallback(
    (item: { name: string; path: string; isFolder: boolean; kind: Kind }) => {
      if (!item.path || item.path === 'Home') return;
      setRecentItems((prev) => {
        const filtered = prev.filter((i) => i.path !== item.path);
        const next = [{ ...item, t: Date.now() }, ...filtered].slice(0, MAX_ITEMS);
        saveList(RECENTS_KEY, next);
        return next;
      });
    },
    []
  );

  const removeRecent = useCallback((path: string) => {
    setRecentItems((prev) => {
      const next = prev.filter((i) => i.path !== path);
      saveList(RECENTS_KEY, next);
      return next;
    });
  }, []);

  const clearRecents = useCallback(() => {
    setRecentItems([]);
    saveList(RECENTS_KEY, []);
  }, []);

  return {
    activeTab,
    setActiveTab,
    toggleTab,
    closePanel,
    starredItems,
    recentItems,
    isStarred,
    toggleStar,
    recordRecent,
    removeRecent,
    clearRecents,
  };
}
