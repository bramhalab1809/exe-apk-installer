import { useState, useEffect, useCallback, useRef, useMemo } from 'react';
import { Entry } from '../data/types.ts';
import { listFolder } from '../data/hfApi.ts';
import { getCached, setCached } from '../data/folderCache.ts';
import { sortEntries, isHiddenFolder, isSystemEntry } from '../data/sortAndHide.ts';

export interface UseTreeResult {
  rootFolders: Entry[];
  rootLoading: boolean;
  expandedPaths: Set<string>;
  childrenMap: Map<string, Entry[]>;
  loadingMap: Map<string, boolean>;
  loadedMap: Map<string, boolean>;
  toggleExpand: (path: string) => void;
  expandPath: (path: string) => void;
  resetTree: () => void;
}

const HOME_NODE: Entry = {
  name: 'Home',
  path: 'Home',
  isFolder: true,
  size: 0,
  kind: 'other',
};

const ABOUT_ME_NODE: Entry = {
  name: 'About me',
  path: 'About me',
  isFolder: true,
  size: 0,
  kind: 'other',
};

export function useTree(currentPath: string, hiddenFolders: string[]): UseTreeResult {
  const isAboutMeHidden = useMemo(() => {
    return hiddenFolders.some((f) => f.trim().toLowerCase() === 'about me');
  }, [hiddenFolders]);

  const rootFolders = useMemo(() => {
    return isAboutMeHidden ? [HOME_NODE] : [HOME_NODE, ABOUT_ME_NODE];
  }, [isAboutMeHidden]);

  const [rootLoading, setRootLoading] = useState<boolean>(true);
  const [expandedPaths, setExpandedPaths] = useState<Set<string>>(() => new Set(['Home']));
  const [childrenMap, setChildrenMap] = useState<Map<string, Entry[]>>(() => new Map());
  const [loadingMap, setLoadingMap] = useState<Map<string, boolean>>(() => new Map());
  const [loadedMap, setLoadedMap] = useState<Map<string, boolean>>(() => new Map());

  const hiddenRef = useRef(hiddenFolders);
  hiddenRef.current = hiddenFolders;

  const fetchFolderFolders = useCallback(async (path: string): Promise<Entry[]> => {
    const cached = getCached(path, false);
    let allEntries: Entry[];

    if (cached) {
      allEntries = cached.entries;
    } else {
      const res = await listFolder(path);
      const sorted = sortEntries(res.entries);
      setCached(path, { entries: sorted, maybeIncomplete: res.maybeIncomplete });
      allEntries = sorted;
    }

    return allEntries.filter(
      (e) => e.isFolder && !isSystemEntry(e) && !isHiddenFolder(e, hiddenRef.current)
    );
  }, []);

  const loadChildren = useCallback(
    async (folderPath: string) => {
      setLoadingMap((prev) => new Map(prev).set(folderPath, true));
      try {
        const folders = await fetchFolderFolders(folderPath);
        setChildrenMap((prev) => new Map(prev).set(folderPath, folders));
        setLoadedMap((prev) => new Map(prev).set(folderPath, true));
      } catch {
        // Non-fatal error loading subfolders
      } finally {
        setLoadingMap((prev) => {
          const next = new Map(prev);
          next.delete(folderPath);
          return next;
        });
      }
    },
    [fetchFolderFolders]
  );

  const loadRoot = useCallback(() => {
    setRootLoading(true);
    loadChildren('Home').then(() => {
      setRootLoading(false);
    });
  }, [loadChildren]);

  useEffect(() => {
    loadRoot();
  }, [loadRoot]);

  const toggleExpand = useCallback(
    (folderPath: string) => {
      setExpandedPaths((prev) => {
        const next = new Set(prev);
        if (next.has(folderPath)) {
          next.delete(folderPath);
        } else {
          next.add(folderPath);
          if (!loadedMap.get(folderPath) && !loadingMap.get(folderPath)) {
            loadChildren(folderPath);
          }
        }
        return next;
      });
    },
    [loadedMap, loadingMap, loadChildren]
  );

  const expandPath = useCallback(
    (folderPath: string) => {
      setExpandedPaths((prev) => {
        if (prev.has(folderPath)) return prev;
        const next = new Set(prev);
        next.add(folderPath);
        return next;
      });
      if (!loadedMap.get(folderPath) && !loadingMap.get(folderPath)) {
        loadChildren(folderPath);
      }
    },
    [loadedMap, loadingMap, loadChildren]
  );

  const prevCurrentPathRef = useRef<string | null>(null);

  // Sync expanded folders when currentPath changes:
  // Expand strict ancestors of currentPath and close deeper folders when navigating back.
  useEffect(() => {
    if (currentPath === '__search_active__') return;
    if (prevCurrentPathRef.current === currentPath) return;
    prevCurrentPathRef.current = currentPath;

    const clean = (currentPath || '').trim().replace(/^\/+|\/+$/g, '');
    if (!clean || clean.toLowerCase() === 'home') {
      setExpandedPaths(new Set(['Home']));
      return;
    }

    const isAboutMe = clean === 'About me' || clean.startsWith('About me/');
    const full = isAboutMe || clean.startsWith('Home/') ? clean : `Home/${clean}`;
    const segments = full.split('/').filter(Boolean);

    const nextExpanded = new Set<string>(['Home']);
    let accum = '';
    for (let i = 0; i < segments.length - 1; i++) {
      accum = accum ? `${accum}/${segments[i]}` : segments[i];
      nextExpanded.add(accum);
      if (!loadedMap.get(accum) && !loadingMap.get(accum)) {
        loadChildren(accum);
      }
    }

    setExpandedPaths(nextExpanded);
  }, [currentPath, loadedMap, loadingMap, loadChildren]);

  const resetTree = useCallback(() => {
    setChildrenMap(new Map());
    setLoadedMap(new Map());
    setLoadingMap(new Map());
    loadRoot();
  }, [loadRoot]);

  return {
    rootFolders,
    rootLoading,
    expandedPaths,
    childrenMap,
    loadingMap,
    loadedMap,
    toggleExpand,
    expandPath,
    resetTree,
  };
}
