import { useRef, useLayoutEffect, useEffect, RefObject } from 'react';

export function useScrollRestoration(
  mainRef: RefObject<HTMLElement | null>,
  routeType: string,
  folderPath: string,
  status: string
) {
  const scrollMap = useRef<Map<string, number>>(new Map());

  const handleScroll = () => {
    if (mainRef.current && routeType === 'folder') {
      scrollMap.current.set(folderPath, mainRef.current.scrollTop);
    }
  };

  useLayoutEffect(() => {
    if (mainRef.current) {
      mainRef.current.scrollTop = routeType === 'folder' ? (scrollMap.current.get(folderPath) ?? 0) : 0;
    }
  }, [routeType, folderPath, mainRef]);

  useEffect(() => {
    if (routeType === 'folder' && status === 'ready' && mainRef.current) {
      mainRef.current.scrollTop = scrollMap.current.get(folderPath) ?? 0;
    }
  }, [routeType, status, folderPath, mainRef]);

  return { handleScroll };
}
