import { useState, useRef, useCallback } from 'react';
import { RouteState, searchHref, folderHref } from '../router/hashRoute.ts';

export function useSearchNav(route: RouteState) {
  const isSearch = route.type === 'search';
  const rememberedFolderRef = useRef<string>('');

  if (!isSearch) {
    rememberedFolderRef.current = route.folderPath;
  }

  const [activeScope, setActiveScope] = useState<'all' | 'folder'>(() =>
    route.scopeFolder ? 'folder' : 'all'
  );

  const handleQueryChange = useCallback(
    (q: string) => {
      const trimmed = q.trim();
      if (!trimmed) {
        window.location.hash = folderHref(rememberedFolderRef.current || '');
        return;
      }

      const scope =
        activeScope === 'folder'
          ? route.scopeFolder || rememberedFolderRef.current || null
          : null;
      const newHash = searchHref(trimmed, scope);

      if (!isSearch) {
        window.location.hash = newHash;
      } else {
        window.history.replaceState(null, '', newHash);
        window.dispatchEvent(new HashChangeEvent('hashchange'));
      }
    },
    [isSearch, activeScope, route.scopeFolder]
  );

  const handleClearOrEsc = useCallback(() => {
    window.location.hash = folderHref(rememberedFolderRef.current || '');
  }, []);

  const handleScopeChange = useCallback(
    (scope: 'all' | 'folder') => {
      setActiveScope(scope);
      if (isSearch) {
        const scopeVal = scope === 'folder' ? rememberedFolderRef.current || null : null;
        const newHash = searchHref(route.query, scopeVal);
        window.history.replaceState(null, '', newHash);
        window.dispatchEvent(new HashChangeEvent('hashchange'));
      }
    },
    [isSearch, route.query]
  );

  const currentScopeFolder =
    route.scopeFolder ||
    (route.type === 'folder' ? route.folderPath : rememberedFolderRef.current || null);

  return {
    isSearch,
    rememberedFolder: rememberedFolderRef.current,
    activeScope,
    currentScopeFolder,
    handleQueryChange,
    handleClearOrEsc,
    handleScopeChange,
  };
}
