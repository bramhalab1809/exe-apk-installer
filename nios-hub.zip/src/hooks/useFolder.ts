import { useState, useEffect, useCallback, useRef } from 'react';
import { Entry } from '../data/types.ts';
import { listFolder } from '../data/hfApi.ts';
import { sortEntries } from '../data/sortAndHide.ts';
import { getCached, setCached } from '../data/folderCache.ts';

export type FolderStatus = 'loading' | 'ready' | 'error';

export interface UseFolderResult {
  entries: Entry[];
  status: FolderStatus;
  stale: boolean;
  maybeIncomplete: boolean;
  refresh: () => void;
}

const ROOT_ENTRIES: Entry[] = [
  {
    name: 'Home',
    path: 'Home',
    isFolder: true,
    size: 0,
    kind: 'other',
  },
  {
    name: 'About me',
    path: 'About me',
    isFolder: true,
    size: 0,
    kind: 'other',
  },
];

export function useFolder(path: string): UseFolderResult {
  const [entries, setEntries] = useState<Entry[]>([]);
  const [status, setStatus] = useState<FolderStatus>('loading');
  const [stale, setStale] = useState<boolean>(false);
  const [maybeIncomplete, setMaybeIncomplete] = useState<boolean>(false);
  const [reloadCount, setReloadCount] = useState<number>(0);

  const abortControllerRef = useRef<AbortController | null>(null);

  const refresh = useCallback(() => {
    setReloadCount((c) => c + 1);
  }, []);

  useEffect(() => {
    // Top-level root view shows Home (and About me when unhidden)
    if (!path) {
      setEntries(ROOT_ENTRIES);
      setStatus('ready');
      setStale(false);
      setMaybeIncomplete(false);
      return;
    }

    let isCancelled = false;
    abortControllerRef.current?.abort();
    const controller = new AbortController();
    abortControllerRef.current = controller;

    const isRefresh = reloadCount > 0;
    const freshCache = isRefresh ? null : getCached(path, false);

    if (freshCache) {
      setEntries(freshCache.entries);
      setStatus('ready');
      setStale(false);
      setMaybeIncomplete(freshCache.maybeIncomplete);
      return;
    }

    // No fresh cache or refreshing
    const staleCache = getCached(path, true);
    if (!staleCache) {
      setStatus('loading');
    }

    listFolder(path, controller.signal)
      .then(({ entries: rawEntries, maybeIncomplete: incomplete }) => {
        if (isCancelled) return;
        const sorted = sortEntries(rawEntries);
        setCached(path, { entries: sorted, maybeIncomplete: incomplete });

        setEntries(sorted);
        setStatus('ready');
        setStale(false);
        setMaybeIncomplete(incomplete);
      })
      .catch((err: unknown) => {
        if (isCancelled || (err instanceof DOMException && err.name === 'AbortError')) {
          return;
        }

        // Check if we have stale cache to fall back to
        const fallback = staleCache || getCached(path, true);
        if (fallback) {
          setEntries(fallback.entries);
          setStatus('ready');
          setStale(true);
          setMaybeIncomplete(fallback.maybeIncomplete);
        } else {
          setStatus('error');
          setStale(false);
        }
      });

    return () => {
      isCancelled = true;
      controller.abort();
    };
  }, [path, reloadCount]);

  return {
    entries,
    status,
    stale,
    maybeIncomplete,
    refresh,
  };
}
