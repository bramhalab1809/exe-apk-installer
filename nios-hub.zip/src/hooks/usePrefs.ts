import { useState, useLayoutEffect, useCallback } from 'react';

export type ThemeMode = 'light' | 'dark' | 'system';

export interface UserPrefs {
  theme: ThemeMode;
  hiddenFolders?: string[];
  showSearchControls?: boolean;
}

const STORAGE_KEY = 'nioshub.prefs';
const DEFAULT_THEME: ThemeMode = 'system';
export const DEFAULT_HIDDEN_FOLDERS = ['About me'];

function getSystemPrefersDark(): boolean {
  if (typeof window === 'undefined') return false;
  try {
    return window.matchMedia('(prefers-color-scheme: dark)').matches;
  } catch {
    return false;
  }
}

function applyThemeToDom(theme: ThemeMode): void {
  if (typeof document === 'undefined') return;
  const root = document.documentElement;
  const isDark = theme === 'dark' || (theme === 'system' && getSystemPrefersDark());
  root.classList.toggle('dark', isDark);
  root.style.colorScheme = isDark ? 'dark' : 'light';
}

function sanitizeHiddenFolders(list: unknown): string[] {
  if (!Array.isArray(list)) return [...DEFAULT_HIDDEN_FOLDERS];

  const result: string[] = [];
  const seenLower = new Set<string>();

  for (const item of list) {
    if (typeof item === 'string') {
      const trimmed = item.trim();
      const lower = trimmed.toLowerCase();
      if (trimmed.length > 0 && trimmed.length <= 200 && !seenLower.has(lower)) {
        seenLower.add(lower);
        result.push(trimmed);
        if (result.length >= 50) break;
      }
    }
  }

  return result.length > 0 ? result : [...DEFAULT_HIDDEN_FOLDERS];
}

interface LoadedPrefs {
  theme: ThemeMode;
  hiddenFolders: string[];
  showSearchControls: boolean;
}

function loadInitialPrefs(): LoadedPrefs {
  if (typeof window === 'undefined') {
    return { theme: DEFAULT_THEME, hiddenFolders: [...DEFAULT_HIDDEN_FOLDERS], showSearchControls: false };
  }
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) {
      applyThemeToDom(DEFAULT_THEME);
      return { theme: DEFAULT_THEME, hiddenFolders: [...DEFAULT_HIDDEN_FOLDERS], showSearchControls: false };
    }
    const parsed = JSON.parse(raw) as Partial<UserPrefs>;
    const theme: ThemeMode =
      parsed && (parsed.theme === 'light' || parsed.theme === 'dark' || parsed.theme === 'system')
        ? parsed.theme
        : DEFAULT_THEME;
    const hiddenFolders = sanitizeHiddenFolders(parsed?.hiddenFolders);
    const showSearchControls = typeof parsed?.showSearchControls === 'boolean' ? parsed.showSearchControls : false;
    applyThemeToDom(theme);
    return { theme, hiddenFolders, showSearchControls };
  } catch {
    applyThemeToDom(DEFAULT_THEME);
    return { theme: DEFAULT_THEME, hiddenFolders: [...DEFAULT_HIDDEN_FOLDERS], showSearchControls: false };
  }
}

function savePrefs(theme: ThemeMode, hiddenFolders: string[], showSearchControls: boolean): void {
  if (typeof window === 'undefined') return;
  try {
    const data: UserPrefs = { theme, hiddenFolders, showSearchControls };
    localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
  } catch {
    // Ignore storage write errors
  }
}

export function usePrefs() {
  const [prefs, setPrefs] = useState(loadInitialPrefs);

  const setTheme = useCallback((newTheme: ThemeMode) => {
    applyThemeToDom(newTheme);
    setPrefs((prev) => {
      const next = { ...prev, theme: newTheme };
      savePrefs(next.theme, next.hiddenFolders, next.showSearchControls);
      return next;
    });
  }, []);

  const setShowSearchControls = useCallback((val: boolean) => {
    setPrefs((prev) => {
      const next = { ...prev, showSearchControls: val };
      savePrefs(next.theme, next.hiddenFolders, next.showSearchControls);
      return next;
    });
  }, []);

  const addHiddenFolder = useCallback((name: string) => {
    const trimmed = name.trim();
    if (!trimmed || trimmed.length > 200) return;

    setPrefs((prev) => {
      const lower = trimmed.toLowerCase();
      if (prev.hiddenFolders.some((f) => f.toLowerCase() === lower)) return prev;
      if (prev.hiddenFolders.length >= 50) return prev;
      const nextList = [...prev.hiddenFolders, trimmed];
      savePrefs(prev.theme, nextList, prev.showSearchControls);
      return { ...prev, hiddenFolders: nextList };
    });
  }, []);

  const removeHiddenFolder = useCallback((name: string) => {
    const lower = name.trim().toLowerCase();
    setPrefs((prev) => {
      const nextList = prev.hiddenFolders.filter((f) => f.toLowerCase() !== lower);
      savePrefs(prev.theme, nextList, prev.showSearchControls);
      return { ...prev, hiddenFolders: nextList };
    });
  }, []);

  const resetHiddenFolders = useCallback(() => {
    setPrefs((prev) => {
      const nextList = [...DEFAULT_HIDDEN_FOLDERS];
      savePrefs(prev.theme, nextList, prev.showSearchControls);
      return { ...prev, hiddenFolders: nextList };
    });
  }, []);

  useLayoutEffect(() => {
    applyThemeToDom(prefs.theme);

    if (prefs.theme === 'system') {
      try {
        const mediaQuery = window.matchMedia('(prefers-color-scheme: dark)');
        const listener = () => applyThemeToDom('system');
        mediaQuery.addEventListener('change', listener);
        return () => mediaQuery.removeEventListener('change', listener);
      } catch {
        // matchMedia fallback
      }
    }
  }, [prefs.theme]);

  return {
    theme: prefs.theme,
    setTheme,
    hiddenFolders: prefs.hiddenFolders,
    addHiddenFolder,
    removeHiddenFolder,
    resetHiddenFolders,
    showSearchControls: prefs.showSearchControls,
    setShowSearchControls,
  };
}
