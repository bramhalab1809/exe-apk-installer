import workerUrl from 'pdfjs-dist/build/pdf.worker.min.mjs?url';

export type PdfjsModule = typeof import('pdfjs-dist');
export type PDFDocumentProxy = import('pdfjs-dist').PDFDocumentProxy;
export type PDFDocumentLoadingTask = import('pdfjs-dist').PDFDocumentLoadingTask;

let pdfjsPromise: Promise<PdfjsModule> | null = null;
let workerConfigured = false;

export async function loadPdfjs(): Promise<PdfjsModule> {
  if (!pdfjsPromise) {
    pdfjsPromise = import('pdfjs-dist').then((mod) => {
      if (!workerConfigured) {
        mod.GlobalWorkerOptions.workerSrc = workerUrl;
        workerConfigured = true;
      }
      return mod;
    });
  }
  return pdfjsPromise;
}

export function isRecoverablePdfError(err: unknown): boolean {
  if (!err || typeof err !== 'object') return false;
  const e = err as { name?: string; message?: string };
  const name = typeof e.name === 'string' ? e.name : '';
  const msg = typeof e.message === 'string' ? e.message : '';

  if (
    name === 'UnexpectedResponseException' ||
    name === 'NetworkError' ||
    name === 'MissingPDFException'
  ) {
    return true;
  }

  if (
    msg.includes('403') ||
    msg.includes('410') ||
    msg.includes('Failed to fetch') ||
    msg.includes('NetworkError')
  ) {
    return true;
  }

  return false;
}
