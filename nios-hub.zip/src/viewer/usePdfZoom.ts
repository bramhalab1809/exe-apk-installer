import { useEffect, useRef, Dispatch, SetStateAction, RefObject } from 'react';

export function usePdfZoom(
  scrollContainerRef: RefObject<HTMLDivElement | null>,
  zoom: number,
  setZoom: Dispatch<SetStateAction<number>>,
  status: string
) {
  const zoomRef = useRef<number>(zoom);
  zoomRef.current = zoom;
  const pinchStartRef = useRef<{ dist: number; startZoom: number } | null>(null);
  const lastTapRef = useRef<number>(0);

  useEffect(() => {
    const el = scrollContainerRef.current;
    if (!el) return;

    const handleWheel = (e: WheelEvent) => {
      if (e.ctrlKey || e.metaKey) {
        e.preventDefault();
        const delta = e.deltaY < 0 ? 0.25 : -0.25;
        setZoom((z) => Math.min(3, Math.max(0.5, Math.round((z + delta) * 100) / 100)));
      }
    };

    const getTouchDist = (t: TouchList) => Math.hypot(t[0].clientX - t[1].clientX, t[0].clientY - t[1].clientY);

    const handleTouchStart = (e: TouchEvent) => {
      if (e.touches.length === 2) {
        pinchStartRef.current = { dist: getTouchDist(e.touches), startZoom: zoomRef.current };
      } else if (e.touches.length === 1) {
        const now = Date.now();
        if (now - lastTapRef.current < 280) {
          setZoom((z) => (z > 1.1 ? 1 : 1.75));
          lastTapRef.current = 0;
        } else {
          lastTapRef.current = now;
        }
      }
    };

    const handleTouchMove = (e: TouchEvent) => {
      if (e.touches.length === 2 && pinchStartRef.current && pinchStartRef.current.dist > 0) {
        e.preventDefault();
        const ratio = getTouchDist(e.touches) / pinchStartRef.current.dist;
        const nextZoom = Math.min(3, Math.max(0.5, Math.round(pinchStartRef.current.startZoom * ratio * 20) / 20));
        setZoom(nextZoom);
      }
    };

    const handleTouchEnd = () => {
      pinchStartRef.current = null;
    };

    el.addEventListener('wheel', handleWheel, { passive: false });
    el.addEventListener('touchstart', handleTouchStart, { passive: true });
    el.addEventListener('touchmove', handleTouchMove, { passive: false });
    el.addEventListener('touchend', handleTouchEnd);
    return () => {
      el.removeEventListener('wheel', handleWheel);
      el.removeEventListener('touchstart', handleTouchStart);
      el.removeEventListener('touchmove', handleTouchMove);
      el.removeEventListener('touchend', handleTouchEnd);
    };
  }, [scrollContainerRef, setZoom, status]);
}
