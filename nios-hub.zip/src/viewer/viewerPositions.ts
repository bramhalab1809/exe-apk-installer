const POS_STORAGE_KEY = 'nioshub.pos';
const MAX_POS_ENTRIES = 200;

export interface PositionEntry {
  page: number;
  t: number;
}

type PositionMap = Record<string, PositionEntry>;

function readPositionMap(): PositionMap {
  try {
    const raw = localStorage.getItem(POS_STORAGE_KEY);
    if (!raw) return {};
    const parsed = JSON.parse(raw) as unknown;
    if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) {
      return {};
    }
    const result: PositionMap = {};
    for (const [key, val] of Object.entries(parsed as Record<string, unknown>)) {
      if (val && typeof val === 'object' && !Array.isArray(val)) {
        const entry = val as { page?: unknown; t?: unknown };
        if (
          typeof entry.page === 'number' &&
          Number.isFinite(entry.page) &&
          entry.page >= 1 &&
          typeof entry.t === 'number' &&
          Number.isFinite(entry.t)
        ) {
          result[key] = { page: Math.floor(entry.page), t: entry.t };
        }
      }
    }
    return result;
  } catch {
    return {};
  }
}

export function getSavedPage(path: string): number {
  if (!path) return 1;
  try {
    const map = readPositionMap();
    const entry = map[path];
    if (entry && entry.page >= 1) {
      return entry.page;
    }
    return 1;
  } catch {
    return 1;
  }
}

export function savePagePosition(path: string, page: number): void {
  if (!path || typeof page !== 'number' || !Number.isFinite(page) || page < 1) {
    return;
  }
  try {
    const map = readPositionMap();
    map[path] = {
      page: Math.floor(page),
      t: Date.now(),
    };

    const entries = Object.entries(map);
    if (entries.length > MAX_POS_ENTRIES) {
      entries.sort((a, b) => b[1].t - a[1].t);
      const trimmed: PositionMap = {};
      for (let i = 0; i < MAX_POS_ENTRIES; i++) {
        const [k, v] = entries[i];
        trimmed[k] = v;
      }
      localStorage.setItem(POS_STORAGE_KEY, JSON.stringify(trimmed));
    } else {
      localStorage.setItem(POS_STORAGE_KEY, JSON.stringify(map));
    }
  } catch {
    // Ignore storage errors in private browsing or quota exhaustion
  }
}
