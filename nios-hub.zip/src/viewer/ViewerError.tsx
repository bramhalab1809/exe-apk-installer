import { AlertCircle, RotateCw, ExternalLink, Download } from '../icons/index.ts';
import { fileUrl } from '../data/hfApi.ts';

export interface ViewerErrorProps {
  path: string;
  onRetry?: () => void;
  showDownload?: boolean;
}

export function ViewerError({ path, onRetry, showDownload = false }: ViewerErrorProps) {
  return (
    <div className="flex flex-1 flex-col items-center justify-center min-h-[240px] p-6 gap-3 text-center select-none">
      <AlertCircle className="h-10 w-10 text-[#EF4444]" />
      <span className="text-[15px] font-medium text-[#78716C] dark:text-[#A8A29E]">
        Could not load
      </span>

      <div className="flex flex-wrap items-center justify-center gap-2 mt-1">
        {onRetry && (
          <button
            type="button"
            onClick={onRetry}
            aria-label="Retry"
            title="Retry"
            className="flex h-9 w-9 items-center justify-center rounded-[8px] border border-[#E7E5E4] dark:border-[#292524] text-[#78716C] dark:text-[#A8A29E] hover:bg-[#F5F5F4] dark:hover:bg-[#292524] hover:text-[#1C1917] dark:hover:text-[#FAFAF9] transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#F59E0B]"
          >
            <RotateCw className="h-4 w-4" />
          </button>
        )}

        {showDownload && (
          <a
            href={fileUrl(path, { download: true })}
            download
            aria-label="Download"
            title="Download"
            className="flex h-9 w-9 items-center justify-center rounded-[8px] border border-[#E7E5E4] dark:border-[#292524] text-[#78716C] dark:text-[#A8A29E] hover:bg-[#F5F5F4] dark:hover:bg-[#292524] hover:text-[#1C1917] dark:hover:text-[#FAFAF9] transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#F59E0B]"
          >
            <Download className="h-4 w-4" />
          </a>
        )}

        <a
          href={fileUrl(path)}
          target="_blank"
          rel="noopener noreferrer"
          className="inline-flex h-9 items-center gap-1.5 px-3 rounded-[8px] border border-[#E7E5E4] dark:border-[#292524] text-[13px] font-medium text-[#1C1917] dark:text-[#FAFAF9] hover:bg-[#F5F5F4] dark:hover:bg-[#292524] transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#F59E0B]"
        >
          <ExternalLink className="h-4 w-4" />
          <span>Open raw file</span>
        </a>
      </div>
    </div>
  );
}
