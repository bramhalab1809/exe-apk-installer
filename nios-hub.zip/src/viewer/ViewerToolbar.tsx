import {
  ChevronLeft,
  ChevronRight,
  ExternalLink,
  Download,
  Maximize2,
  Minimize2,
  X,
  RotateCw,
  Star,
} from '../icons/index.ts';
import { Kind } from '../data/types.ts';
import { fileUrl } from '../data/hfApi.ts';
import { folderHref } from '../router/hashRoute.ts';
import { fileLinkProps } from '../lib/fileLink.ts';

export interface ViewerToolbarProps {
  path: string;
  fileName: string;
  kind: Kind;
  prevPath: string | null;
  nextPath: string | null;
  isStarred?: boolean;
  onToggleStar?: (item: { name: string; path: string; isFolder: boolean; kind: Kind }) => void;
  recovering: boolean;
  isFullscreen: boolean;
  canFullscreen: boolean;
  toggleFullscreen: () => void;
  closeHref: string;
  handleOpenInBrowserTab: () => void;
  parentPath: string;
}

const btnClass =
  'flex h-8 w-8 sm:h-9 sm:w-9 shrink-0 items-center justify-center rounded-[8px] text-[#78716C] dark:text-[#A8A29E] hover:bg-[#F5F5F4] dark:hover:bg-[#292524] hover:text-[#1C1917] dark:hover:text-[#FAFAF9] transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#F59E0B]';

export function ViewerToolbar({
  path,
  fileName,
  kind,
  prevPath,
  nextPath,
  isStarred = false,
  onToggleStar,
  recovering,
  isFullscreen,
  canFullscreen,
  toggleFullscreen,
  closeHref,
  handleOpenInBrowserTab,
  parentPath,
}: ViewerToolbarProps) {
  const parentSegments = (parentPath || 'Home')
    .split('/')
    .filter(Boolean)
    .map((part, idx, arr) => ({
      name: part,
      path: arr.slice(0, idx + 1).join('/'),
    }));

  return (
    <div className="flex h-12 w-full items-center justify-between gap-1.5 sm:gap-2 px-2 shrink-0 border-b border-[#E7E5E4] dark:border-[#292524] bg-white dark:bg-[#1C1917]">
      <div className="flex items-center gap-0.5 sm:gap-1 min-w-0 flex-1">
        {prevPath ? (
          <a {...fileLinkProps(prevPath)} aria-label="Previous file" title="Previous file" className={btnClass}>
            <ChevronLeft className="h-5 w-5" />
          </a>
        ) : (
          <button type="button" disabled aria-label="Previous file" title="Previous file" className={`${btnClass} opacity-40 pointer-events-none`}>
            <ChevronLeft className="h-5 w-5" />
          </button>
        )}

        {nextPath ? (
          <a {...fileLinkProps(nextPath)} aria-label="Next file" title="Next file" className={btnClass}>
            <ChevronRight className="h-5 w-5" />
          </a>
        ) : (
          <button type="button" disabled aria-label="Next file" title="Next file" className={`${btnClass} opacity-40 pointer-events-none`}>
            <ChevronRight className="h-5 w-5" />
          </button>
        )}

        <div className="flex flex-col min-w-0 flex-1 pl-1">
          <span title={fileName} className="text-[13px] font-medium text-[#1C1917] dark:text-[#FAFAF9] truncate leading-tight">
            {fileName}
          </span>
          <div className="flex items-center gap-0.5 text-[11px] text-[#78716C] dark:text-[#A8A29E] overflow-hidden whitespace-nowrap leading-tight min-w-0">
            {parentSegments.length <= 3 ? (
              parentSegments.map((seg, i) => (
                <span key={seg.path} className="inline-flex items-center min-w-0">
                  {i > 0 && <span className="mx-0.5 shrink-0">›</span>}
                  <a
                    href={seg.path.toLowerCase() === 'home' ? '#/' : folderHref(seg.path)}
                    title={`Go to ${seg.name}`}
                    className="hover:text-[#1C1917] dark:hover:text-[#FAFAF9] hover:underline focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-[#F59E0B] rounded truncate max-w-[100px] sm:max-w-[160px]"
                  >
                    {seg.name}
                  </a>
                </span>
              ))
            ) : (
              <>
                <a
                  href={parentSegments[0].path.toLowerCase() === 'home' ? '#/' : folderHref(parentSegments[0].path)}
                  title={`Go to ${parentSegments[0].name}`}
                  className="hover:text-[#1C1917] dark:hover:text-[#FAFAF9] hover:underline focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-[#F59E0B] rounded shrink-0"
                >
                  {parentSegments[0].name}
                </a>
                <span className="mx-0.5 shrink-0">›</span>
                <a
                  href={folderHref(parentSegments[parentSegments.length - 2].path)}
                  title={`Go to ${parentSegments[parentSegments.length - 2].name}`}
                  className="hover:text-[#1C1917] dark:hover:text-[#FAFAF9] hover:underline focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-[#F59E0B] rounded shrink-0"
                >
                  •••
                </a>
                <span className="mx-0.5 shrink-0">›</span>
                <a
                  href={folderHref(parentSegments[parentSegments.length - 1].path)}
                  title={`Go to ${parentSegments[parentSegments.length - 1].name}`}
                  className="hover:text-[#1C1917] dark:hover:text-[#FAFAF9] hover:underline focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-[#F59E0B] rounded truncate min-w-0"
                >
                  {parentSegments[parentSegments.length - 1].name}
                </a>
              </>
            )}
          </div>
        </div>
      </div>

      <div className="flex items-center gap-0.5 shrink-0">
        {recovering && (
          <span aria-label="Recovering" title="Recovering" className="flex h-8 w-8 sm:h-9 sm:w-9 items-center justify-center text-[#F59E0B]">
            <RotateCw className="h-4 w-4 animate-spin" />
          </span>
        )}

        {onToggleStar && (
          <button
            type="button"
            onClick={() => onToggleStar({ name: fileName, path, isFolder: false, kind })}
            aria-label={isStarred ? 'Remove from Starred' : 'Add to Starred'}
            title={isStarred ? 'Remove from Starred' : 'Add to Starred'}
            className={btnClass}
          >
            <Star className={`h-4 w-4 ${isStarred ? 'fill-[#F59E0B] text-[#F59E0B]' : ''}`} />
          </button>
        )}

        <a
          href={fileUrl(path)}
          target="_blank"
          rel="noopener noreferrer"
          aria-label="Open in browser tab"
          title="Open in browser tab"
          onClick={handleOpenInBrowserTab}
          onAuxClick={handleOpenInBrowserTab}
          className={btnClass}
        >
          <ExternalLink className="h-4 w-4" />
        </a>

        <a
          href={fileUrl(path, { download: true })}
          download
          aria-label="Download"
          title="Download"
          className={btnClass}
        >
          <Download className="h-4 w-4" />
        </a>

        {canFullscreen && (
          <button
            type="button"
            onClick={toggleFullscreen}
            aria-label={isFullscreen ? 'Exit fullscreen' : 'Fullscreen'}
            title={isFullscreen ? 'Exit fullscreen' : 'Fullscreen'}
            className={btnClass}
          >
            {isFullscreen ? <Minimize2 className="h-4 w-4" /> : <Maximize2 className="h-4 w-4" />}
          </button>
        )}

        <a href={closeHref} aria-label="Close" title="Close" className={btnClass}>
          <X className="h-4 w-4" />
        </a>
      </div>
    </div>
  );
}
