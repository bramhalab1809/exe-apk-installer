import { useState, useEffect, useRef, useMemo } from 'react';
import { ZoomIn, ZoomOut } from '../icons/index.ts';
import { fileUrl } from '../data/hfApi.ts';
import { ViewerError } from './ViewerError.tsx';

export interface ImageViewerProps {
  path: string;
}

export function ImageViewer({ path }: ImageViewerProps) {
  const [zoom, setZoom] = useState<number>(1);
  const [errorCount, setErrorCount] = useState<number>(0);
  const [failed, setFailed] = useState<boolean>(false);
  const [retrySeed, setRetrySeed] = useState<number>(0);

  const containerRef = useRef<HTMLDivElement | null>(null);
  const timerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const zoomRef = useRef<number>(zoom);
  zoomRef.current = zoom;
  const pinchStartRef = useRef<{ dist: number; startZoom: number } | null>(null);
  const lastTapRef = useRef<number>(0);

  useEffect(() => {
    setZoom(1);
    setErrorCount(0);
    setFailed(false);
    return () => {
      if (timerRef.current) clearTimeout(timerRef.current);
    };
  }, [path]);

  useEffect(() => {
    const el = containerRef.current;
    if (!el) return;

    const handleWheel = (e: WheelEvent) => {
      if (e.ctrlKey || e.metaKey) {
        e.preventDefault();
        setZoom((z) => {
          const delta = e.deltaY < 0 ? 0.5 : -0.5;
          return Math.min(5, Math.max(1, Math.round((z + delta) * 100) / 100));
        });
      }
    };

    const getTouchDist = (t: TouchList) =>
      Math.hypot(t[0].clientX - t[1].clientX, t[0].clientY - t[1].clientY);

    const handleTouchStart = (e: TouchEvent) => {
      if (e.touches.length === 2) {
        pinchStartRef.current = { dist: getTouchDist(e.touches), startZoom: zoomRef.current };
      } else if (e.touches.length === 1) {
        const now = Date.now();
        if (now - lastTapRef.current < 280) {
          setZoom((z) => (z > 1.1 ? 1 : 2));
          lastTapRef.current = 0;
        } else {
          lastTapRef.current = now;
        }
      }
    };

    const handleTouchMove = (e: TouchEvent) => {
      if (e.touches.length === 2 && pinchStartRef.current && pinchStartRef.current.dist > 0) {
        e.preventDefault();
        const ratio = getTouchDist(e.touches) / pinchStartRef.current.dist;
        const nextZoom = Math.min(
          5,
          Math.max(1, Math.round(pinchStartRef.current.startZoom * ratio * 20) / 20)
        );
        setZoom(nextZoom);
      }
    };

    const handleTouchEnd = () => {
      pinchStartRef.current = null;
    };

    el.addEventListener('wheel', handleWheel, { passive: false });
    el.addEventListener('touchstart', handleTouchStart, { passive: true });
    el.addEventListener('touchmove', handleTouchMove, { passive: false });
    el.addEventListener('touchend', handleTouchEnd);
    return () => {
      el.removeEventListener('wheel', handleWheel);
      el.removeEventListener('touchstart', handleTouchStart);
      el.removeEventListener('touchmove', handleTouchMove);
      el.removeEventListener('touchend', handleTouchEnd);
    };
  }, [failed]);

  const src = useMemo(() => {
    const useBust = errorCount > 0 || retrySeed > 0;
    return fileUrl(path, useBust ? { bust: true } : undefined);
  }, [path, errorCount, retrySeed]);

  const handleImgError = () => {
    if (errorCount < 2) {
      if (timerRef.current) clearTimeout(timerRef.current);
      timerRef.current = setTimeout(() => {
        setErrorCount((c) => c + 1);
      }, 300);
    } else {
      setFailed(true);
    }
  };

  const handleManualRetry = () => {
    setFailed(false);
    setErrorCount(0);
    setRetrySeed((s) => s + 1);
  };

  if (failed) {
    return <ViewerError path={path} onRetry={handleManualRetry} />;
  }

  const fileName = path.split('/').pop() || path;

  return (
    <div className="relative flex flex-1 flex-col w-full h-full min-h-0 overflow-hidden bg-[#F5F5F4] dark:bg-[#0C0A09]">
      <div
        ref={containerRef}
        style={{ touchAction: 'pan-x pan-y' }}
        className="flex-1 w-full h-full overflow-auto p-4"
      >
        <div className="w-fit min-w-full min-h-full flex items-center justify-center">
          <img
            src={src}
            alt={fileName}
            onError={handleImgError}
            style={{ width: `${zoom * 100}%` }}
            className={`object-contain select-none ${
              zoom === 1 ? 'max-h-full max-w-full' : 'max-w-none'
            }`}
          />
        </div>
      </div>

      {/* Centered floating zoom bar */}
      <div className="absolute bottom-3 left-1/2 -translate-x-1/2 z-10 flex items-center gap-1 px-2 h-8 sm:h-9 max-w-[calc(100%-16px)] whitespace-nowrap rounded-full border border-[#E7E5E4] dark:border-[#292524] bg-white/95 dark:bg-[#1C1917]/95 shadow-sm select-none">
        <button
          type="button"
          disabled={zoom <= 1}
          onClick={() => setZoom((z) => Math.max(1, Math.round((z - 0.5) * 100) / 100))}
          aria-label="Zoom out"
          title="Zoom out"
          className="flex h-7 w-7 items-center justify-center rounded-full text-[#78716C] dark:text-[#A8A29E] hover:bg-[#F5F5F4] dark:hover:bg-[#292524] hover:text-[#1C1917] dark:hover:text-[#FAFAF9] disabled:opacity-40 disabled:pointer-events-none transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#F59E0B]"
        >
          <ZoomOut className="h-4 w-4" />
        </button>

        <button
          type="button"
          onClick={() => setZoom(1)}
          aria-label="Reset zoom"
          title="Reset zoom"
          className="px-2 h-7 rounded-full text-[12px] font-medium tabular-nums text-[#1C1917] dark:text-[#FAFAF9] hover:bg-[#F5F5F4] dark:hover:bg-[#292524] transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#F59E0B]"
        >
          {Math.round(zoom * 100)}%
        </button>

        <button
          type="button"
          disabled={zoom >= 5}
          onClick={() => setZoom((z) => Math.min(5, Math.round((z + 0.5) * 100) / 100))}
          aria-label="Zoom in"
          title="Zoom in"
          className="flex h-7 w-7 items-center justify-center rounded-full text-[#78716C] dark:text-[#A8A29E] hover:bg-[#F5F5F4] dark:hover:bg-[#292524] hover:text-[#1C1917] dark:hover:text-[#FAFAF9] disabled:opacity-40 disabled:pointer-events-none transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#F59E0B]"
        >
          <ZoomIn className="h-4 w-4" />
        </button>
      </div>
    </div>
  );
}
