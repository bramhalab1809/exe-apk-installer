import { Download, ExternalLink } from '../icons/index.ts';
import { fileUrl } from '../data/hfApi.ts';
import { FileIcon } from '../components/FileIcon.tsx';

export interface OtherViewerProps {
  path: string;
}

export function OtherViewer({ path }: OtherViewerProps) {
  const fileName = path.split('/').pop() || path;

  return (
    <div className="flex flex-1 flex-col items-center justify-center p-6 gap-4 text-center select-none">
      <FileIcon name={fileName} kind="other" width={96} height={80} />

      <span className="text-[15px] font-medium text-[#1C1917] dark:text-[#FAFAF9] break-all max-w-md">
        {fileName}
      </span>

      <div className="flex flex-col items-center gap-2 mt-1">
        <a
          href={fileUrl(path, { download: true })}
          download
          aria-label="Download"
          title="Download"
          className="flex h-12 w-12 items-center justify-center rounded-[12px] bg-[#1C1917] dark:bg-[#FAFAF9] text-[#FAFAF9] dark:text-[#1C1917] hover:opacity-90 transition-opacity focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#F59E0B]"
        >
          <Download className="h-6 w-6" />
        </a>

        <a
          href={fileUrl(path)}
          target="_blank"
          rel="noopener noreferrer"
          className="inline-flex h-9 items-center gap-1.5 px-3 rounded-[8px] text-[13px] font-medium text-[#78716C] dark:text-[#A8A29E] hover:text-[#1C1917] dark:hover:text-[#FAFAF9] hover:bg-[#F5F5F4] dark:hover:bg-[#292524] transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#F59E0B]"
        >
          <ExternalLink className="h-4 w-4" />
          <span>Open raw file</span>
        </a>
      </div>
    </div>
  );
}
