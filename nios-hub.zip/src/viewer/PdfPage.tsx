import { useState, useEffect, useRef } from 'react';
import { PDFDocumentProxy, isRecoverablePdfError } from './pdfSetup.ts';

export interface PdfPageProps {
  doc: PDFDocumentProxy;
  pageNumber: number;
  displayWidth: number;
  defaultAspect: number;
  scrollRoot: HTMLElement | null;
  onRecover: () => void;
}

export function PdfPage({
  doc,
  pageNumber,
  displayWidth,
  defaultAspect,
  scrollRoot,
  onRecover,
}: PdfPageProps) {
  const [pageAspect, setPageAspect] = useState<number | null>(null);
  const [isNear, setIsNear] = useState<boolean>(pageNumber <= 2);

  const containerRef = useRef<HTMLDivElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const renderTaskRef = useRef<{ cancel: () => void; promise: Promise<void> } | null>(null);
  const renderedKeyRef = useRef<string | null>(null);
  const docRef = useRef<PDFDocumentProxy>(doc);

  if (docRef.current !== doc) {
    docRef.current = doc;
    renderedKeyRef.current = null;
  }

  useEffect(() => {
    const el = containerRef.current;
    if (!el || !scrollRoot) return;

    const nearObserver = new IntersectionObserver(
      (entries) => {
        const entry = entries[0];
        if (!entry) return;
        setIsNear(entry.isIntersecting);
        if (!entry.isIntersecting && renderTaskRef.current) {
          renderTaskRef.current.cancel();
          renderTaskRef.current = null;
        }
      },
      { root: scrollRoot, rootMargin: '100% 0px' }
    );

    const evictionObserver = new IntersectionObserver(
      (entries) => {
        const entry = entries[0];
        if (!entry) return;
        if (!entry.isIntersecting) {
          if (renderTaskRef.current) {
            renderTaskRef.current.cancel();
            renderTaskRef.current = null;
          }
          renderedKeyRef.current = null;
          if (canvasRef.current) {
            canvasRef.current.width = 0;
            canvasRef.current.height = 0;
          }
        }
      },
      { root: scrollRoot, rootMargin: '300% 0px' }
    );

    nearObserver.observe(el);
    evictionObserver.observe(el);

    return () => {
      nearObserver.disconnect();
      evictionObserver.disconnect();
    };
  }, [scrollRoot]);

  useEffect(() => {
    if (!isNear || displayWidth <= 0) return;

    const dpr = Math.min(typeof window !== 'undefined' ? window.devicePixelRatio || 1 : 1, 2);
    const targetKey = `${displayWidth}@${dpr}`;

    if (
      renderedKeyRef.current === targetKey &&
      canvasRef.current &&
      canvasRef.current.width > 0
    ) {
      return;
    }

    let cancelled = false;

    const renderPage = async () => {
      try {
        const page = await doc.getPage(pageNumber);
        if (cancelled) return;

        const unitViewport = page.getViewport({ scale: 1 });
        if (unitViewport.width > 0 && unitViewport.height > 0) {
          const ratio = unitViewport.height / unitViewport.width;
          setPageAspect((prev) => (prev !== null && Math.abs(prev - ratio) < 0.001 ? prev : ratio));
        }

        const cssScale = displayWidth / (unitViewport.width || 1);
        const renderViewport = page.getViewport({ scale: cssScale * dpr });

        const canvas = canvasRef.current;
        if (!canvas || cancelled) return;

        if (renderTaskRef.current) {
          renderTaskRef.current.cancel();
          renderTaskRef.current = null;
        }

        const widthPx = Math.max(1, Math.floor(renderViewport.width));
        const heightPx = Math.max(1, Math.floor(renderViewport.height));
        canvas.width = widthPx;
        canvas.height = heightPx;

        const ctx = canvas.getContext('2d');
        if (!ctx) return;

        const task = page.render({
          canvasContext: ctx,
          canvas,
          viewport: renderViewport,
        });
        renderTaskRef.current = task;

        await task.promise;
        if (!cancelled) {
          renderedKeyRef.current = targetKey;
          renderTaskRef.current = null;
        }
      } catch (err: unknown) {
        if (cancelled) return;
        const errName =
          err && typeof err === 'object' && 'name' in err
            ? String((err as { name?: unknown }).name)
            : '';
        if (errName === 'RenderingCancelledException') {
          return;
        }
        if (isRecoverablePdfError(err)) {
          onRecover();
        }
      }
    };

    renderPage();

    return () => {
      cancelled = true;
      if (renderTaskRef.current) {
        renderTaskRef.current.cancel();
        renderTaskRef.current = null;
      }
    };
  }, [doc, pageNumber, displayWidth, isNear, onRecover]);

  const effectiveAspect = pageAspect ?? defaultAspect;
  const displayHeight = Math.max(100, Math.round(displayWidth * effectiveAspect));

  return (
    <div
      ref={containerRef}
      data-page-number={pageNumber}
      style={{ width: `${displayWidth}px`, height: `${displayHeight}px` }}
      className="relative shrink-0 bg-white shadow-sm border border-[#E7E5E4] dark:border-[#292524] overflow-hidden select-none"
    >
      <canvas
        ref={canvasRef}
        width={0}
        height={0}
        className="block w-full h-full pointer-events-none"
      />
    </div>
  );
}
