import { useState, useEffect, useCallback } from 'react';
import { File, Download } from '../icons/index.ts';
import { fileUrl } from '../data/hfApi.ts';
import { ViewerError } from './ViewerError.tsx';

export interface TextViewerProps {
  path: string;
}

const MAX_TEXT_BYTES = 2 * 1024 * 1024;

export function TextViewer({ path }: TextViewerProps) {
  const [status, setStatus] = useState<'loading' | 'ready' | 'tooLarge' | 'error'>('loading');
  const [text, setText] = useState<string>('');
  const [reloadCount, setReloadCount] = useState<number>(0);

  const handleRetry = useCallback(() => {
    setReloadCount((c) => c + 1);
  }, []);

  useEffect(() => {
    let cancelled = false;
    const controller = new AbortController();

    setStatus('loading');
    setText('');

    const url = fileUrl(path, reloadCount > 0 ? { bust: true } : undefined);

    fetch(url, { signal: controller.signal })
      .then(async (res) => {
        if (!res.ok) {
          throw new Error(`HTTP ${res.status}`);
        }

        const contentLength = Number(res.headers.get('content-length') || '0');
        if (contentLength > MAX_TEXT_BYTES) {
          if (!cancelled) {
            controller.abort();
            setStatus('tooLarge');
          }
          return;
        }

        const bodyText = await res.text();
        if (cancelled) return;

        if (bodyText.length > MAX_TEXT_BYTES) {
          setStatus('tooLarge');
          return;
        }

        setText(bodyText);
        setStatus('ready');
      })
      .catch((err: unknown) => {
        if (cancelled || (err instanceof DOMException && err.name === 'AbortError')) {
          return;
        }
        setStatus('error');
      });

    return () => {
      cancelled = true;
      controller.abort();
    };
  }, [path, reloadCount]);

  if (status === 'error') {
    return <ViewerError path={path} onRetry={handleRetry} />;
  }

  const fileName = path.split('/').pop() || path;

  if (status === 'tooLarge') {
    return (
      <div className="flex flex-1 flex-col items-center justify-center p-6 gap-4 text-center select-none">
        <File className="h-16 w-16 text-[#78716C] dark:text-[#A8A29E]" />
        <span className="text-[15px] font-medium text-[#1C1917] dark:text-[#FAFAF9] break-all max-w-md">
          {fileName}
        </span>
        <a
          href={fileUrl(path, { download: true })}
          download
          aria-label="Download"
          title="Download"
          className="inline-flex h-10 items-center gap-2 px-4 rounded-[8px] bg-[#1C1917] dark:bg-[#FAFAF9] text-[#FAFAF9] dark:text-[#1C1917] text-[13px] font-medium hover:opacity-90 transition-opacity focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#F59E0B]"
        >
          <Download className="h-4 w-4" />
          <span>Download</span>
        </a>
      </div>
    );
  }

  if (status === 'loading') {
    return (
      <div className="flex-1 w-full h-full overflow-auto p-6 flex flex-col gap-3">
        <div className="h-4 w-3/4 rounded bg-[#E7E5E4] dark:bg-[#292524] animate-pulse" />
        <div className="h-4 w-5/6 rounded bg-[#E7E5E4] dark:bg-[#292524] animate-pulse" />
        <div className="h-4 w-2/3 rounded bg-[#E7E5E4] dark:bg-[#292524] animate-pulse" />
        <div className="h-4 w-4/5 rounded bg-[#E7E5E4] dark:bg-[#292524] animate-pulse" />
      </div>
    );
  }

  return (
    <div className="flex-1 w-full h-full overflow-auto p-6 select-text">
      <pre className="whitespace-pre-wrap break-words font-mono text-sm text-[#1C1917] dark:text-[#FAFAF9]">
        {text}
      </pre>
    </div>
  );
}
