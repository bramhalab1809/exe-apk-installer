import { lazy, Suspense, useState, useEffect, useRef } from 'react';
import { Kind } from '../data/types.ts';
import { kindOf } from '../data/fileKinds.ts';
import { folderHref, parentOf } from '../router/hashRoute.ts';
import { useSiblings } from '../hooks/useSiblings.ts';
import { ImageViewer } from './ImageViewer.tsx';
import { MediaViewer } from './MediaViewer.tsx';
import { TextViewer } from './TextViewer.tsx';
import { OtherViewer } from './OtherViewer.tsx';
import { ViewerToolbar } from './ViewerToolbar.tsx';

const PdfViewer = lazy(() => import('./PdfViewer.tsx'));

export interface FileViewerProps {
  path: string;
  isStarred?: boolean;
  onToggleStar?: (item: { name: string; path: string; isFolder: boolean; kind: Kind }) => void;
}

export function FileViewer({ path, isStarred = false, onToggleStar }: FileViewerProps) {
  const { parentPath, prevPath, nextPath } = useSiblings(path);
  const [isFullscreen, setIsFullscreen] = useState<boolean>(false);
  const [recovering, setRecovering] = useState<boolean>(false);
  const containerRef = useRef<HTMLDivElement | null>(null);

  const fileName = path.split('/').pop() || path;
  const kind = kindOf(fileName);
  const closeHref = folderHref(parentOf(path));
  const canFullscreen = typeof document !== 'undefined' && Boolean(document.fullscreenEnabled);

  useEffect(() => {
    setRecovering(false);
  }, [path]);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && !document.fullscreenElement) {
        window.location.hash = folderHref(parentOf(path));
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [path]);

  useEffect(() => {
    const onFsChange = () => setIsFullscreen(Boolean(document.fullscreenElement));
    document.addEventListener('fullscreenchange', onFsChange);
    return () => document.removeEventListener('fullscreenchange', onFsChange);
  }, []);

  const toggleFullscreen = () => {
    if (!canFullscreen) return;
    if (!document.fullscreenElement) {
      containerRef.current?.requestFullscreen?.().catch(() => {});
    } else {
      document.exitFullscreen?.().catch(() => {});
    }
  };

  const handleOpenInBrowserTab = () => {
    setTimeout(() => {
      window.location.hash = folderHref(parentOf(path));
    }, 0);
  };

  return (
    <div
      ref={containerRef}
      className="flex flex-1 flex-col w-full h-full min-h-0 overflow-hidden bg-white dark:bg-[#1C1917]"
    >
      <ViewerToolbar
        path={path}
        fileName={fileName}
        kind={kind}
        prevPath={prevPath}
        nextPath={nextPath}
        isStarred={isStarred}
        onToggleStar={onToggleStar}
        recovering={recovering}
        isFullscreen={isFullscreen}
        canFullscreen={canFullscreen}
        toggleFullscreen={toggleFullscreen}
        closeHref={closeHref}
        handleOpenInBrowserTab={handleOpenInBrowserTab}
        parentPath={parentPath}
      />

      {kind === 'pdf' && (
        <Suspense
          fallback={
            <div className="flex-1 w-full h-full flex items-center justify-center p-6 bg-[#F5F5F4] dark:bg-[#0C0A09]">
              <div className="w-full max-w-[720px] h-full rounded-lg bg-[#E7E5E4] dark:bg-[#292524] animate-pulse" />
            </div>
          }
        >
          <PdfViewer path={path} onRecoveringChange={setRecovering} />
        </Suspense>
      )}
      {kind === 'image' && <ImageViewer path={path} />}
      {(kind === 'video' || kind === 'audio') && <MediaViewer path={path} kind={kind} />}
      {kind === 'text' && <TextViewer path={path} />}
      {kind === 'other' && <OtherViewer path={path} />}
    </div>
  );
}
