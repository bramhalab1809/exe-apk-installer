import { useState, useEffect, useRef } from 'react';
import { Music } from '../icons/index.ts';
import { fileUrl } from '../data/hfApi.ts';
import { ViewerError } from './ViewerError.tsx';

export interface MediaViewerProps {
  path: string;
  kind: 'video' | 'audio';
}

const RETRY_WINDOW_MS = 60 * 1000;
const MAX_RETRIES_IN_WINDOW = 3;

export function MediaViewer({ path, kind }: MediaViewerProps) {
  const [failed, setFailed] = useState<boolean>(false);

  const videoRef = useRef<HTMLVideoElement | null>(null);
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const savedTimeRef = useRef<number>(0);
  const wasPlayingRef = useRef<boolean>(false);
  const needsRestoreRef = useRef<boolean>(false);
  const retryTimesRef = useRef<number[]>([]);
  const retryTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => {
    setFailed(false);
    savedTimeRef.current = 0;
    wasPlayingRef.current = false;
    needsRestoreRef.current = false;
    retryTimesRef.current = [];
    return () => {
      if (retryTimerRef.current) clearTimeout(retryTimerRef.current);
    };
  }, [path, kind]);

  const getMediaElement = (): HTMLMediaElement | null => {
    return kind === 'video' ? videoRef.current : audioRef.current;
  };

  const handleTimeUpdate = () => {
    const el = getMediaElement();
    if (el && el.currentTime > 0) {
      savedTimeRef.current = el.currentTime;
    }
  };

  const handlePlay = () => {
    wasPlayingRef.current = true;
  };

  const handlePause = () => {
    const el = getMediaElement();
    if (el && !el.error && !el.ended) {
      wasPlayingRef.current = false;
    }
  };

  const handleLoadedMetadata = () => {
    const el = getMediaElement();
    if (!el || !needsRestoreRef.current) return;
    needsRestoreRef.current = false;

    if (savedTimeRef.current > 0) {
      try {
        el.currentTime = savedTimeRef.current;
      } catch {
        // Ignore seek failure if unseekable
      }
    }

    if (wasPlayingRef.current) {
      el.play().catch(() => {});
    }
  };

  const handleError = () => {
    const el = getMediaElement();
    if (el) {
      if (el.currentTime > 0) {
        savedTimeRef.current = el.currentTime;
      }
      if (!el.paused) {
        wasPlayingRef.current = true;
      }
    }

    const now = Date.now();
    retryTimesRef.current = retryTimesRef.current.filter((t) => now - t < RETRY_WINDOW_MS);

    if (retryTimesRef.current.length >= MAX_RETRIES_IN_WINDOW) {
      setFailed(true);
      return;
    }

    retryTimesRef.current.push(now);
    needsRestoreRef.current = true;

    if (retryTimerRef.current) clearTimeout(retryTimerRef.current);
    retryTimerRef.current = setTimeout(() => {
      const target = getMediaElement();
      if (!target) return;
      target.src = fileUrl(path, { bust: true });
      target.load();
    }, 350);
  };

  const handleManualRetry = () => {
    retryTimesRef.current = [];
    setFailed(false);
  };

  if (failed) {
    return <ViewerError path={path} onRetry={handleManualRetry} showDownload />;
  }

  const initialSrc = fileUrl(path);

  if (kind === 'audio') {
    return (
      <div className="flex flex-1 flex-col items-center justify-center p-6 gap-6 bg-[#F5F5F4] dark:bg-[#0C0A09]">
        <div className="flex h-24 w-24 items-center justify-center rounded-2xl bg-white dark:bg-[#1C1917] border border-[#E7E5E4] dark:border-[#292524] shadow-sm text-[#3B82F6]">
          <Music className="h-12 w-12" />
        </div>
        <audio
          ref={audioRef}
          src={initialSrc}
          controls
          preload="metadata"
          onTimeUpdate={handleTimeUpdate}
          onPlay={handlePlay}
          onPause={handlePause}
          onLoadedMetadata={handleLoadedMetadata}
          onError={handleError}
          className="w-full max-w-md focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#F59E0B] rounded-lg"
        />
      </div>
    );
  }

  return (
    <div className="flex flex-1 flex-col items-center justify-center p-4 min-h-0 overflow-hidden bg-[#F5F5F4] dark:bg-[#0C0A09]">
      <video
        ref={videoRef}
        src={initialSrc}
        controls
        playsInline
        preload="metadata"
        onTimeUpdate={handleTimeUpdate}
        onPlay={handlePlay}
        onPause={handlePause}
        onLoadedMetadata={handleLoadedMetadata}
        onError={handleError}
        className="max-w-full max-h-full rounded-lg bg-black focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#F59E0B]"
      />
    </div>
  );
}
