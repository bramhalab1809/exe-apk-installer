import React, { useState, useEffect, useLayoutEffect, useRef, useCallback } from 'react';
import { usePdfDocument } from './usePdfDocument.ts';
import { PdfPage } from './PdfPage.tsx';
import { PdfControls } from './PdfControls.tsx';
import { ViewerError } from './ViewerError.tsx';
import { getSavedPage, savePagePosition } from './viewerPositions.ts';
import { usePdfZoom } from './usePdfZoom.ts';

export interface PdfViewerProps {
  path: string;
  onRecoveringChange?: (recovering: boolean) => void;
}

const DEFAULT_ASPECT = 1.4142;

export default function PdfViewer({ path, onRecoveringChange }: PdfViewerProps) {
  const { doc, status, progress, recovering, retry, recover } = usePdfDocument(path);
  const [zoom, setZoom] = useState<number>(1);
  const [fitWidth, setFitWidth] = useState<number>(720);
  const [defaultAspect, setDefaultAspect] = useState<number>(DEFAULT_ASPECT);
  const [currentPage, setCurrentPage] = useState<number>(() => getSavedPage(path));
  const [scrollRoot, setScrollRoot] = useState<HTMLDivElement | null>(null);

  const scrollContainerRef = useRef<HTMLDivElement | null>(null);
  const currentPageRef = useRef<number>(currentPage);
  currentPageRef.current = currentPage;
  const lastSavedAtRef = useRef<number>(0);
  const saveTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const restoredForPathRef = useRef<string | null>(null);

  usePdfZoom(scrollContainerRef, zoom, setZoom, status);

  useEffect(() => {
    onRecoveringChange?.(recovering);
    return () => onRecoveringChange?.(false);
  }, [recovering, onRecoveringChange]);

  useEffect(() => {
    setZoom(1);
    setDefaultAspect(DEFAULT_ASPECT);
    const saved = getSavedPage(path);
    setCurrentPage(saved);
    currentPageRef.current = saved;
    restoredForPathRef.current = null;
  }, [path]);

  // Measure container width and handle mobile screen rotation smoothly
  useLayoutEffect(() => {
    const el = scrollContainerRef.current;
    if (!el) return;
    setScrollRoot(el);
    let lastClientW = el.clientWidth;

    const updateWidth = () => {
      if (!el || el.clientWidth <= 0) return;
      const newW = el.clientWidth;
      const rotated = Math.abs(newW - lastClientW) > 40;
      lastClientW = newW;
      setFitWidth(Math.max(140, Math.min(newW - 16, 1100)));
      if (rotated && restoredForPathRef.current === path) {
        const activePage = currentPageRef.current;
        requestAnimationFrame(() => {
          const targetEl = el.querySelector<HTMLElement>(`[data-page-number="${activePage}"]`);
          if (targetEl) el.scrollTop = targetEl.offsetTop;
        });
      }
    };

    updateWidth();
    const ro = new ResizeObserver(updateWidth);
    ro.observe(el);
    window.addEventListener('orientationchange', updateWidth);
    return () => {
      ro.disconnect();
      window.removeEventListener('orientationchange', updateWidth);
    };
  }, [status, path]);

  useEffect(() => {
    if (!doc) return;
    let cancelled = false;
    doc.getPage(1).then((p1) => {
      if (cancelled) return;
      const vp = p1.getViewport({ scale: 1 });
      if (vp.width > 0 && vp.height > 0) setDefaultAspect(vp.height / vp.width);
    }).catch(() => {});
    return () => { cancelled = true; };
  }, [doc]);

  useLayoutEffect(() => {
    if (!doc || status !== 'ready' || !scrollContainerRef.current || restoredForPathRef.current === path) return;
    restoredForPathRef.current = path;
    const saved = Math.min(Math.max(1, getSavedPage(path)), doc.numPages);
    setCurrentPage(saved);
    currentPageRef.current = saved;
    if (saved > 1) {
      requestAnimationFrame(() => {
        const container = scrollContainerRef.current;
        const targetEl = container?.querySelector<HTMLElement>(`[data-page-number="${saved}"]`);
        if (container && targetEl) container.scrollTop = targetEl.offsetTop;
      });
    } else {
      scrollContainerRef.current.scrollTop = 0;
    }
  }, [doc, status, path]);

  useEffect(() => {
    if (restoredForPathRef.current !== path) return;
    const now = Date.now();
    const elapsed = now - lastSavedAtRef.current;
    if (saveTimerRef.current) clearTimeout(saveTimerRef.current);
    if (elapsed >= 1000) {
      lastSavedAtRef.current = now;
      savePagePosition(path, currentPage);
    } else {
      saveTimerRef.current = setTimeout(() => {
        lastSavedAtRef.current = Date.now();
        savePagePosition(path, currentPageRef.current);
      }, 1000 - elapsed);
    }
  }, [path, currentPage]);

  useEffect(() => () => {
    if (saveTimerRef.current) clearTimeout(saveTimerRef.current);
    savePagePosition(path, currentPageRef.current);
  }, [path]);

  const handleScroll = useCallback(() => {
    const container = scrollContainerRef.current;
    if (!container || !doc) return;
    const probeY = container.scrollTop + container.clientHeight * 0.35;
    const pages = container.querySelectorAll<HTMLElement>('[data-page-number]');
    let bestPage = 1;
    for (let i = 0; i < pages.length; i++) {
      if (pages[i].offsetTop <= probeY) {
        bestPage = Number(pages[i].getAttribute('data-page-number')) || i + 1;
      } else break;
    }
    if (bestPage !== currentPageRef.current) setCurrentPage(bestPage);
  }, [doc]);

  const goToPage = useCallback((target: number) => {
    if (!doc || !scrollContainerRef.current) return;
    const clamped = Math.min(Math.max(1, target), doc.numPages);
    setCurrentPage(clamped);
    const pageEl = scrollContainerRef.current.querySelector<HTMLElement>(`[data-page-number="${clamped}"]`);
    if (pageEl) scrollContainerRef.current.scrollTop = pageEl.offsetTop;
  }, [doc]);

  const handleKeyDown = (e: React.KeyboardEvent<HTMLDivElement>) => {
    if (!doc) return;
    if (e.key === 'PageDown') { e.preventDefault(); goToPage(currentPage + 1); }
    else if (e.key === 'PageUp') { e.preventDefault(); goToPage(currentPage - 1); }
  };

  if (status === 'error') return <ViewerError path={path} onRetry={retry} />;

  const numPages = doc?.numPages || 0;
  const displayWidth = Math.max(140, Math.round(fitWidth * zoom));

  return (
    <div
      tabIndex={0}
      onKeyDown={handleKeyDown}
      className="relative flex flex-1 flex-col w-full h-full min-h-0 overflow-hidden bg-[#F5F5F4] dark:bg-[#0C0A09] focus-visible:outline-none"
    >
      {progress !== null && progress < 100 && (
        <div className="w-full h-1 bg-[#E7E5E4] dark:bg-[#292524] shrink-0 overflow-hidden">
          <div className="h-full bg-[#F59E0B] transition-all duration-150" style={{ width: `${Math.max(5, progress)}%` }} />
        </div>
      )}

      <div
        ref={scrollContainerRef}
        onScroll={handleScroll}
        style={{ touchAction: 'pan-x pan-y' }}
        className="flex-1 w-full h-full overflow-auto"
      >
        <div className="w-fit min-w-full flex flex-col items-center gap-3 py-4 px-2">
          {status === 'loading' || !doc ? (
            <div
              style={{ width: `${displayWidth}px`, height: `${Math.round(displayWidth * defaultAspect)}px` }}
              className="rounded-lg bg-[#E7E5E4] dark:bg-[#292524] animate-pulse shrink-0"
            />
          ) : (
            Array.from({ length: numPages }).map((_, idx) => (
              <PdfPage
                key={idx + 1}
                doc={doc}
                pageNumber={idx + 1}
                displayWidth={displayWidth}
                defaultAspect={defaultAspect}
                scrollRoot={scrollRoot}
                onRecover={recover}
              />
            ))
          )}
        </div>
      </div>

      {status === 'ready' && doc && numPages > 0 && (
        <PdfControls
          currentPage={currentPage}
          numPages={numPages}
          zoom={zoom}
          onPrevPage={() => goToPage(currentPage - 1)}
          onNextPage={() => goToPage(currentPage + 1)}
          onZoomOut={() => setZoom((z) => Math.max(0.5, Math.round((z - 0.25) * 100) / 100))}
          onZoomIn={() => setZoom((z) => Math.min(3, Math.round((z + 0.25) * 100) / 100))}
          onResetZoom={() => setZoom(1)}
        />
      )}
    </div>
  );
}
