import { useState, useEffect, useRef, useCallback } from 'react';
import { fileUrl } from '../data/hfApi.ts';
import { loadPdfjs, PDFDocumentProxy, PDFDocumentLoadingTask } from './pdfSetup.ts';

export type PdfStatus = 'loading' | 'ready' | 'error';

export interface UsePdfDocumentResult {
  doc: PDFDocumentProxy | null;
  status: PdfStatus;
  progress: number | null;
  recovering: boolean;
  retry: () => void;
  recover: () => void;
}

const RETRY_DELAYS = [600, 1500, 3000];
const RECOVERY_WINDOW_MS = 2 * 60 * 1000;
const MAX_RECOVERIES_IN_WINDOW = 3;
const HIDDEN_EXPIRY_MS = 20 * 60 * 1000;

export function usePdfDocument(path: string): UsePdfDocumentResult {
  const [doc, setDoc] = useState<PDFDocumentProxy | null>(null);
  const [status, setStatus] = useState<PdfStatus>('loading');
  const [progress, setProgress] = useState<number | null>(0);
  const [recovering, setRecovering] = useState<boolean>(false);

  const docRef = useRef<PDFDocumentProxy | null>(null);
  const taskRef = useRef<PDFDocumentLoadingTask | null>(null);
  const runIdRef = useRef<number>(0);
  const recoveringRef = useRef<boolean>(false);
  const recoveryTimesRef = useRef<number[]>([]);
  const hiddenAtRef = useRef<number | null>(null);

  const destroyCurrent = useCallback(() => {
    if (taskRef.current) {
      taskRef.current.destroy().catch(() => {});
      taskRef.current = null;
    }
    if (docRef.current) {
      docRef.current.cleanup().catch(() => {});
      docRef.current = null;
    }
  }, []);

  const loadWithRetries = useCallback(
    async (initialBust: boolean, isRecovery: boolean) => {
      const currentRun = ++runIdRef.current;

      if (!isRecovery) {
        destroyCurrent();
        setDoc(null);
        setStatus('loading');
        setProgress(0);
        setRecovering(false);
        recoveringRef.current = false;
      }

      for (let attempt = 0; attempt <= RETRY_DELAYS.length; attempt++) {
        if (runIdRef.current !== currentRun) return;

        if (attempt > 0) {
          const delay = RETRY_DELAYS[attempt - 1];
          await new Promise((resolve) => setTimeout(resolve, delay));
          if (runIdRef.current !== currentRun) return;
        }

        const useBust = initialBust || attempt > 0;
        let currentTask: PDFDocumentLoadingTask | null = null;

        try {
          const pdfjs = await loadPdfjs();
          if (runIdRef.current !== currentRun) return;

          if (taskRef.current) {
            taskRef.current.destroy().catch(() => {});
            taskRef.current = null;
          }

          currentTask = pdfjs.getDocument({
            url: fileUrl(path, { bust: useBust }),
            rangeChunkSize: 262144,
            disableAutoFetch: true,
          });
          taskRef.current = currentTask;

          currentTask.onProgress = (p: { loaded: number; total: number }) => {
            if (runIdRef.current !== currentRun) return;
            if (p.total > 0) {
              const pct = Math.min(100, Math.round((p.loaded / p.total) * 100));
              setProgress(pct);
            }
          };

          const loadedDoc = await currentTask.promise;
          if (runIdRef.current !== currentRun) {
            loadedDoc.cleanup().catch(() => {});
            return;
          }

          if (docRef.current && docRef.current !== loadedDoc) {
            docRef.current.cleanup().catch(() => {});
          }

          docRef.current = loadedDoc;
          setDoc(loadedDoc);
          setStatus('ready');
          setProgress(null);
          setRecovering(false);
          recoveringRef.current = false;
          return;
        } catch {
          if (currentTask) {
            currentTask.destroy().catch(() => {});
            if (taskRef.current === currentTask) {
              taskRef.current = null;
            }
          }
        }
      }

      if (runIdRef.current === currentRun) {
        destroyCurrent();
        setDoc(null);
        setProgress(null);
        setRecovering(false);
        recoveringRef.current = false;
        setStatus('error');
      }
    },
    [path, destroyCurrent]
  );

  const retry = useCallback(() => {
    recoveryTimesRef.current = [];
    loadWithRetries(true, false);
  }, [loadWithRetries]);

  const recover = useCallback(() => {
    if (recoveringRef.current) return;
    const now = Date.now();
    recoveryTimesRef.current = recoveryTimesRef.current.filter(
      (t) => now - t < RECOVERY_WINDOW_MS
    );

    if (recoveryTimesRef.current.length >= MAX_RECOVERIES_IN_WINDOW) {
      runIdRef.current++;
      destroyCurrent();
      setDoc(null);
      setProgress(null);
      setRecovering(false);
      recoveringRef.current = false;
      setStatus('error');
      return;
    }

    recoveryTimesRef.current.push(now);
    recoveringRef.current = true;
    setRecovering(true);
    loadWithRetries(true, true);
  }, [destroyCurrent, loadWithRetries]);

  useEffect(() => {
    recoveryTimesRef.current = [];
    hiddenAtRef.current = null;
    loadWithRetries(false, false);

    return () => {
      runIdRef.current++;
      recoveringRef.current = false;
      destroyCurrent();
    };
  }, [path, loadWithRetries, destroyCurrent]);

  useEffect(() => {
    const handleVisibilityChange = () => {
      if (document.visibilityState === 'hidden') {
        hiddenAtRef.current = Date.now();
      } else if (document.visibilityState === 'visible') {
        const hiddenAt = hiddenAtRef.current;
        hiddenAtRef.current = null;
        if (hiddenAt !== null && Date.now() - hiddenAt > HIDDEN_EXPIRY_MS) {
          recover();
        }
      }
    };

    document.addEventListener('visibilitychange', handleVisibilityChange);
    return () => {
      document.removeEventListener('visibilitychange', handleVisibilityChange);
    };
  }, [recover]);

  return { doc, status, progress, recovering, retry, recover };
}
