import { ChevronUp, ChevronDown, ZoomIn, ZoomOut } from '../icons/index.ts';

export interface PdfControlsProps {
  currentPage: number;
  numPages: number;
  zoom: number;
  onPrevPage: () => void;
  onNextPage: () => void;
  onZoomOut: () => void;
  onZoomIn: () => void;
  onResetZoom: () => void;
}

export function PdfControls({
  currentPage,
  numPages,
  zoom,
  onPrevPage,
  onNextPage,
  onZoomOut,
  onZoomIn,
  onResetZoom,
}: PdfControlsProps) {
  const iconBtnClass =
    'flex h-7 w-7 items-center justify-center rounded-full text-[#78716C] dark:text-[#A8A29E] hover:bg-[#F5F5F4] dark:hover:bg-[#292524] hover:text-[#1C1917] dark:hover:text-[#FAFAF9] disabled:opacity-40 disabled:pointer-events-none transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#F59E0B]';

  return (
    <div className="absolute bottom-3 left-1/2 -translate-x-1/2 z-10 flex items-center gap-0.5 sm:gap-1 px-2 h-8 sm:h-9 max-w-[calc(100%-16px)] whitespace-nowrap rounded-full border border-[#E7E5E4] dark:border-[#292524] bg-white/95 dark:bg-[#1C1917]/95 shadow-sm select-none">
      <button
        type="button"
        disabled={currentPage <= 1}
        onClick={onPrevPage}
        aria-label="Previous page"
        title="Previous page"
        className={iconBtnClass}
      >
        <ChevronUp className="h-4 w-4" />
      </button>

      <span className="px-1.5 text-[12px] font-medium tabular-nums text-[#1C1917] dark:text-[#FAFAF9]">
        {currentPage} / {numPages}
      </span>

      <button
        type="button"
        disabled={currentPage >= numPages}
        onClick={onNextPage}
        aria-label="Next page"
        title="Next page"
        className={iconBtnClass}
      >
        <ChevronDown className="h-4 w-4" />
      </button>

      <div className="h-4 w-px bg-[#E7E5E4] dark:bg-[#292524] mx-0.5" />

      <button
        type="button"
        disabled={zoom <= 0.5}
        onClick={onZoomOut}
        aria-label="Zoom out"
        title="Zoom out"
        className={iconBtnClass}
      >
        <ZoomOut className="h-4 w-4" />
      </button>

      <button
        type="button"
        onClick={onResetZoom}
        aria-label="Reset zoom"
        title="Reset zoom"
        className="px-1.5 h-7 rounded-full text-[12px] font-medium tabular-nums text-[#1C1917] dark:text-[#FAFAF9] hover:bg-[#F5F5F4] dark:hover:bg-[#292524] transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#F59E0B]"
      >
        {Math.round(zoom * 100)}%
      </button>

      <button
        type="button"
        disabled={zoom >= 3}
        onClick={onZoomIn}
        aria-label="Zoom in"
        title="Zoom in"
        className={iconBtnClass}
      >
        <ZoomIn className="h-4 w-4" />
      </button>
    </div>
  );
}
